/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.export;

import dev.jarlens.core.JarModel;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class Exporter {
    private Exporter() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void exportCleanJar(JarModel jarModel, Map<String, byte[]> map, Function<String, String> function, Path path) throws IOException {
        Path path2 = Files.createTempFile(path.toAbsolutePath().getParent(), ".jarlens", ".tmp", new FileAttribute[0]);
        try {
            try (BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(Files.newOutputStream(path2, new OpenOption[0]));
                 JarOutputStream jarOutputStream = new JarOutputStream(bufferedOutputStream);){
                HashSet<String> hashSet = new HashSet<String>();
                Manifest manifest = Exporter.cleanManifest(jarModel, function);
                jarOutputStream.putNextEntry(new JarEntry("META-INF/MANIFEST.MF"));
                manifest.write(jarOutputStream);
                jarOutputStream.closeEntry();
                hashSet.add("META-INF/MANIFEST.MF");
                for (Map.Entry<String, byte[]> entry : map.entrySet()) {
                    Exporter.put(jarOutputStream, hashSet, entry.getKey() + ".class", entry.getValue());
                }
                for (Map.Entry<String, byte[]> entry : jarModel.resources().entrySet()) {
                    String string = entry.getKey();
                    if (string.equalsIgnoreCase("META-INF/MANIFEST.MF") || Exporter.isSignatureFile(string)) continue;
                    Exporter.put(jarOutputStream, hashSet, string, entry.getValue());
                }
            }
            Files.move(path2, path, StandardCopyOption.REPLACE_EXISTING);
        }
        finally {
            Files.deleteIfExists(path2);
        }
    }

    private static void put(ZipOutputStream zipOutputStream, Set<String> set, String string, byte[] byArray) throws IOException {
        if (!set.add(string)) {
            return;
        }
        ZipEntry zipEntry = new ZipEntry(string);
        zipOutputStream.putNextEntry(zipEntry);
        zipOutputStream.write(byArray);
        zipOutputStream.closeEntry();
    }

    static boolean isSignatureFile(String string) {
        String string2 = string.toUpperCase(Locale.ROOT);
        if (!string2.startsWith("META-INF/") || string2.indexOf(47, 9) >= 0) {
            return false;
        }
        return string2.endsWith(".SF") || string2.endsWith(".RSA") || string2.endsWith(".DSA") || string2.endsWith(".EC") || string2.startsWith("META-INF/SIG-");
    }

    private static Manifest cleanManifest(JarModel jarModel, Function<String, String> function) {
        String string;
        String string2;
        Attributes attributes;
        Manifest manifest = new Manifest();
        if (jarModel.manifestBytes() != null) {
            try {
                manifest = new Manifest(new ByteArrayInputStream(jarModel.manifestBytes()));
            }
            catch (IOException iOException) {
                manifest = new Manifest();
            }
        }
        if ((attributes = manifest.getMainAttributes()).getValue(Attributes.Name.MANIFEST_VERSION) == null) {
            attributes.put(Attributes.Name.MANIFEST_VERSION, "1.0");
        }
        if ((string2 = attributes.getValue(Attributes.Name.MAIN_CLASS)) != null && (string = function.apply(string2.trim().replace('.', '/'))) != null) {
            attributes.put(Attributes.Name.MAIN_CLASS, string.replace('/', '.'));
        }
        manifest.getEntries().clear();
        attributes.putValue("Deobfuscated-By", "JarLens");
        return manifest;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * WARNING - void declaration
     */
    public static int exportSources(JarModel jarModel, List<String> list, Function<String, String> function, boolean bl, Path path, int n, Progress progress, BooleanSupplier booleanSupplier) throws IOException {
        Path path2 = Files.createTempFile(path.toAbsolutePath().getParent(), ".jarlens", ".tmp", new FileAttribute[0]);
        ExecutorService executorService = Executors.newFixedThreadPool(Math.max(1, n), runnable -> {
            Thread thread = new Thread(runnable, "source-export");
            thread.setDaemon(true);
            return thread;
        });
        try {
            int n2;
            AtomicInteger atomicInteger = new AtomicInteger();
            int n3 = list.size();
            try (BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(Files.newOutputStream(path2, new OpenOption[0]));
                 ZipOutputStream zipOutputStream = new ZipOutputStream(bufferedOutputStream);){
                HashSet<String> hashSet = new HashSet<String>();
                int n4 = Math.max(4, n * 4);
                ArrayList<String> arrayList = new ArrayList<String>(list);
                ArrayList<Future<String>> arrayList2 = new ArrayList<Future<String>>();
                int n5 = 0;
                for (int i = 0; i < arrayList.size(); ++i) {
                    void object;
                    String string;
                    while (n5 < arrayList.size() && arrayList2.size() < n4) {
                        string = arrayList.get(n5++);
                        arrayList2.add(executorService.submit(() -> (String)function.apply(string)));
                    }
                    if (booleanSupplier.getAsBoolean()) {
                        throw new CancellationException();
                    }
                    string = arrayList.get(i);
                    try {
                        String string2 = (String)((Future)arrayList2.remove(0)).get();
                    }
                    catch (InterruptedException interruptedException) {
                        Thread.currentThread().interrupt();
                        throw new CancellationException();
                    }
                    catch (Exception exception) {
                        String string3 = "/* JarLens could not decompile " + string.replace('/', '.') + ": " + String.valueOf(exception) + " */\n";
                    }
                    Exporter.put(zipOutputStream, hashSet, string + ".java", ((String)object).getBytes(StandardCharsets.UTF_8));
                    progress.update(atomicInteger.incrementAndGet(), n3, string);
                }
                if (bl) {
                    for (Map.Entry<String, byte[]> entry : jarModel.resources().entrySet()) {
                        if (booleanSupplier.getAsBoolean()) {
                            throw new CancellationException();
                        }
                        if (Exporter.isSignatureFile(entry.getKey())) continue;
                        Exporter.put(zipOutputStream, hashSet, entry.getKey(), entry.getValue());
                    }
                }
            }
            Files.move(path2, path, StandardCopyOption.REPLACE_EXISTING);
            int n6 = n2 = n3;
            return n6;
        }
        finally {
            executorService.shutdownNow();
            Files.deleteIfExists(path2);
        }
    }

    public static interface Progress {
        public void update(int var1, int var2, String var3);
    }
}

