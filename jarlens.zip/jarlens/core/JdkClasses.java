/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.core;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public final class JdkClasses {
    private static final ConcurrentHashMap<String, Optional<byte[]>> CACHE = new ConcurrentHashMap();
    private static final ClassLoader PLATFORM = ClassLoader.getPlatformClassLoader();

    private JdkClasses() {
    }

    public static boolean isPlatformName(String string) {
        return string.startsWith("java/") || string.startsWith("javax/") || string.startsWith("jdk/") || string.startsWith("sun/") || string.startsWith("com/sun/") || string.startsWith("org/w3c/") || string.startsWith("org/xml/") || string.startsWith("org/ietf/");
    }

    public static byte[] get(String string2) {
        if (string2 == null || !JdkClasses.isPlatformName(string2)) {
            return null;
        }
        return CACHE.computeIfAbsent(string2, string -> {
            Optional<byte[]> optional;
            block8: {
                InputStream inputStream = PLATFORM.getResourceAsStream(string + ".class");
                try {
                    optional = Optional.ofNullable(inputStream == null ? null : inputStream.readAllBytes());
                    if (inputStream == null) break block8;
                }
                catch (Throwable throwable) {
                    try {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            }
                            catch (Throwable throwable2) {
                                throwable.addSuppressed(throwable2);
                            }
                        }
                        throw throwable;
                    }
                    catch (IOException iOException) {
                        return Optional.empty();
                    }
                }
                inputStream.close();
            }
            return optional;
        }).orElse(null);
    }
}

