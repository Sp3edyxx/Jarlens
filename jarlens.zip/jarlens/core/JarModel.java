/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.jar.Manifest;

public final class JarModel {
    private final String displayName;
    private final String sourcePath;
    private final Map<String, byte[]> classes = new TreeMap<String, byte[]>();
    private final Map<String, String> classEntryPaths = new LinkedHashMap<String, String>();
    private final Map<String, byte[]> resources = new TreeMap<String, byte[]>();
    private final List<BrokenClass> brokenClasses = new ArrayList<BrokenClass>();
    private final List<String> warnings = new ArrayList<String>();
    private final Map<Integer, Integer> classVersions = new TreeMap<Integer, Integer>();
    private Manifest manifest;
    private byte[] manifestBytes;

    public JarModel(String string, String string2) {
        this.displayName = string;
        this.sourcePath = string2;
    }

    public String displayName() {
        return this.displayName;
    }

    public String sourcePath() {
        return this.sourcePath;
    }

    public Map<String, byte[]> classes() {
        return Collections.unmodifiableNavigableMap((TreeMap)this.classes);
    }

    public Map<String, String> classEntryPaths() {
        return Collections.unmodifiableMap(this.classEntryPaths);
    }

    public Map<String, byte[]> resources() {
        return Collections.unmodifiableMap(this.resources);
    }

    public List<BrokenClass> brokenClasses() {
        return Collections.unmodifiableList(this.brokenClasses);
    }

    public List<String> warnings() {
        return Collections.unmodifiableList(this.warnings);
    }

    public Map<Integer, Integer> classVersions() {
        return Collections.unmodifiableMap(this.classVersions);
    }

    public Manifest manifest() {
        return this.manifest;
    }

    public byte[] manifestBytes() {
        return this.manifestBytes;
    }

    public String mainClass() {
        if (this.manifest == null) {
            return null;
        }
        String string = this.manifest.getMainAttributes().getValue("Main-Class");
        return string == null ? null : string.trim();
    }

    public boolean isNestedArchive(String string) {
        String string2 = string.toLowerCase();
        return string2.endsWith(".jar") || string2.endsWith(".war") || string2.endsWith(".ear") || string2.endsWith(".zip");
    }

    void putClass(String string, String string2, byte[] byArray, int n) {
        this.classes.put(string, byArray);
        this.classEntryPaths.put(string, string2);
        this.classVersions.merge(n, 1, Integer::sum);
    }

    boolean hasClass(String string) {
        return this.classes.containsKey(string);
    }

    void putResource(String string, byte[] byArray) {
        this.resources.put(string, byArray);
    }

    boolean hasResource(String string) {
        return this.resources.containsKey(string);
    }

    void addBroken(String string, String string2) {
        this.brokenClasses.add(new BrokenClass(string, string2));
    }

    void warn(String string) {
        this.warnings.add(string);
    }

    void setManifest(Manifest manifest, byte[] byArray) {
        this.manifest = manifest;
        this.manifestBytes = byArray;
    }

    public static String javaVersionName(int n) {
        if (n >= 49) {
            return "Java " + (n - 44);
        }
        return switch (n) {
            case 48 -> "Java 1.4";
            case 47 -> "Java 1.3";
            case 46 -> "Java 1.2";
            case 45 -> "Java 1.1";
            default -> "class version " + n;
        };
    }

    public record BrokenClass(String entryPath, String error) {
    }
}

