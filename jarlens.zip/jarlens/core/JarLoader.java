/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.core;

import dev.jarlens.core.JarModel;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.tree.ClassNode;

public final class JarLoader {
    public static final long MAX_ENTRY_SIZE = 0x10000000L;
    public static final long MAX_TOTAL_SIZE = 0xC0000000L;
    public static final int MAX_ENTRIES = 400000;
    private static final MethodVisitor NOOP_METHOD = new MethodVisitor(589824){};
    private static final ClassVisitor VALIDATOR = new ClassVisitor(589824){

        @Override
        public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
            return NOOP_METHOD;
        }
    };
    private long totalRead;
    private final Set<String> seen = new HashSet<String>();
    private JarModel model;

    private JarLoader() {
    }

    public static JarModel load(Path path) throws JarLoadException {
        if (!Files.isRegularFile(path, new LinkOption[0])) {
            throw new JarLoadException("Not a file: " + String.valueOf(path), null);
        }
        JarLoader jarLoader = new JarLoader();
        jarLoader.model = new JarModel(path.getFileName().toString(), path.toAbsolutePath().toString());
        jarLoader.readFile(path);
        return jarLoader.model;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static JarModel load(String string, byte[] byArray) throws JarLoadException {
        JarLoader jarLoader = new JarLoader();
        jarLoader.model = new JarModel(string, null);
        Path path = null;
        try {
            path = Files.createTempFile("jarlens-nested", ".zip", new FileAttribute[0]);
            Files.write(path, byArray, new OpenOption[0]);
            jarLoader.readFile(path);
        }
        catch (JarLoadException jarLoadException) {
            throw jarLoadException;
        }
        catch (IOException iOException) {
            jarLoader.readStream(new ByteArrayInputStream(byArray), true);
        }
        finally {
            if (path != null) {
                try {
                    Files.deleteIfExists(path);
                }
                catch (IOException iOException) {}
            }
        }
        return jarLoader.model;
    }

    private void readFile(Path path) throws JarLoadException {
        Throwable throwable = null;
        for (Charset charset : new Charset[]{StandardCharsets.UTF_8, StandardCharsets.ISO_8859_1}) {
            try (ZipFile zipFile = new ZipFile(path.toFile(), charset);){
                this.readZipFile(zipFile);
                this.finish();
                return;
            }
            catch (JarLoadException jarLoadException) {
                throw jarLoadException;
            }
            catch (Exception | InternalError throwable2) {
                throwable = throwable2;
                this.resetModel();
            }
        }
        try (InputStream inputStream = Files.newInputStream(path, new OpenOption[0]);){
            this.model.warn("Central directory unreadable (" + JarLoader.describe(throwable) + "); recovered entries by scanning local file headers.");
            this.readStream(inputStream, false);
        }
        catch (IOException iOException) {
            throw new JarLoadException("Could not read archive: " + JarLoader.describe(throwable), throwable);
        }
    }

    private void resetModel() {
        this.model = new JarModel(this.model.displayName(), this.model.sourcePath());
        this.seen.clear();
        this.totalRead = 0L;
    }

    private void readZipFile(ZipFile zipFile) throws IOException {
        Enumeration<? extends ZipEntry> enumeration = zipFile.entries();
        int n = 0;
        while (enumeration.hasMoreElements()) {
            byte[] byArray;
            ZipEntry zipEntry = enumeration.nextElement();
            if (++n > 400000) {
                this.model.warn("Archive has more than 400000 entries; the rest were skipped.");
                break;
            }
            try (InputStream inputStream = zipFile.getInputStream(zipEntry);){
                byArray = inputStream == null ? new byte[]{} : this.readLimited(inputStream, zipEntry.getName());
            }
            catch (EntryTooLargeException entryTooLargeException) {
                this.model.warn(entryTooLargeException.getMessage());
                continue;
            }
            catch (Exception exception) {
                this.model.warn("Unreadable entry '" + JarLoader.safeName(zipEntry.getName()) + "': " + JarLoader.describe(exception));
                continue;
            }
            if (byArray == null) continue;
            this.handleEntry(zipEntry.getName(), byArray);
        }
    }

    private void readStream(InputStream inputStream, boolean bl) throws JarLoadException {
        int n;
        block17: {
            n = 0;
            try {
                ZipInputStream zipInputStream = new ZipInputStream(inputStream, StandardCharsets.UTF_8);
                block12: while (true) {
                    while (true) {
                        ZipEntry zipEntry;
                        try {
                            zipEntry = zipInputStream.getNextEntry();
                        }
                        catch (Exception exception) {
                            this.model.warn("Stopped reading at a corrupt entry: " + JarLoader.describe(exception));
                            break block17;
                        }
                        if (zipEntry == null) {
                            break block17;
                        }
                        if (++n > 400000) {
                            this.model.warn("Archive has more than 400000 entries; the rest were skipped.");
                            break block17;
                        }
                        try {
                            byte[] byArray = this.readLimited(zipInputStream, zipEntry.getName());
                            if (byArray == null) continue block12;
                            this.handleEntry(zipEntry.getName(), byArray);
                            continue block12;
                        }
                        catch (EntryTooLargeException entryTooLargeException) {
                            this.model.warn(entryTooLargeException.getMessage());
                            continue;
                        }
                        catch (Exception exception) {
                            this.model.warn("Unreadable entry '" + JarLoader.safeName(zipEntry.getName()) + "': " + JarLoader.describe(exception));
                            continue;
                        }
                        break;
                    }
                }
                finally {
                    zipInputStream.close();
                }
            }
            catch (IOException iOException) {
                this.model.warn("Archive stream error: " + JarLoader.describe(iOException));
            }
        }
        if (n == 0 && this.model.classes().isEmpty() && this.model.resources().isEmpty()) {
            throw new JarLoadException("The file is not a valid jar/zip archive (no readable entries).", null);
        }
        this.finish();
    }

    private byte[] readLimited(InputStream inputStream, String string) throws IOException {
        long l = Math.min(0x10000000L, 0xC0000000L - this.totalRead);
        byte[] byArray = inputStream.readNBytes((int)Math.max(0L, l) + 1);
        if ((long)byArray.length > l) {
            throw new EntryTooLargeException((long)byArray.length > 0x10000000L ? "Skipped entry '" + JarLoader.safeName(string) + "': larger than 256 MB (possible zip bomb)." : "Skipped entry '" + JarLoader.safeName(string) + "': archive exceeds the total size limit (possible zip bomb).");
        }
        this.totalRead += (long)byArray.length;
        return byArray;
    }

    private void handleEntry(String string, byte[] byArray) {
        String string2 = JarLoader.normalize(string);
        if (string2.isEmpty()) {
            return;
        }
        boolean bl = string.endsWith("/") || string.endsWith("\\");
        boolean bl2 = byArray.length >= 10 && (byArray[0] & 0xFF) == 202 && (byArray[1] & 0xFF) == 254 && (byArray[2] & 0xFF) == 186 && (byArray[3] & 0xFF) == 190;
        boolean bl3 = bl2;
        if (bl && byArray.length == 0) {
            return;
        }
        if (bl && bl2) {
            this.model.warn("Class file hidden behind directory-like entry name: " + JarLoader.safeName(string));
        }
        if (!this.seen.add(string2)) {
            this.model.warn("Duplicate entry ignored: " + JarLoader.safeName(string2));
            return;
        }
        if (string2.equalsIgnoreCase("META-INF/MANIFEST.MF")) {
            try {
                this.model.setManifest(new Manifest(new ByteArrayInputStream(byArray)), byArray);
            }
            catch (Exception exception) {
                this.model.warn("Malformed manifest: " + JarLoader.describe(exception));
            }
            this.model.putResource(string2, byArray);
            return;
        }
        boolean bl4 = string2.endsWith(".class");
        boolean bl5 = string2.startsWith("META-INF/versions/");
        if (bl2 && (bl4 || bl) && !bl5) {
            this.addClass(string2, byArray);
        } else {
            if (bl4 && !bl2 && !bl5) {
                this.model.warn("Entry '" + JarLoader.safeName(string2) + "' is named .class but is not a class file (decoy).");
            }
            this.model.putResource(string2, byArray);
        }
    }

    private void addClass(String string, byte[] byArray) {
        String string2;
        Object object;
        int n = (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
        byte[] byArray2 = byArray;
        try {
            object = new ClassReader(byArray);
            string2 = ((ClassReader)object).getClassName();
            try {
                ((ClassReader)object).accept(VALIDATOR, 0);
            }
            catch (Exception | StackOverflowError throwable) {
                ClassNode classNode = new ClassNode();
                ((ClassReader)object).accept(classNode, 6);
                ClassWriter classWriter = new ClassWriter(1);
                classNode.accept(classWriter);
                byArray2 = classWriter.toByteArray();
                this.model.warn("Class " + string2 + " had malformed attributes (" + JarLoader.describe(throwable) + "); debug info and frames were stripped so it can be analysed.");
            }
        }
        catch (Exception | StackOverflowError throwable) {
            this.model.addBroken(string, JarLoader.describe(throwable));
            this.model.putResource(string, byArray);
            return;
        }
        if (string2 == null || string2.isEmpty()) {
            this.model.addBroken(string, "class has no name");
            this.model.putResource(string, byArray);
            return;
        }
        if (this.model.hasClass(string2)) {
            this.model.warn("Duplicate definition of class " + string2 + " in '" + JarLoader.safeName(string) + "' ignored.");
            return;
        }
        object = string2 + ".class";
        if (!string.equals(object)) {
            this.model.warn("Class " + string2 + " is stored under a different path ('" + JarLoader.safeName(string) + "').");
        }
        this.model.putClass(string2, string, byArray2, n);
    }

    private void finish() {
        if (this.model.classes().isEmpty() && !this.model.brokenClasses().isEmpty()) {
            this.model.warn("No class could be parsed; the archive may be deliberately corrupted.");
        }
    }

    static String normalize(String string) {
        String string2 = string.replace('\\', '/');
        while (string2.startsWith("/")) {
            string2 = string2.substring(1);
        }
        while (string2.endsWith("/")) {
            string2 = string2.substring(0, string2.length() - 1);
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (String string3 : string2.split("/")) {
            if (string3.isEmpty() || string3.equals(".") || string3.equals("..")) continue;
            if (stringBuilder.length() > 0) {
                stringBuilder.append('/');
            }
            stringBuilder.append(string3);
        }
        return stringBuilder.toString();
    }

    static String safeName(String string) {
        if (string == null) {
            return "?";
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < string.length() && stringBuilder.length() < 200; ++i) {
            char c = string.charAt(i);
            if (c < ' ' || c == '\u007f') {
                stringBuilder.append(String.format("\\u%04x", Character.valueOf(c)));
                continue;
            }
            stringBuilder.append(c);
        }
        if (string.length() > 200) {
            stringBuilder.append("\u2026");
        }
        return stringBuilder.toString();
    }

    public static String describe(Throwable throwable) {
        if (throwable == null) {
            return "unknown error";
        }
        if (throwable instanceof EOFException) {
            return "unexpected end of file";
        }
        String string = throwable.getMessage();
        return throwable.getClass().getSimpleName() + (String)(string == null ? "" : ": " + string);
    }

    public static final class JarLoadException
    extends IOException {
        public JarLoadException(String string, Throwable throwable) {
            super(string, throwable);
        }
    }

    private static final class EntryTooLargeException
    extends IOException {
        EntryTooLargeException(String string) {
            super(string);
        }
    }
}

