/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.core;

import dev.jarlens.core.JdkClasses;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;

public final class ClassHierarchy {
    private final Function<String, byte[]> jarClasses;
    private final ConcurrentHashMap<String, Optional<ClassInfo>> infos = new ConcurrentHashMap();
    private final ConcurrentHashMap<Member, Optional<String>> fieldOwners = new ConcurrentHashMap();
    private final ConcurrentHashMap<Member, Optional<String>> methodOwners = new ConcurrentHashMap();
    private final ConcurrentHashMap<Pair, Optional<Boolean>> subtypes = new ConcurrentHashMap();
    private final ConcurrentHashMap<String, Set<String>> interfaces = new ConcurrentHashMap();

    public ClassHierarchy(Map<String, byte[]> map) {
        HashMap<String, byte[]> hashMap = new HashMap<String, byte[]>(map);
        this.jarClasses = hashMap::get;
    }

    public ClassHierarchy(Function<String, byte[]> function) {
        this.jarClasses = function;
    }

    public ClassInfo get(String string) {
        if (string == null) {
            return null;
        }
        return this.infos.computeIfAbsent(string, this::read).orElse(null);
    }

    public boolean isJarClass(String string) {
        ClassInfo classInfo = this.get(string);
        return classInfo != null && classInfo.inJar;
    }

    private Optional<ClassInfo> read(String string) {
        byte[] byArray = this.jarClasses.apply(string);
        boolean bl = byArray != null;
        boolean bl2 = bl;
        if (byArray == null) {
            byArray = JdkClasses.get(string);
        }
        if (byArray == null) {
            return Optional.empty();
        }
        try {
            ClassReader classReader = new ClassReader(byArray);
            final HashMap hashMap = new HashMap();
            final HashMap hashMap2 = new HashMap();
            final String[] stringArray = new String[2];
            final int[] nArray = new int[1];
            final ArrayList arrayList = new ArrayList(List.of(List.of()));
            classReader.accept(new ClassVisitor(this, 589824){
                {
                    Objects.requireNonNull(classHierarchy);
                    super(n);
                }

                @Override
                public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray2) {
                    stringArray[0] = string;
                    stringArray[1] = string3;
                    nArray[0] = n2;
                    arrayList.set(0, stringArray2 == null ? List.of() : List.of(stringArray2));
                }

                @Override
                public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
                    hashMap2.put(string + " " + string2, n);
                    return null;
                }

                @Override
                public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray2) {
                    hashMap.put(string + string2, n);
                    return null;
                }
            }, 7);
            return Optional.of(new ClassInfo(string, stringArray[1], arrayList.get(0), nArray[0], bl, Collections.unmodifiableMap(hashMap), Collections.unmodifiableMap(hashMap2)));
        }
        catch (Exception exception) {
            return Optional.empty();
        }
    }

    public boolean isInterface(String string) {
        ClassInfo classInfo = this.get(string);
        return classInfo != null && classInfo.isInterface();
    }

    public String superName(String string) {
        ClassInfo classInfo = this.get(string);
        return classInfo == null ? null : classInfo.superName;
    }

    public Set<String> allSupertypes(String string) {
        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
        ArrayDeque<String> arrayDeque = new ArrayDeque<String>();
        arrayDeque.add(string);
        while (!arrayDeque.isEmpty()) {
            ClassInfo classInfo = this.get((String)arrayDeque.poll());
            if (classInfo == null) continue;
            if (classInfo.superName != null && linkedHashSet.add(classInfo.superName)) {
                arrayDeque.add(classInfo.superName);
            }
            for (String string2 : classInfo.interfaces) {
                if (!linkedHashSet.add(string2)) continue;
                arrayDeque.add(string2);
            }
        }
        return linkedHashSet;
    }

    public Boolean isSubtypeOf(String string, String string2) {
        if (string.equals(string2) || string2.equals("java/lang/Object")) {
            return true;
        }
        Pair pair = new Pair(string, string2);
        Optional<Boolean> optional = this.subtypes.get(pair);
        if (optional == null) {
            optional = Optional.ofNullable(this.computeSubtype(string, string2));
            this.subtypes.putIfAbsent(pair, optional);
        }
        return optional.orElse(null);
    }

    private Boolean computeSubtype(String string, String string2) {
        HashSet<String> hashSet = new HashSet<String>();
        ArrayDeque<String> arrayDeque = new ArrayDeque<String>();
        arrayDeque.add(string);
        boolean bl = false;
        while (!arrayDeque.isEmpty()) {
            String string3 = (String)arrayDeque.poll();
            if (!hashSet.add(string3)) continue;
            ClassInfo classInfo = this.get(string3);
            if (classInfo == null) {
                bl = true;
                continue;
            }
            if (string3.equals(string2)) {
                return true;
            }
            if (classInfo.superName != null) {
                arrayDeque.add(classInfo.superName);
            }
            arrayDeque.addAll(classInfo.interfaces);
        }
        return bl ? null : Boolean.FALSE;
    }

    public String commonSuperClass(String string, String string2) {
        ClassInfo classInfo;
        if (string.equals(string2)) {
            return string;
        }
        ClassInfo classInfo2 = this.get(string);
        ClassInfo classInfo3 = this.get(string2);
        if (classInfo2 == null || classInfo3 == null) {
            return "java/lang/Object";
        }
        if (classInfo2.isInterface() || classInfo3.isInterface()) {
            if (Boolean.TRUE.equals(this.isSubtypeOf(string2, string))) {
                return string;
            }
            if (Boolean.TRUE.equals(this.isSubtypeOf(string, string2))) {
                return string2;
            }
            return "java/lang/Object";
        }
        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
        String string3 = string;
        int n = 0;
        while (string3 != null && n++ < 1000) {
            linkedHashSet.add(string3);
            classInfo = this.get(string3);
            if (classInfo == null) break;
            string3 = classInfo.superName;
        }
        string3 = string2;
        n = 0;
        while (string3 != null && n++ < 1000) {
            if (linkedHashSet.contains(string3)) {
                return string3;
            }
            classInfo = this.get(string3);
            if (classInfo == null) break;
            string3 = classInfo.superName;
        }
        return "java/lang/Object";
    }

    public String resolveFieldOwner(String string, String string2, String string3) {
        Member member = new Member(string, string2, string3);
        Optional<String> optional = this.fieldOwners.get(member);
        if (optional == null) {
            optional = Optional.ofNullable(this.computeFieldOwner(string, string2, string3));
            this.fieldOwners.putIfAbsent(member, optional);
        }
        return optional.orElse(null);
    }

    private String computeFieldOwner(String string, String string2, String string3) {
        HashSet<String> hashSet = new HashSet<String>();
        String string4 = string;
        while (string4 != null && hashSet.add(string4)) {
            ClassInfo classInfo = this.get(string4);
            if (classInfo == null) {
                return null;
            }
            if (classInfo.hasField(string2, string3)) {
                return string4;
            }
            for (String string5 : this.allInterfaces(string4)) {
                ClassInfo classInfo2 = this.get(string5);
                if (classInfo2 == null || !classInfo2.hasField(string2, string3)) continue;
                return string5;
            }
            string4 = classInfo.superName;
        }
        return null;
    }

    public String resolveMethodOwner(String string, String string2, String string3) {
        Member member = new Member(string, string2, string3);
        Optional<String> optional = this.methodOwners.get(member);
        if (optional == null) {
            optional = Optional.ofNullable(this.computeMethodOwner(string, string2, string3));
            this.methodOwners.putIfAbsent(member, optional);
        }
        return optional.orElse(null);
    }

    private String computeMethodOwner(String string, String string2, String string3) {
        ClassInfo classInfo;
        HashSet<String> hashSet = new HashSet<String>();
        String string4 = string;
        while (string4 != null && hashSet.add(string4) && (classInfo = this.get(string4)) != null) {
            if (classInfo.hasMethod(string2, string3)) {
                return string4;
            }
            string4 = classInfo.superName;
        }
        for (String string5 : this.allInterfaces(string)) {
            ClassInfo classInfo2 = this.get(string5);
            if (classInfo2 == null || !classInfo2.hasMethod(string2, string3)) continue;
            return string5;
        }
        return null;
    }

    private Set<String> allInterfaces(String string) {
        Set<String> set2 = this.interfaces.get(string);
        if (set2 != null) {
            return set2;
        }
        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
        for (String set3 : this.allSupertypes(string)) {
            ClassInfo classInfo = this.get(set3);
            if (classInfo == null || !classInfo.isInterface()) continue;
            linkedHashSet.add(set3);
        }
        Set set4 = Collections.unmodifiableSet(linkedHashSet);
        Set<String> set = this.interfaces.putIfAbsent(string, set4);
        return set != null ? set : set4;
    }

    public static final class ClassInfo {
        public final String name;
        public final String superName;
        public final List<String> interfaces;
        public final int access;
        public final boolean inJar;
        public final Map<String, Integer> methods;
        public final Map<String, Integer> fields;

        ClassInfo(String string, String string2, List<String> list, int n, boolean bl, Map<String, Integer> map, Map<String, Integer> map2) {
            this.name = string;
            this.superName = string2;
            this.interfaces = list;
            this.access = n;
            this.inJar = bl;
            this.methods = map;
            this.fields = map2;
        }

        public boolean isInterface() {
            return (this.access & 0x200) != 0;
        }

        public boolean hasMethod(String string, String string2) {
            return this.methods.containsKey(string + string2);
        }

        public boolean hasField(String string, String string2) {
            return this.fields.containsKey(string + " " + string2);
        }
    }

    private record Pair(String a, String b) {
    }

    private record Member(String owner, String name, String desc) {
    }
}

