/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.mapping;

import dev.jarlens.core.ClassHierarchy;
import dev.jarlens.deob.HierarchyRemapper;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class MappingSet {
    private final String format;
    final Map<String, String> classes = new LinkedHashMap<String, String>();
    final List<Member> methods = new ArrayList<Member>();
    final List<Member> fields = new ArrayList<Member>();

    MappingSet(String string) {
        this.format = string;
    }

    public String format() {
        return this.format;
    }

    public int classCount() {
        return this.classes.size();
    }

    public int methodCount() {
        return this.methods.size();
    }

    public int fieldCount() {
        return this.fields.size();
    }

    public boolean isEmpty() {
        return this.classes.isEmpty() && this.methods.isEmpty() && this.fields.isEmpty();
    }

    public HierarchyRemapper toRemapper(ClassHierarchy classHierarchy, Set<String> set) {
        ClassHierarchy.ClassInfo classInfo;
        HierarchyRemapper hierarchyRemapper = new HierarchyRemapper(classHierarchy);
        HashSet<String> hashSet = new HashSet<String>();
        for (String object : set) {
            if (this.classes.containsKey(object)) continue;
            hashSet.add(object);
        }
        for (Map.Entry entry : this.classes.entrySet()) {
            String string = (String)entry.getKey();
            String string2 = (String)entry.getValue();
            if (!set.contains(string) || string.equals(string2) || string2.isEmpty() || !hashSet.add(string2)) continue;
            hierarchyRemapper.mapClass(string, string2);
        }
        for (Member member : this.methods) {
            if (!set.contains(member.owner) || member.desc == null || member.name.equals(member.newName) || member.name.startsWith("<") || (classInfo = classHierarchy.get(member.owner)) == null || !classInfo.hasMethod(member.name, member.desc)) continue;
            hierarchyRemapper.mapMethod(member.owner, member.name, member.desc, member.newName);
        }
        for (Member member : this.fields) {
            if (!set.contains(member.owner) || member.name.equals(member.newName) || (classInfo = classHierarchy.get(member.owner)) == null) continue;
            if (member.desc != null) {
                if (!classInfo.hasField(member.name, member.desc)) continue;
                hierarchyRemapper.mapField(member.owner, member.name, member.desc, member.newName);
                continue;
            }
            for (String string2 : classInfo.fields.keySet()) {
                int n;
                if (!string2.substring(0, n = string2.indexOf(32)).equals(member.name)) continue;
                hierarchyRemapper.mapField(member.owner, member.name, string2.substring(n + 1), member.newName);
            }
        }
        return hierarchyRemapper;
    }

    public record Member(String owner, String name, String desc, String newName) {
    }
}

