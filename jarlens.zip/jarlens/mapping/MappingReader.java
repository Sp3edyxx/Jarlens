/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.mapping;

import dev.jarlens.mapping.MappingSet;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MappingReader {
    private static final Pattern PG_CLASS = Pattern.compile("^(\\S+)\\s+->\\s+(\\S+):$");
    private static final Pattern PG_METHOD = Pattern.compile("^(?:\\d+:\\d+:)?(\\S+)\\s+([^\\s(]+)\\(([^)]*)\\)(?::\\d+(?::\\d+)?)?\\s+->\\s+(\\S+)$");
    private static final Pattern PG_FIELD = Pattern.compile("^(\\S+)\\s+(\\S+)\\s+->\\s+(\\S+)$");

    private MappingReader() {
    }

    public static MappingSet read(Path path) throws IOException {
        if (Files.size(path) > 0x20000000L) {
            throw new IOException("Mapping file is too large");
        }
        List<String> list = Files.readAllLines(path, StandardCharsets.UTF_8);
        String string2 = list.stream().filter(string -> !string.isBlank() && !string.startsWith("#")).findFirst().orElse("");
        if (string2.startsWith("tiny\t2\t")) {
            return MappingReader.tinyV2(list);
        }
        if (string2.startsWith("v1\t")) {
            return MappingReader.tinyV1(list);
        }
        if (string2.startsWith("CLASS ") || string2.startsWith("CLASS\t")) {
            return MappingReader.enigma(list);
        }
        if (string2.contains(" -> ") && string2.trim().endsWith(":")) {
            return MappingReader.proguard(list);
        }
        throw new IOException("Unrecognized mapping format (expected ProGuard, Tiny v1/v2 or Enigma)");
    }

    private static MappingSet proguard(List<String> list) throws IOException {
        Object object;
        Object object2;
        MappingSet mappingSet = new MappingSet("ProGuard");
        HashMap<String, String> hashMap = new HashMap<String, String>();
        for (String object3 : list) {
            Matcher matcher;
            if (object3.isBlank() || object3.startsWith("#") || Character.isWhitespace(object3.charAt(0)) || !(matcher = PG_CLASS.matcher(object3.trim())).matches()) continue;
            object2 = matcher.group(1).replace('.', '/');
            object = matcher.group(2).replace('.', '/');
            hashMap.put((String)object2, (String)object);
            mappingSet.classes.put((String)object, (String)object2);
        }
        Iterator<String> iterator = null;
        for (String string : list) {
            Object object3;
            if (string.isBlank() || string.trim().startsWith("#")) continue;
            if (!Character.isWhitespace(string.charAt(0))) {
                object2 = PG_CLASS.matcher(string.trim());
                iterator = ((Matcher)object2).matches() ? ((Matcher)object2).group(2).replace('.', '/') : null;
                continue;
            }
            if (iterator == null) continue;
            object2 = string.trim();
            object = PG_METHOD.matcher((CharSequence)object2);
            if (((Matcher)object).matches()) {
                object3 = ((Matcher)object).group(2);
                if (((String)object3).contains(".")) continue;
                StringBuilder stringBuilder = new StringBuilder("(");
                String string2 = ((Matcher)object).group(3).trim();
                if (!string2.isEmpty()) {
                    for (String string3 : string2.split(",")) {
                        stringBuilder.append(MappingReader.javaToDesc(string3.trim(), hashMap));
                    }
                }
                stringBuilder.append(')').append(MappingReader.javaToDesc(((Matcher)object).group(1), hashMap));
                mappingSet.methods.add(new MappingSet.Member((String)((Object)iterator), ((Matcher)object).group(4), stringBuilder.toString(), (String)object3));
                continue;
            }
            object3 = PG_FIELD.matcher((CharSequence)object2);
            if (!((Matcher)object3).matches()) continue;
            mappingSet.fields.add(new MappingSet.Member((String)((Object)iterator), ((Matcher)object3).group(3), MappingReader.javaToDesc(((Matcher)object3).group(1), hashMap), ((Matcher)object3).group(2)));
        }
        if (mappingSet.isEmpty()) {
            throw new IOException("No mappings found in ProGuard file");
        }
        return mappingSet;
    }

    private static String javaToDesc(String string, Map<String, String> map) {
        StringBuilder stringBuilder = new StringBuilder();
        String string2 = string;
        while (string2.endsWith("[]")) {
            stringBuilder.append('[');
            string2 = string2.substring(0, string2.length() - 2);
        }
        String string3 = switch (string2) {
            case "boolean" -> "Z";
            case "char" -> "C";
            case "byte" -> "B";
            case "short" -> "S";
            case "int" -> "I";
            case "long" -> "J";
            case "float" -> "F";
            case "double" -> "D";
            case "void" -> "V";
            default -> {
                String var7_6 = string2.replace('.', '/');
                yield "L" + map.getOrDefault(var7_6, var7_6) + ";";
            }
        };
        return String.valueOf(stringBuilder) + string3;
    }

    private static MappingSet tinyV1(List<String> list) throws IOException {
        MappingSet mappingSet = new MappingSet("Tiny v1");
        String[] stringArray = list.get(0).split("\t");
        int n = MappingReader.targetNamespace(stringArray, 1);
        for (String string : list.subList(1, list.size())) {
            String[] stringArray2 = string.split("\t");
            if (stringArray2.length < 2) continue;
            int n2 = stringArray.length - 1;
            switch (stringArray2[0]) {
                case "CLASS": {
                    if (stringArray2.length < 1 + n2) break;
                    MappingReader.put(mappingSet.classes, stringArray2[1], stringArray2[n]);
                    break;
                }
                case "FIELD": {
                    if (stringArray2.length < 3 + n2 || stringArray2[n + 2].isEmpty()) break;
                    mappingSet.fields.add(new MappingSet.Member(stringArray2[1], stringArray2[3], stringArray2[2], stringArray2[n + 2]));
                    break;
                }
                case "METHOD": {
                    if (stringArray2.length < 3 + n2 || stringArray2[n + 2].isEmpty()) break;
                    mappingSet.methods.add(new MappingSet.Member(stringArray2[1], stringArray2[3], stringArray2[2], stringArray2[n + 2]));
                }
            }
        }
        if (mappingSet.isEmpty()) {
            throw new IOException("No mappings found in Tiny v1 file");
        }
        return mappingSet;
    }

    private static int targetNamespace(String[] stringArray, int n) {
        for (int i = n; i < stringArray.length; ++i) {
            if (!stringArray[i].equals("named")) continue;
            return i - n + 1;
        }
        return stringArray.length - n;
    }

    private static MappingSet tinyV2(List<String> list) throws IOException {
        MappingSet mappingSet = new MappingSet("Tiny v2");
        String[] stringArray = list.get(0).split("\t");
        int n = MappingReader.targetNamespace(stringArray, 3);
        String string = null;
        for (String string2 : list.subList(1, list.size())) {
            int n2;
            if (string2.isEmpty()) continue;
            for (n2 = 0; n2 < string2.length() && string2.charAt(n2) == '\t'; ++n2) {
            }
            String[] stringArray2 = string2.substring(n2).split("\t", -1);
            if (n2 == 0 && stringArray2[0].equals("c")) {
                string = stringArray2.length > 1 ? stringArray2[1] : null;
                if (string == null || stringArray2.length <= n) continue;
                MappingReader.put(mappingSet.classes, stringArray2[1], stringArray2[n]);
                continue;
            }
            if (n2 != 1 || string == null || !stringArray2[0].equals("m") && !stringArray2[0].equals("f") || stringArray2.length <= n + 1) continue;
            String string3 = stringArray2[1];
            String string4 = stringArray2[2];
            String string5 = stringArray2[n + 1];
            if (string5.isEmpty()) continue;
            MappingSet.Member member = new MappingSet.Member(string, string4, string3, string5);
            if (stringArray2[0].equals("m")) {
                mappingSet.methods.add(member);
                continue;
            }
            mappingSet.fields.add(member);
        }
        if (mappingSet.isEmpty()) {
            throw new IOException("No mappings found in Tiny v2 file");
        }
        return mappingSet;
    }

    private static void put(Map<String, String> map, String string, String string2) {
        if (string != null && string2 != null && !string2.isEmpty()) {
            map.put(string, string2);
        }
    }

    private static MappingSet enigma(List<String> list) throws IOException {
        MappingSet mappingSet = new MappingSet("Enigma");
        ArrayDeque<String[]> arrayDeque = new ArrayDeque<String[]>();
        for (String string : list) {
            int n;
            if (string.isBlank()) continue;
            for (n = 0; n < string.length() && string.charAt(n) == '\t'; ++n) {
            }
            String[] stringArray = string.trim().split("\\s+");
            if (stringArray.length == 0) continue;
            while (arrayDeque.size() > n) {
                arrayDeque.pop();
            }
            switch (stringArray[0]) {
                case "CLASS": {
                    String string2;
                    if (stringArray.length < 2) break;
                    Object object = stringArray[1];
                    Object object2 = stringArray.length >= 3 ? stringArray[2] : null;
                    String[] stringArray2 = (String[])arrayDeque.peek();
                    if (stringArray2 != null && !((String)object).contains("/") && !((String)object).startsWith(stringArray2[0] + "$")) {
                        object = stringArray2[0] + "$" + (String)object;
                    }
                    if (object2 != null && stringArray2 != null && !((String)object2).contains("/")) {
                        object2 = stringArray2[1] + "$" + (String)object2;
                    }
                    Object object3 = object2 != null ? object2 : (string2 = stringArray2 != null ? stringArray2[1] + ((String)object).substring(((String)object).lastIndexOf(36)) : object);
                    if (object2 != null) {
                        mappingSet.classes.put((String)object, (String)object2);
                    }
                    arrayDeque.push(new String[]{object, string2});
                    break;
                }
                case "FIELD": 
                case "METHOD": {
                    Object object = (String[])arrayDeque.peek();
                    if (object == null || stringArray.length < 4) break;
                    Object object2 = new MappingSet.Member(object[0], stringArray[1], stringArray[3], stringArray[2]);
                    if (stringArray[0].equals("FIELD")) {
                        mappingSet.fields.add((MappingSet.Member)object2);
                        break;
                    }
                    mappingSet.methods.add((MappingSet.Member)object2);
                    break;
                }
            }
        }
        if (mappingSet.isEmpty()) {
            throw new IOException("No mappings found in Enigma file");
        }
        return mappingSet;
    }
}

