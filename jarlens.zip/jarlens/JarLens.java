/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import dev.jarlens.decompile.DecompilerService;
import dev.jarlens.ui.AppSettings;
import dev.jarlens.ui.MainFrame;
import java.awt.Desktop;
import java.io.File;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicLong;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public final class JarLens {
    private static final AtomicLong LAST_ERROR = new AtomicLong();

    private JarLens() {
    }

    public static void main(String[] stringArray) {
        System.setProperty("apple.awt.application.name", "JarLens");
        System.setProperty("apple.laf.useScreenMenuBar", "true");
        System.setProperty("flatlaf.uiScale.allowScaleDown", "true");
        Thread.setDefaultUncaughtExceptionHandler(JarLens::uncaught);
        AppSettings appSettings = AppSettings.load();
        DecompilerService decompilerService = new DecompilerService(Math.max(2, Runtime.getRuntime().availableProcessors()));
        SwingUtilities.invokeLater(() -> {
            if (appSettings.darkTheme) {
                FlatDarkLaf.setup();
            } else {
                FlatLightLaf.setup();
            }
            UIManager.put("TabbedPane.showTabSeparators", true);
            UIManager.put("Tree.showDefaultIcons", true);
            UIManager.put("ScrollBar.showButtons", false);
            MainFrame mainFrame = new MainFrame(appSettings, decompilerService);
            mainFrame.setVisible(true);
            MainFrame.warmUpInBackground(decompilerService);
            JarLens.installMacOpenHandler(mainFrame);
            if (stringArray.length > 0) {
                mainFrame.open(Path.of(stringArray[0], new String[0]));
            }
        });
    }

    private static void installMacOpenHandler(MainFrame mainFrame) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.APP_OPEN_FILE)) {
                Desktop.getDesktop().setOpenFileHandler(openFilesEvent -> {
                    Iterator<File> iterator = openFilesEvent.getFiles().iterator();
                    if (iterator.hasNext()) {
                        File file = iterator.next();
                        SwingUtilities.invokeLater(() -> mainFrame.open(file.toPath()));
                    }
                });
            }
        }
        catch (RuntimeException runtimeException) {
            // empty catch block
        }
    }

    private static void uncaught(Thread thread, Throwable throwable) {
        throwable.printStackTrace();
        long l = System.currentTimeMillis();
        if (l - LAST_ERROR.getAndSet(l) < 3000L) {
            return;
        }
        String string = throwable instanceof OutOfMemoryError ? "JarLens ran out of memory. Close other jars or start it with more memory, e.g.\njava -Xmx4g -jar JarLens.jar" : "An unexpected error occurred (" + throwable.getClass().getSimpleName() + ": " + throwable.getMessage() + ").\nThe application keeps running; the last action may not have completed.";
        SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(null, string, "JarLens", 0));
    }
}

