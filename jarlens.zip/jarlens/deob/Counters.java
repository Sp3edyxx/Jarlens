/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.deob.Stat;
import java.util.EnumMap;
import java.util.Map;

public final class Counters {
    private final EnumMap<Stat, Integer> values = new EnumMap(Stat.class);

    public void add(Stat stat, int n) {
        if (n != 0) {
            this.values.merge(stat, n, Integer::sum);
        }
    }

    public void inc(Stat stat) {
        this.add(stat, 1);
    }

    public int get(Stat stat) {
        return this.values.getOrDefault((Object)stat, 0);
    }

    public Map<Stat, Integer> asMap() {
        return this.values;
    }

    public boolean isEmpty() {
        return this.values.isEmpty();
    }
}

