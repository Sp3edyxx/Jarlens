/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.transform;

import dev.jarlens.deob.Counters;
import dev.jarlens.deob.Stat;
import dev.jarlens.deob.TransformContext;
import dev.jarlens.deob.Transformer;
import dev.jarlens.deob.transform.Names;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.AnnotationNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.IincInsnNode;
import org.objectweb.asm.tree.InnerClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LocalVariableNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.ParameterNode;
import org.objectweb.asm.tree.VarInsnNode;
import org.objectweb.asm.util.CheckClassAdapter;

public final class DebugInfoCleaner
implements Transformer {
    @Override
    public String name() {
        return "Bogus debug info removal";
    }

    @Override
    public boolean transform(ClassNode classNode, TransformContext transformContext, Counters counters) {
        int n = counters.get(Stat.BOGUS_DEBUG) + counters.get(Stat.HIDDEN_FLAGS);
        if (classNode.attrs != null && !classNode.attrs.isEmpty()) {
            counters.add(Stat.BOGUS_DEBUG, classNode.attrs.size());
            classNode.attrs = null;
        }
        if (classNode.signature != null && !DebugInfoCleaner.validSignature(classNode.signature, 'c')) {
            classNode.signature = null;
            counters.inc(Stat.BOGUS_DEBUG);
        }
        if (classNode.sourceFile != null && !DebugInfoCleaner.plausibleSourceFile(classNode.sourceFile)) {
            classNode.sourceFile = null;
            counters.inc(Stat.BOGUS_DEBUG);
        }
        if (classNode.sourceDebug != null && classNode.sourceDebug.length() > 0 && !classNode.sourceDebug.startsWith("SMAP")) {
            classNode.sourceDebug = null;
            counters.inc(Stat.BOGUS_DEBUG);
        }
        DebugInfoCleaner.cleanAnnotations(classNode.invisibleAnnotations, counters);
        DebugInfoCleaner.cleanInnerClasses(classNode, transformContext, counters);
        if ((classNode.access & 0x1000) != 0 && DebugInfoCleaner.simpleName(classNode.name).indexOf(36) < 0) {
            classNode.access &= 0xFFFFEFFF;
            counters.inc(Stat.HIDDEN_FLAGS);
        }
        Set<String> set = DebugInfoCleaner.lambdaBodies(classNode);
        for (FieldNode object : classNode.fields) {
            if (object.attrs != null && !object.attrs.isEmpty()) {
                counters.add(Stat.BOGUS_DEBUG, object.attrs.size());
                object.attrs = null;
            }
            if (object.signature != null && !DebugInfoCleaner.validSignature(object.signature, 'f')) {
                object.signature = null;
                counters.inc(Stat.BOGUS_DEBUG);
            }
            if ((object.access & 0x1000) != 0 && object.name.indexOf(36) < 0 && (object.access & 0x10) == 0) {
                object.access &= 0xFFFFEFFF;
                counters.inc(Stat.HIDDEN_FLAGS);
            }
            DebugInfoCleaner.cleanAnnotations(object.invisibleAnnotations, counters);
        }
        for (MethodNode methodNode : classNode.methods) {
            if (methodNode.attrs != null && !methodNode.attrs.isEmpty()) {
                counters.add(Stat.BOGUS_DEBUG, methodNode.attrs.size());
                methodNode.attrs = null;
            }
            if (methodNode.signature != null && !DebugInfoCleaner.validMethodSignature(methodNode.signature, methodNode.desc, methodNode.name.equals("<init>"))) {
                methodNode.signature = null;
                counters.inc(Stat.BOGUS_DEBUG);
            }
            DebugInfoCleaner.cleanAnnotations(methodNode.invisibleAnnotations, counters);
            DebugInfoCleaner.cleanFlags(methodNode, set, counters);
            DebugInfoCleaner.cleanLocals(methodNode, counters);
            DebugInfoCleaner.cleanParameters(methodNode, counters);
        }
        return counters.get(Stat.BOGUS_DEBUG) + counters.get(Stat.HIDDEN_FLAGS) != n;
    }

    private static Set<String> lambdaBodies(ClassNode classNode) {
        HashSet<String> hashSet = new HashSet<String>();
        for (MethodNode methodNode : classNode.methods) {
            for (AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst(); abstractInsnNode != null; abstractInsnNode = abstractInsnNode.getNext()) {
                if (!(abstractInsnNode instanceof InvokeDynamicInsnNode)) continue;
                InvokeDynamicInsnNode invokeDynamicInsnNode = (InvokeDynamicInsnNode)abstractInsnNode;
                for (Object object : invokeDynamicInsnNode.bsmArgs) {
                    Handle handle;
                    if (!(object instanceof Handle) || !(handle = (Handle)object).getOwner().equals(classNode.name)) continue;
                    hashSet.add(handle.getName() + handle.getDesc());
                }
            }
        }
        return hashSet;
    }

    private static void cleanFlags(MethodNode methodNode, Set<String> set, Counters counters) {
        Type[] typeArray;
        if ((methodNode.access & 0x80) != 0 && ((typeArray = Type.getArgumentTypes(methodNode.desc)).length == 0 || typeArray[typeArray.length - 1].getSort() != 9)) {
            methodNode.access &= 0xFFFFFF7F;
            counters.inc(Stat.HIDDEN_FLAGS);
        }
        boolean bl = (methodNode.access & 0x40) != 0;
        boolean bl2 = bl;
        if (bl && !DebugInfoCleaner.looksLikeBridge(methodNode)) {
            methodNode.access &= 0xFFFFEFBF;
            counters.inc(Stat.HIDDEN_FLAGS);
            return;
        }
        if (!(bl || (methodNode.access & 0x1000) == 0 || methodNode.name.indexOf(36) >= 0 || methodNode.name.startsWith("<") || set.contains(methodNode.name + methodNode.desc))) {
            methodNode.access &= 0xFFFFEFFF;
            counters.inc(Stat.HIDDEN_FLAGS);
        }
    }

    private static boolean looksLikeBridge(MethodNode methodNode) {
        int n = Type.getArgumentTypes(methodNode.desc).length;
        for (AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst(); abstractInsnNode != null; abstractInsnNode = abstractInsnNode.getNext()) {
            if (!(abstractInsnNode instanceof MethodInsnNode)) continue;
            MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
            if (!methodInsnNode.name.equals(methodNode.name) || Type.getArgumentTypes(methodInsnNode.desc).length != n) continue;
            return true;
        }
        return false;
    }

    private static void cleanLocals(MethodNode methodNode, Counters counters) {
        if (methodNode.localVariables == null || methodNode.localVariables.isEmpty()) {
            return;
        }
        Iterator<LocalVariableNode> iterator = methodNode.localVariables.iterator();
        while (iterator.hasNext()) {
            LocalVariableNode localVariableNode = iterator.next();
            boolean bl = "this".equals(localVariableNode.name) && localVariableNode.index == 0 && (methodNode.access & 8) == 0;
            if (bl || localVariableNode.name != null && Names.isValidJavaIdentifier(localVariableNode.name) && !Names.isConfusing(localVariableNode.name)) continue;
            iterator.remove();
            counters.inc(Stat.BOGUS_DEBUG);
        }
        if (methodNode.localVariables.isEmpty()) {
            methodNode.localVariables = null;
            return;
        }
        if (DebugInfoCleaner.localsAreBogus(methodNode)) {
            counters.add(Stat.BOGUS_DEBUG, methodNode.localVariables.size());
            methodNode.localVariables = null;
            methodNode.visibleLocalVariableAnnotations = null;
            methodNode.invisibleLocalVariableAnnotations = null;
        }
    }

    private static boolean localsAreBogus(MethodNode methodNode) {
        Object object;
        Object object2;
        List<LocalVariableNode> list;
        InsnList insnList = methodNode.instructions;
        HashMap<LabelNode, Integer> hashMap = new HashMap<LabelNode, Integer>();
        int n = 0;
        AbstractInsnNode abstractInsnNode = insnList.getFirst();
        while (abstractInsnNode != null) {
            if (abstractInsnNode instanceof LabelNode) {
                list = (LabelNode)abstractInsnNode;
                hashMap.put((LabelNode)((Object)list), n);
            }
            abstractInsnNode = abstractInsnNode.getNext();
            ++n;
        }
        for (LocalVariableNode localVariableNode : methodNode.localVariables) {
            Type type;
            try {
                type = Type.getType(localVariableNode.desc);
            }
            catch (RuntimeException runtimeException) {
                return true;
            }
            if (type.getSort() == 11 || type.getSort() == 0) {
                return true;
            }
            if (localVariableNode.index < 0 || localVariableNode.index + type.getSize() > methodNode.maxLocals) {
                return true;
            }
            object2 = (Integer)hashMap.get(localVariableNode.start);
            object = (Integer)hashMap.get(localVariableNode.end);
            if (object2 == null || object == null || (Integer)object2 > (Integer)object) {
                return true;
            }
            if (localVariableNode.signature != null && !DebugInfoCleaner.validSignature(localVariableNode.signature, 'f')) {
                return true;
            }
            if (DebugInfoCleaner.usageMatches(insnList, hashMap, localVariableNode, type, (Integer)object2, (Integer)object)) continue;
            return true;
        }
        list = methodNode.localVariables;
        for (int i = 0; i < list.size(); ++i) {
            for (int j = i + 1; j < list.size(); ++j) {
                object2 = list.get(i);
                object = list.get(j);
                if (((LocalVariableNode)object2).index != ((LocalVariableNode)object).index) continue;
                int n2 = (Integer)hashMap.get(((LocalVariableNode)object2).start);
                int n3 = (Integer)hashMap.get(((LocalVariableNode)object2).end);
                int n4 = (Integer)hashMap.get(((LocalVariableNode)object).start);
                int n5 = (Integer)hashMap.get(((LocalVariableNode)object).end);
                if (n2 >= n5 || n4 >= n3 || ((LocalVariableNode)object2).desc.equals(((LocalVariableNode)object).desc)) continue;
                return true;
            }
        }
        return false;
    }

    private static boolean usageMatches(InsnList insnList, Map<LabelNode, Integer> map, LocalVariableNode localVariableNode, Type type, int n, int n2) {
        int n3 = DebugInfoCleaner.kind(type);
        int n4 = n;
        for (AbstractInsnNode abstractInsnNode = localVariableNode.start; abstractInsnNode != null && n4 < n2; abstractInsnNode = abstractInsnNode.getNext(), ++n4) {
            if (abstractInsnNode instanceof VarInsnNode) {
                int n5;
                VarInsnNode varInsnNode = (VarInsnNode)abstractInsnNode;
                if (varInsnNode.var != localVariableNode.index || varInsnNode.getOpcode() == 169) continue;
                int n6 = varInsnNode.getOpcode();
                int n7 = n5 = n6 >= 54 ? n6 - 54 : n6 - 21;
                if (n5 == n3) continue;
                return false;
            }
            if (!(abstractInsnNode instanceof IincInsnNode)) continue;
            IincInsnNode iincInsnNode = (IincInsnNode)abstractInsnNode;
            if (iincInsnNode.var != localVariableNode.index || n3 == 0) continue;
            return false;
        }
        return true;
    }

    private static int kind(Type type) {
        return switch (type.getSort()) {
            case 1, 2, 3, 4, 5 -> 0;
            case 7 -> 1;
            case 6 -> 2;
            case 8 -> 3;
            default -> 4;
        };
    }

    private static void cleanParameters(MethodNode methodNode, Counters counters) {
        if (methodNode.parameters == null) {
            return;
        }
        boolean bl = methodNode.parameters.size() > Type.getArgumentTypes(methodNode.desc).length + 2;
        for (ParameterNode parameterNode : methodNode.parameters) {
            if (parameterNode.name == null || Names.isValidJavaIdentifier(parameterNode.name) && !Names.isConfusing(parameterNode.name)) continue;
            bl = true;
        }
        if (bl) {
            counters.add(Stat.BOGUS_DEBUG, methodNode.parameters.size());
            methodNode.parameters = null;
        }
    }

    private static void cleanAnnotations(List<AnnotationNode> list, Counters counters) {
        if (list == null) {
            return;
        }
        Iterator<AnnotationNode> iterator = list.iterator();
        while (iterator.hasNext()) {
            boolean bl;
            AnnotationNode annotationNode = iterator.next();
            try {
                Type type = Type.getType(annotationNode.desc);
                bl = type.getSort() == 10 && Names.isValidInternalName(type.getInternalName());
            }
            catch (RuntimeException runtimeException) {
                bl = false;
            }
            if (bl) continue;
            iterator.remove();
            counters.inc(Stat.BOGUS_DEBUG);
        }
    }

    private static void cleanInnerClasses(ClassNode classNode, TransformContext transformContext, Counters counters) {
        Iterator<InnerClassNode> iterator = classNode.innerClasses.iterator();
        while (iterator.hasNext()) {
            InnerClassNode innerClassNode = iterator.next();
            if (!innerClassNode.name.equals(classNode.name)) continue;
            boolean bl = true;
            if (innerClassNode.outerName != null) {
                bl = transformContext.isJarClass(innerClassNode.outerName) && transformContext.index().innerClassesListedBy(innerClassNode.outerName).contains(classNode.name);
            } else if (classNode.outerClass != null) {
                bl = transformContext.isJarClass(classNode.outerClass);
            }
            if (bl) continue;
            iterator.remove();
            classNode.outerClass = null;
            classNode.outerMethod = null;
            classNode.outerMethodDesc = null;
            counters.inc(Stat.BOGUS_DEBUG);
        }
        if (classNode.outerClass != null && !transformContext.isJarClass(classNode.outerClass)) {
            classNode.outerClass = null;
            classNode.outerMethod = null;
            classNode.outerMethodDesc = null;
            counters.inc(Stat.BOGUS_DEBUG);
        }
    }

    private static boolean plausibleSourceFile(String string) {
        int n;
        if (string.isEmpty() || string.length() > 120) {
            return false;
        }
        for (n = 0; n < string.length(); ++n) {
            char c = string.charAt(n);
            if (c >= ' ' && c <= '~') continue;
            return false;
        }
        n = string.lastIndexOf(46);
        return n > 0 && Names.isValidJavaIdentifier(string.substring(0, n).replace('-', '_'));
    }

    private static boolean validSignature(String string, char c) {
        try {
            if (c == 'c') {
                CheckClassAdapter.checkClassSignature(string);
            } else {
                CheckClassAdapter.checkFieldSignature(string);
            }
            return true;
        }
        catch (RuntimeException runtimeException) {
            return false;
        }
    }

    private static boolean validMethodSignature(String string, String string2, boolean bl) {
        try {
            CheckClassAdapter.checkMethodSignature(string);
        }
        catch (RuntimeException runtimeException) {
            return false;
        }
        int n = DebugInfoCleaner.countSignatureParams(string);
        int n2 = Type.getArgumentTypes(string2).length;
        if (n < 0) {
            return false;
        }
        return bl ? n <= n2 : n == n2;
    }

    private static int countSignatureParams(String string) {
        int n = string.indexOf(40);
        int n2 = string.indexOf(41);
        if (n < 0 || n2 < n) {
            return -1;
        }
        int n3 = 0;
        block0: for (int i = n + 1; i < n2; ++i) {
            char c = string.charAt(i);
            if (c == '[') continue;
            ++n3;
            if (c != 'L' && c != 'T') continue;
            int n4 = 0;
            while (i < n2) {
                char c2 = string.charAt(i);
                if (c2 == '<') {
                    ++n4;
                } else if (c2 == '>') {
                    --n4;
                } else if (c2 == ';' && n4 == 0) continue block0;
                ++i;
            }
        }
        return n3;
    }

    private static String simpleName(String string) {
        return string.substring(string.lastIndexOf(47) + 1);
    }
}

