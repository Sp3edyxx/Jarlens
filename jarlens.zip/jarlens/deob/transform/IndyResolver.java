/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.transform;

import dev.jarlens.deob.Counters;
import dev.jarlens.deob.JarIndex;
import dev.jarlens.deob.Stat;
import dev.jarlens.deob.TransformContext;
import dev.jarlens.deob.Transformer;
import dev.jarlens.deob.emu.EmuObjects;
import dev.jarlens.deob.emu.Emulator;
import java.util.ArrayList;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

public final class IndyResolver
implements Transformer {
    private ThreadLocal<Emulator> emulators;
    private TransformContext ctx;

    @Override
    public String name() {
        return "invokedynamic resolution";
    }

    @Override
    public void prepare(TransformContext transformContext) {
        this.ctx = transformContext;
        this.emulators = ThreadLocal.withInitial(() -> new Emulator(transformContext.snapshot::get, transformContext.hierarchy, transformContext.settings.emulatorInstructionLimit, transformContext.settings.emulatorClinitLimit));
    }

    @Override
    public boolean mayApply(byte[] byArray) {
        ClassReader classReader = new ClassReader(byArray);
        for (int i = 1; i < classReader.getItemCount(); ++i) {
            int n = classReader.getItem(i);
            if (n <= 0 || byArray[n - 1] != 18) continue;
            return true;
        }
        return false;
    }

    @Override
    public boolean transform(ClassNode classNode, TransformContext transformContext, Counters counters) {
        boolean bl = false;
        for (MethodNode methodNode : classNode.methods) {
            InvokeDynamicInsnNode invokeDynamicInsnNode;
            Object object;
            ArrayList<InvokeDynamicInsnNode> arrayList = new ArrayList<InvokeDynamicInsnNode>();
            for (object = methodNode.instructions.getFirst(); object != null; object = ((AbstractInsnNode)object).getNext()) {
                if (!(object instanceof InvokeDynamicInsnNode)) continue;
                invokeDynamicInsnNode = (InvokeDynamicInsnNode)object;
                if (!transformContext.isJarClass(invokeDynamicInsnNode.bsm.getOwner())) continue;
                arrayList.add(invokeDynamicInsnNode);
            }
            object = arrayList.iterator();
            while (object.hasNext()) {
                invokeDynamicInsnNode = (InvokeDynamicInsnNode)object.next();
                EmuObjects.EmuMethodHandle emuMethodHandle = this.resolve(classNode.name, invokeDynamicInsnNode);
                InsnList insnList = emuMethodHandle == null ? null : this.replacement(classNode, methodNode, invokeDynamicInsnNode, emuMethodHandle);
                InsnList insnList2 = insnList;
                if (insnList == null) {
                    counters.inc(Stat.INDY_FAILED);
                    continue;
                }
                methodNode.instructions.insertBefore((AbstractInsnNode)invokeDynamicInsnNode, insnList);
                methodNode.instructions.remove(invokeDynamicInsnNode);
                counters.inc(Stat.INDY_RESOLVED);
                bl = true;
            }
        }
        return bl;
    }

    private EmuObjects.EmuMethodHandle resolve(String string, InvokeDynamicInsnNode invokeDynamicInsnNode) {
        Emulator emulator = this.emulators.get();
        String string5 = invokeDynamicInsnNode.bsm.getOwner();
        JarIndex jarIndex = this.ctx.index();
        emulator.setStaticReadPolicy((string2, string3, string4) -> string2.equals(string5) || jarIndex.isEffectivelyFinalStatic(new JarIndex.FieldKey(string2, string3, string4)));
        try {
            EmuObjects.EmuCallSite emuCallSite = emulator.invokeBootstrap(string, invokeDynamicInsnNode.bsm, invokeDynamicInsnNode.name, invokeDynamicInsnNode.desc, invokeDynamicInsnNode.bsmArgs);
            return emuCallSite.target();
        }
        catch (RuntimeException | StackOverflowError throwable) {
            return null;
        }
    }

    private InsnList replacement(ClassNode classNode, MethodNode methodNode, InvokeDynamicInsnNode invokeDynamicInsnNode, EmuObjects.EmuMethodHandle emuMethodHandle) {
        int n;
        Type[] typeArray;
        Type type = Type.getMethodType(invokeDynamicInsnNode.desc);
        Type type2 = Type.getMethodType(emuMethodHandle.invocationType());
        Type[] typeArray2 = type.getArgumentTypes();
        if (typeArray2.length != (typeArray = type2.getArgumentTypes()).length) {
            return null;
        }
        boolean[] blArray = new boolean[typeArray2.length];
        boolean bl = false;
        for (int i = 0; i < typeArray2.length; ++i) {
            int n2 = this.compatible(typeArray2[i], typeArray[i]);
            if (n2 < 0) {
                return null;
            }
            blArray[i] = n2 == 1;
            bl |= blArray[i];
        }
        Type type3 = type2.getReturnType();
        Type type4 = type.getReturnType();
        if (type4.getSort() == 0) {
            n = type3.getSort() == 0 ? 0 : 2;
        } else {
            if (type3.getSort() == 0) {
                return null;
            }
            n = this.compatible(type3, type4);
        }
        if (n < 0) {
            return null;
        }
        AbstractInsnNode abstractInsnNode = this.callInsn(classNode, emuMethodHandle);
        if (abstractInsnNode == null) {
            return null;
        }
        InsnList insnList = new InsnList();
        if (bl) {
            int n3;
            int n4 = methodNode.maxLocals;
            int[] nArray = new int[typeArray2.length];
            int n5 = n4;
            for (n3 = 0; n3 < typeArray2.length; ++n3) {
                nArray[n3] = n5;
                n5 += typeArray2[n3].getSize();
            }
            for (n3 = typeArray2.length - 1; n3 >= 0; --n3) {
                insnList.add(new VarInsnNode(typeArray2[n3].getOpcode(54), nArray[n3]));
            }
            for (n3 = 0; n3 < typeArray2.length; ++n3) {
                insnList.add(new VarInsnNode(typeArray2[n3].getOpcode(21), nArray[n3]));
                if (!blArray[n3]) continue;
                insnList.add(new TypeInsnNode(192, IndyResolver.internal(typeArray[n3])));
            }
            methodNode.maxLocals = n5;
        }
        insnList.add(abstractInsnNode);
        if (n == 1) {
            insnList.add(new TypeInsnNode(192, IndyResolver.internal(type4)));
        }
        if (n == 2) {
            insnList.add(new InsnNode(type3.getSize() == 2 ? 88 : 87));
        }
        return insnList;
    }

    private AbstractInsnNode callInsn(ClassNode classNode, EmuObjects.EmuMethodHandle emuMethodHandle) {
        boolean bl = emuMethodHandle.itf || this.ctx.hierarchy.isInterface(emuMethodHandle.owner);
        switch (emuMethodHandle.kind) {
            case 6: {
                return new MethodInsnNode(184, emuMethodHandle.owner, emuMethodHandle.name, emuMethodHandle.desc, bl);
            }
            case 5: 
            case 9: {
                return new MethodInsnNode(bl ? 185 : 182, emuMethodHandle.owner, emuMethodHandle.name, emuMethodHandle.desc, bl);
            }
            case 7: {
                if (!emuMethodHandle.owner.equals(classNode.name) || emuMethodHandle.name.startsWith("<")) {
                    return null;
                }
                return new MethodInsnNode(183, emuMethodHandle.owner, emuMethodHandle.name, emuMethodHandle.desc, bl);
            }
            case 1: {
                return new FieldInsnNode(180, emuMethodHandle.owner, emuMethodHandle.name, emuMethodHandle.desc);
            }
            case 2: {
                return new FieldInsnNode(178, emuMethodHandle.owner, emuMethodHandle.name, emuMethodHandle.desc);
            }
            case 3: {
                return new FieldInsnNode(181, emuMethodHandle.owner, emuMethodHandle.name, emuMethodHandle.desc);
            }
            case 4: {
                return new FieldInsnNode(179, emuMethodHandle.owner, emuMethodHandle.name, emuMethodHandle.desc);
            }
        }
        return null;
    }

    private int compatible(Type type, Type type2) {
        if (type.equals(type2)) {
            return 0;
        }
        boolean bl = type.getSort() >= 9;
        boolean bl2 = type2.getSort() >= 9;
        boolean bl3 = bl2;
        if (!bl || !bl2) {
            boolean bl4 = type.getSort() >= 1 && type.getSort() <= 5;
            boolean bl5 = type2.getSort() >= 1 && type2.getSort() <= 5;
            return bl4 && bl5 ? 0 : -1;
        }
        if (type2.getSort() == 10 && type2.getInternalName().equals("java/lang/Object")) {
            return 0;
        }
        if (type.getSort() == 10 && type2.getSort() == 10) {
            if (this.ctx.hierarchy.isInterface(type2.getInternalName())) {
                return 0;
            }
            Boolean bl6 = this.ctx.hierarchy.isSubtypeOf(type.getInternalName(), type2.getInternalName());
            return Boolean.TRUE.equals(bl6) ? 0 : 1;
        }
        return 1;
    }

    private static String internal(Type type) {
        return type.getSort() == 9 ? type.getDescriptor() : type.getInternalName();
    }
}

