/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.transform;

import java.util.Locale;
import java.util.Set;

public final class Names {
    private static final Set<String> KEYWORDS = Set.of("abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float", "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void", "volatile", "while", "true", "false", "null", "_");
    private static final Set<String> RESTRICTED_TYPE_NAMES = Set.of("var", "yield", "record", "sealed", "permits", "non-sealed");
    private static final Set<String> WINDOWS_RESERVED = Set.of("con", "prn", "aux", "nul", "clock$", "com0", "com1", "com2", "com3", "com4", "com5", "com6", "com7", "com8", "com9", "lpt0", "lpt1", "lpt2", "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9");

    private Names() {
    }

    public static boolean isKeyword(String string) {
        return KEYWORDS.contains(string);
    }

    public static boolean isValidJavaIdentifier(String string) {
        int n;
        if (string == null || string.isEmpty() || Names.isKeyword(string)) {
            return false;
        }
        if (!Character.isJavaIdentifierStart(string.codePointAt(0))) {
            return false;
        }
        for (int i = 0; i < string.length(); i += Character.charCount(n)) {
            n = string.codePointAt(i);
            if (Character.isJavaIdentifierPart(n) && !Character.isIdentifierIgnorable(n)) continue;
            return false;
        }
        return true;
    }

    public static boolean isAscii(String string) {
        for (int i = 0; i < string.length(); ++i) {
            if (string.charAt(i) <= '~' && string.charAt(i) >= ' ') continue;
            return false;
        }
        return true;
    }

    public static boolean isConfusing(String string) {
        if (string.length() > 80) {
            return string.indexOf(36) < 0;
        }
        if (string.length() < 3) {
            return false;
        }
        boolean bl = true;
        boolean bl2 = true;
        for (int i = 0; i < string.length(); ++i) {
            char c = string.charAt(i);
            if (c != 'I' && c != 'l' && c != '1' && c != 'i' && c != '|') {
                bl = false;
            }
            if (c == 'O' || c == '0' || c == 'o' || c == 'Q') continue;
            bl2 = false;
        }
        if (bl) {
            return string.chars().distinct().count() >= 2L;
        }
        return bl2 && string.chars().distinct().count() >= 2L;
    }

    public static boolean isWindowsReserved(String string) {
        String string2 = string.toLowerCase(Locale.ROOT);
        int n = string2.indexOf(46);
        if (n >= 0) {
            string2 = string2.substring(0, n);
        }
        return WINDOWS_RESERVED.contains(string2) || string.endsWith(".") || string.endsWith(" ");
    }

    public static boolean isShortObfuscatedName(String string) {
        if (string.isEmpty() || string.length() > 3) {
            return false;
        }
        for (int i = 0; i < string.length(); ++i) {
            char c = string.charAt(i);
            if (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z') continue;
            return false;
        }
        return true;
    }

    public static boolean memberNeedsRename(String string, boolean bl) {
        if (string.startsWith("<")) {
            return false;
        }
        return !Names.isValidJavaIdentifier(string) || !Names.isAscii(string) || Names.isConfusing(string) || bl && Names.isShortObfuscatedName(string);
    }

    public static boolean packageNeedsRename(String string, boolean bl) {
        return !Names.isValidJavaIdentifier(string) || !Names.isAscii(string) || Names.isConfusing(string) || Names.isWindowsReserved(string) || bl && Names.isShortObfuscatedName(string) && string.length() <= 2;
    }

    public static boolean classSegmentNeedsRename(String string, boolean bl, boolean bl2) {
        if (string.equals("module-info") || string.equals("package-info")) {
            return false;
        }
        if (!bl && string.isEmpty()) {
            return false;
        }
        if (!bl) {
            int n;
            for (n = 0; n < string.length() && Character.isDigit(string.charAt(n)); ++n) {
            }
            if (n == string.length()) {
                return false;
            }
            if (n > 0) {
                string = string.substring(n);
            }
        }
        return !Names.isValidJavaIdentifier(string) || !Names.isAscii(string) || Names.isConfusing(string) || Names.isWindowsReserved(string) || RESTRICTED_TYPE_NAMES.contains(string) || bl2 && Names.isShortObfuscatedName(string);
    }

    public static boolean isValidInternalName(String string) {
        if (string == null || string.isEmpty()) {
            return false;
        }
        for (String string2 : string.split("/", -1)) {
            if (string2.isEmpty()) {
                return false;
            }
            for (int i = 0; i < string2.length(); ++i) {
                char c = string2.charAt(i);
                if (c != '.' && c != ';' && c != '[' && c != '<' && c != '>') continue;
                return false;
            }
        }
        return true;
    }
}

