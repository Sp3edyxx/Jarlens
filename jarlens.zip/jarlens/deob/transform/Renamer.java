/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.transform;

import dev.jarlens.core.ClassHierarchy;
import dev.jarlens.deob.HierarchyRemapper;
import dev.jarlens.deob.transform.Names;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.MethodNode;

public final class Renamer {
    private boolean renameShort;
    private int classCounter;
    private int methodCounter;
    private int fieldCounter;
    private int packageCounter;

    public Renamer renameShortNames(boolean bl) {
        this.renameShort = bl;
        return this;
    }

    public HierarchyRemapper computeMapping(Map<String, byte[]> map, ClassHierarchy classHierarchy) {
        TreeMap<String, ClassNode> treeMap = new TreeMap<String, ClassNode>();
        for (Map.Entry<String, byte[]> entry : map.entrySet()) {
            try {
                ClassNode classNode = new ClassNode();
                new ClassReader(entry.getValue()).accept(classNode, 7);
                treeMap.put(entry.getKey(), classNode);
            }
            catch (Exception exception) {}
        }
        HierarchyRemapper hierarchyRemapper = new HierarchyRemapper(classHierarchy);
        this.renameClasses(treeMap, hierarchyRemapper);
        this.renameMethods(treeMap, classHierarchy, hierarchyRemapper);
        this.renameFields(treeMap, hierarchyRemapper);
        return hierarchyRemapper;
    }

    /*
     * WARNING - void declaration
     */
    private void renameClasses(Map<String, ClassNode> map, HierarchyRemapper hierarchyRemapper) {
        HashSet<String> hashSet = new HashSet<String>();
        for (String object2 : map.keySet()) {
            hashSet.add(object2.toLowerCase(Locale.ROOT));
        }
        HashMap hashMap = new HashMap();
        HashMap<String, Object> hashMap2 = new HashMap<String, Object>();
        HashMap<String, Set> hashMap3 = new HashMap<String, Set>();
        HashSet<String> hashSet2 = new HashSet<String>();
        int n = 0;
        for (String string2 : map.keySet()) {
            StringBuilder stringBuilder;
            String[] stringArray;
            int n2 = string2.lastIndexOf(47);
            String string3 = n2 < 0 ? "" : string2.substring(0, n2);
            String string4 = string2.substring(n2 + 1);
            String string5 = (String)hashMap.get(string3);
            if (string5 == null) {
                stringArray = new StringBuilder();
                stringBuilder = new StringBuilder();
                for (String string6 : string3.isEmpty() ? new String[]{} : string3.split("/")) {
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append('/');
                    }
                    stringBuilder.append(string6);
                    String string7 = stringBuilder.toString();
                    Object object = (String)hashMap.get(string7);
                    if (object == null) {
                        String string8 = stringArray.toString();
                        Set set = hashMap3.computeIfAbsent(string8, string -> new HashSet());
                        String string9 = string6;
                        if (Names.packageNeedsRename(string6, this.renameShort) || set.contains(string6.toLowerCase(Locale.ROOT))) {
                            while (set.contains(string9 = String.format("pkg_%03d", ++this.packageCounter))) {
                            }
                            ++n;
                        }
                        set.add(string9.toLowerCase(Locale.ROOT));
                        object = (String)(string8.isEmpty() ? "" : string8 + "/") + string9;
                        hashMap.put(string7, object);
                    }
                    stringArray.setLength(0);
                    stringArray.append((String)object);
                }
                string5 = stringArray.toString();
                hashMap.put(string3, string5);
            }
            stringArray = string4.split("\\$", -1);
            stringBuilder = new StringBuilder();
            StringBuilder stringBuilder2 = new StringBuilder((String)(string3.isEmpty() ? "" : string3 + "/"));
            for (int i = 0; i < stringArray.length; ++i) {
                void var20_30;
                if (i > 0) {
                    stringBuilder2.append('$');
                    stringBuilder.append('$');
                }
                stringBuilder2.append(stringArray[i]);
                String string11 = stringBuilder2.toString();
                String string10 = (String)hashMap2.get(string11);
                if (string10 == null) {
                    void var20_29;
                    String string12 = stringArray[i];
                    if (Names.classSegmentNeedsRename(stringArray[i], i == 0, this.renameShort)) {
                        String string13 = this.nextClassName(hashSet, string5);
                    }
                    hashMap2.put(string11, var20_29);
                }
                stringBuilder.append((String)var20_30);
            }
            String i = (String)(string5.isEmpty() ? "" : string5 + "/") + String.valueOf(stringBuilder);
            if (!hashSet2.add(i.toLowerCase(Locale.ROOT))) {
                String string14 = this.nextClassName(hashSet, string5);
                Object object = i.contains("$") ? i.substring(0, i.lastIndexOf(36) + 1) : (string5.isEmpty() ? "" : string5 + "/");
                i = (String)object + string14;
                hashSet2.add(i.toLowerCase(Locale.ROOT));
                hashMap2.put(string2, string14);
            }
            if (i.equals(string2)) continue;
            hierarchyRemapper.mapClass(string2, i);
            ++hierarchyRemapper.renamedClassCount;
        }
        hierarchyRemapper.renamedPackageCount = n;
    }

    private String nextClassName(Set<String> set, String string) {
        String string2;
        do {
            string2 = String.format("class_%03d", ++this.classCounter);
        } while (set.contains(((String)(string.isEmpty() ? "" : string + "/") + string2).toLowerCase(Locale.ROOT)));
        return string2;
    }

    private void renameMethods(Map<String, ClassNode> map, ClassHierarchy classHierarchy, HierarchyRemapper hierarchyRemapper) {
        HashMap<String, String> hashMap = new HashMap<String, String>();
        for (String iterator : map.keySet()) {
            hashMap.put(iterator, iterator);
        }
        for (ClassNode classNode : map.values()) {
            if (classNode.superName != null && map.containsKey(classNode.superName)) {
                Renamer.union(hashMap, classNode.name, classNode.superName);
            }
            for (String string2 : classNode.interfaces) {
                if (!map.containsKey(string2)) continue;
                Renamer.union(hashMap, classNode.name, string2);
            }
        }
        TreeMap treeMap = new TreeMap();
        for (ClassNode classNode : map.values()) {
            treeMap.computeIfAbsent(Renamer.find(hashMap, classNode.name), string -> new ArrayList()).add(classNode);
        }
        for (List list : treeMap.values()) {
            String string3;
            Iterator iterator2;
            String string2;
            Set<String> set = Renamer.libraryMethods(list, map, classHierarchy);
            HashSet<String> hashSet = new HashSet<String>();
            HashSet<CallSite> hashSet2 = new HashSet<CallSite>();
            TreeMap<String, List> treeMap2 = new TreeMap<String, List>();
            HashMap<String, Set> hashMap2 = new HashMap<String, Set>();
            for (Iterator iterator2 : list) {
                for (MethodNode methodNode : ((ClassNode)((Object)iterator2)).methods) {
                    hashSet.add(methodNode.name);
                    String string4 = methodNode.name + methodNode.desc;
                    treeMap2.computeIfAbsent(string4, string -> new ArrayList()).add(iterator2);
                    if ((methodNode.access & 0x100) != 0) {
                        hashSet2.add((CallSite)((Object)string4));
                    }
                    if ((methodNode.access & 0x1040) != 0) continue;
                    string3 = methodNode.desc.substring(0, methodNode.desc.indexOf(41) + 1);
                    hashMap2.computeIfAbsent(((ClassNode)((Object)iterator2)).name + "\u0000" + methodNode.name + "\u0000" + string3, string -> new HashSet()).add(methodNode.desc);
                }
            }
            HashSet hashSet3 = new HashSet();
            for (Map.Entry entry : hashMap2.entrySet()) {
                if (((Set)entry.getValue()).size() < 2) continue;
                ArrayList arrayList = new ArrayList((Collection)entry.getValue());
                arrayList.sort(null);
                string2 = ((String)entry.getKey()).split("\u0000", 3)[1];
                for (int i = 1; i < arrayList.size(); ++i) {
                    hashSet3.add(string2 + (String)arrayList.get(i));
                }
            }
            iterator2 = treeMap2.entrySet().iterator();
            while (iterator2.hasNext()) {
                String string5;
                boolean bl;
                Map.Entry entry = iterator2.next();
                string3 = (String)entry.getKey();
                string2 = string3.substring(0, string3.indexOf(40));
                String string6 = string3.substring(string3.indexOf(40));
                if (string2.startsWith("<") || !(bl = Names.memberNeedsRename(string2, this.renameShort) || hashSet3.contains(string3)) || set.contains(string3) || hashSet2.contains(string3)) continue;
                while (hashSet.contains(string5 = String.format("method_%03x", ++this.methodCounter))) {
                }
                hashSet.add(string5);
                for (ClassNode classNode : (List)entry.getValue()) {
                    hierarchyRemapper.mapMethod(classNode.name, string2, string6, string5);
                }
            }
        }
    }

    private static Set<String> libraryMethods(List<ClassNode> list, Map<String, ClassNode> map, ClassHierarchy classHierarchy) {
        HashSet<String> hashSet = new HashSet<String>();
        HashSet<String> hashSet2 = new HashSet<String>();
        for (ClassNode classNode : list) {
            for (String string : classHierarchy.allSupertypes(classNode.name)) {
                ClassHierarchy.ClassInfo classInfo;
                if (map.containsKey(string) || !hashSet2.add(string) || (classInfo = classHierarchy.get(string)) == null) continue;
                hashSet.addAll(classInfo.methods.keySet());
            }
        }
        return hashSet;
    }

    private static String find(Map<String, String> map, String string) {
        String string2 = map.get(string);
        while (!string2.equals(string)) {
            String string3 = map.get(string2);
            map.put(string, string3);
            string = string2;
            string2 = string3;
        }
        return string;
    }

    private static void union(Map<String, String> map, String string, String string2) {
        String string3;
        String string4 = Renamer.find(map, string);
        if (string4.equals(string3 = Renamer.find(map, string2))) {
            return;
        }
        if (string4.compareTo(string3) < 0) {
            map.put(string3, string4);
        } else {
            map.put(string4, string3);
        }
    }

    private void renameFields(Map<String, ClassNode> map, HierarchyRemapper hierarchyRemapper) {
        for (ClassNode classNode : map.values()) {
            HashSet<Object> hashSet = new HashSet<Object>();
            HashSet<String> hashSet2 = new HashSet<String>();
            for (FieldNode fieldNode : classNode.fields) {
                hashSet.add(fieldNode.name);
            }
            for (FieldNode fieldNode : classNode.fields) {
                String string;
                boolean bl = !hashSet2.add(fieldNode.name);
                boolean bl2 = bl;
                if (!bl && !Names.memberNeedsRename(fieldNode.name, this.renameShort)) continue;
                while (hashSet.contains(string = "field_" + ++this.fieldCounter)) {
                }
                hashSet.add(string);
                hierarchyRemapper.mapField(classNode.name, fieldNode.name, fieldNode.desc, string);
            }
        }
    }
}

