/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.transform;

import dev.jarlens.deob.ClassUtil;
import dev.jarlens.deob.Constants;
import dev.jarlens.deob.Counters;
import dev.jarlens.deob.Stat;
import dev.jarlens.deob.TransformContext;
import dev.jarlens.deob.Transformer;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.IincInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LineNumberNode;
import org.objectweb.asm.tree.LookupSwitchInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TableSwitchInsnNode;
import org.objectweb.asm.tree.TryCatchBlockNode;
import org.objectweb.asm.tree.VarInsnNode;
import org.objectweb.asm.tree.analysis.Analyzer;
import org.objectweb.asm.tree.analysis.BasicInterpreter;
import org.objectweb.asm.tree.analysis.BasicValue;
import org.objectweb.asm.tree.analysis.Frame;

public final class JunkCodeRemover
implements Transformer {
    @Override
    public String name() {
        return "Junk & dead code removal";
    }

    @Override
    public boolean transform(ClassNode classNode, TransformContext transformContext, Counters counters) {
        boolean bl = false;
        block0: for (MethodNode methodNode : classNode.methods) {
            if (methodNode.instructions.size() == 0) continue;
            for (int i = 0; i < 10; ++i) {
                boolean bl2 = false;
                bl2 |= JunkCodeRemover.peephole(methodNode, counters);
                bl2 |= JunkCodeRemover.removeDeadConstantStores(methodNode, counters);
                bl2 |= JunkCodeRemover.removeDiscardedExpressions(methodNode, counters);
                bl2 |= JunkCodeRemover.removeIdentityArithmetic(methodNode, counters);
                bl2 |= JunkCodeRemover.removeFakeHandlers(methodNode, counters);
                bl2 |= JunkCodeRemover.removeDeadCode(classNode.name, methodNode, counters);
                if (!(bl2 |= JunkCodeRemover.removeEmptyTryBlocks(methodNode))) continue block0;
                bl = true;
            }
        }
        return bl;
    }

    private static boolean peephole(MethodNode methodNode, Counters counters) {
        InsnList insnList = methodNode.instructions;
        boolean bl = false;
        AbstractInsnNode abstractInsnNode = insnList.getFirst();
        while (abstractInsnNode != null) {
            AbstractInsnNode abstractInsnNode2;
            AbstractInsnNode abstractInsnNode3;
            AbstractInsnNode abstractInsnNode4 = abstractInsnNode.getNext();
            int n = abstractInsnNode.getOpcode();
            if (n == 0) {
                insnList.remove(abstractInsnNode);
                counters.inc(Stat.JUNK_INSNS);
                bl = true;
                abstractInsnNode = abstractInsnNode4;
                continue;
            }
            AbstractInsnNode abstractInsnNode5 = ClassUtil.nextReal(abstractInsnNode);
            if (abstractInsnNode5 != null && n >= 0 && !JunkCodeRemover.hasLabelBetween(abstractInsnNode, abstractInsnNode5)) {
                int n2 = abstractInsnNode5.getOpcode();
                if (n2 == 87 && JunkCodeRemover.isSimplePush(abstractInsnNode, false) || n2 == 88 && JunkCodeRemover.isSimplePush(abstractInsnNode, true) || n == 89 && n2 == 87 || n == 92 && n2 == 88 || n == 95 && n2 == 95) {
                    abstractInsnNode4 = abstractInsnNode5.getNext();
                    insnList.remove(abstractInsnNode);
                    insnList.remove(abstractInsnNode5);
                    counters.add(Stat.JUNK_INSNS, 2);
                    bl = true;
                    abstractInsnNode = abstractInsnNode4;
                    continue;
                }
                if (abstractInsnNode instanceof VarInsnNode) {
                    abstractInsnNode3 = (VarInsnNode)abstractInsnNode;
                    if (abstractInsnNode5 instanceof VarInsnNode) {
                        abstractInsnNode2 = (VarInsnNode)abstractInsnNode5;
                        if (((VarInsnNode)abstractInsnNode3).var == ((VarInsnNode)abstractInsnNode2).var && n >= 21 && n <= 25 && n2 == n + 33) {
                            abstractInsnNode4 = abstractInsnNode5.getNext();
                            insnList.remove(abstractInsnNode);
                            insnList.remove(abstractInsnNode5);
                            counters.add(Stat.JUNK_INSNS, 2);
                            bl = true;
                            abstractInsnNode = abstractInsnNode4;
                            continue;
                        }
                    }
                }
            }
            if (abstractInsnNode instanceof JumpInsnNode) {
                JumpInsnNode jumpInsnNode = (JumpInsnNode)abstractInsnNode;
                abstractInsnNode3 = ClassUtil.firstReal(jumpInsnNode.label);
                if (abstractInsnNode3 != null && abstractInsnNode3 == ClassUtil.nextReal(jumpInsnNode) && JunkCodeRemover.onlyLabelsBetween(jumpInsnNode, jumpInsnNode.label)) {
                    if (n == 167) {
                        insnList.remove(jumpInsnNode);
                    } else {
                        insnList.set(jumpInsnNode, new InsnNode(JunkCodeRemover.popsTwo(n) ? 88 : 87));
                    }
                    counters.inc(Stat.JUNK_INSNS);
                    bl = true;
                    abstractInsnNode = abstractInsnNode4;
                    continue;
                }
                abstractInsnNode2 = JunkCodeRemover.followGotoChain(jumpInsnNode);
                if (abstractInsnNode2 != null && abstractInsnNode2 != jumpInsnNode.label) {
                    jumpInsnNode.label = abstractInsnNode2;
                    bl = true;
                }
            }
            abstractInsnNode = abstractInsnNode4;
        }
        return bl;
    }

    private static LabelNode followGotoChain(JumpInsnNode jumpInsnNode) {
        JumpInsnNode jumpInsnNode2;
        AbstractInsnNode abstractInsnNode;
        HashSet<JumpInsnNode> hashSet = new HashSet<JumpInsnNode>();
        hashSet.add(jumpInsnNode);
        LabelNode labelNode = jumpInsnNode.label;
        while ((abstractInsnNode = ClassUtil.firstReal(labelNode)) instanceof JumpInsnNode && (jumpInsnNode2 = (JumpInsnNode)abstractInsnNode).getOpcode() == 167) {
            if (!hashSet.add(jumpInsnNode2)) {
                return null;
            }
            labelNode = jumpInsnNode2.label;
        }
        return labelNode;
    }

    private static boolean removeDeadConstantStores(MethodNode methodNode, Counters counters) {
        AbstractInsnNode abstractInsnNode;
        HashSet<Integer> hashSet = new HashSet<Integer>();
        for (AbstractInsnNode abstractInsnNode2 = methodNode.instructions.getFirst(); abstractInsnNode2 != null; abstractInsnNode2 = abstractInsnNode2.getNext()) {
            int n = abstractInsnNode2.getOpcode();
            if (abstractInsnNode2 instanceof VarInsnNode) {
                abstractInsnNode = (VarInsnNode)abstractInsnNode2;
                if (n >= 21 && n <= 25 || n == 169) {
                    hashSet.add(abstractInsnNode.var);
                    continue;
                }
            }
            if (!(abstractInsnNode2 instanceof IincInsnNode)) continue;
            abstractInsnNode = (IincInsnNode)abstractInsnNode2;
            hashSet.add(((IincInsnNode)abstractInsnNode).var);
        }
        boolean bl = false;
        AbstractInsnNode abstractInsnNode3 = methodNode.instructions.getFirst();
        while (abstractInsnNode3 != null) {
            abstractInsnNode = abstractInsnNode3.getNext();
            int n = abstractInsnNode3.getOpcode();
            if (abstractInsnNode3 instanceof VarInsnNode) {
                AbstractInsnNode abstractInsnNode4;
                VarInsnNode varInsnNode = (VarInsnNode)abstractInsnNode3;
                if (n >= 54 && n <= 58 && !hashSet.contains(varInsnNode.var) && (abstractInsnNode4 = ClassUtil.prevReal(abstractInsnNode3)) != null && !JunkCodeRemover.hasLabelBetween(abstractInsnNode4, abstractInsnNode3) && JunkCodeRemover.isSimplePush(abstractInsnNode4, n == 55 || n == 57) && !(abstractInsnNode4 instanceof VarInsnNode)) {
                    methodNode.instructions.remove(abstractInsnNode4);
                    methodNode.instructions.remove(abstractInsnNode3);
                    counters.add(Stat.JUNK_INSNS, 2);
                    bl = true;
                }
            }
            abstractInsnNode3 = abstractInsnNode;
        }
        if (bl && methodNode.localVariables != null) {
            methodNode.localVariables.removeIf(localVariableNode -> !hashSet.contains(localVariableNode.index) && !JunkCodeRemover.isParameterSlot(methodNode, localVariableNode.index));
        }
        return bl;
    }

    private static boolean removeDiscardedExpressions(MethodNode methodNode, Counters counters) {
        Set<LabelNode> set = null;
        boolean bl = false;
        AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst();
        while (abstractInsnNode != null) {
            AbstractInsnNode abstractInsnNode2 = abstractInsnNode.getNext();
            int n = abstractInsnNode.getOpcode();
            if (n == 87 || n == 88) {
                List<AbstractInsnNode> list;
                if (set == null) {
                    set = JunkCodeRemover.referencedLabels(methodNode);
                }
                if ((list = JunkCodeRemover.pureSlice(abstractInsnNode, n == 87 ? 1 : 2, set)) != null && list.size() > 1) {
                    for (AbstractInsnNode abstractInsnNode3 : list) {
                        methodNode.instructions.remove(abstractInsnNode3);
                    }
                    methodNode.instructions.remove(abstractInsnNode);
                    counters.add(Stat.JUNK_INSNS, list.size() + 1);
                    bl = true;
                }
            }
            abstractInsnNode = abstractInsnNode2;
        }
        return bl;
    }

    private static List<AbstractInsnNode> pureSlice(AbstractInsnNode abstractInsnNode, int n, Set<LabelNode> set) {
        LinkedList<AbstractInsnNode> linkedList = new LinkedList<AbstractInsnNode>();
        int n2 = n;
        AbstractInsnNode abstractInsnNode2 = abstractInsnNode.getPrevious();
        while (n2 > 0) {
            Object object;
            if (abstractInsnNode2 == null || linkedList.size() > 64) {
                return null;
            }
            if (abstractInsnNode2 instanceof LabelNode) {
                object = (LabelNode)abstractInsnNode2;
                if (set.contains(object)) {
                    return null;
                }
                abstractInsnNode2 = abstractInsnNode2.getPrevious();
                continue;
            }
            if (abstractInsnNode2.getOpcode() < 0) {
                abstractInsnNode2 = abstractInsnNode2.getPrevious();
                continue;
            }
            object = JunkCodeRemover.pureEffect(abstractInsnNode2);
            if (object == null) {
                return null;
            }
            if ((n2 = n2 - object[1] + object[0]) < 0) {
                return null;
            }
            linkedList.addFirst(abstractInsnNode2);
            abstractInsnNode2 = abstractInsnNode2.getPrevious();
        }
        return linkedList;
    }

    private static int[] pureEffect(AbstractInsnNode abstractInsnNode) {
        int n = abstractInsnNode.getOpcode();
        if (abstractInsnNode instanceof LdcInsnNode) {
            LdcInsnNode ldcInsnNode = (LdcInsnNode)abstractInsnNode;
            Object object = ldcInsnNode.cst;
            if (object instanceof Number || object instanceof String) {
                return new int[]{0, Constants.isWide(object) ? 2 : 1};
            }
            return null;
        }
        Object object = Constants.value(abstractInsnNode);
        if (object != null) {
            return new int[]{0, Constants.isWide(object) ? 2 : 1};
        }
        switch (n) {
            case 21: 
            case 23: 
            case 25: {
                return new int[]{0, 1};
            }
            case 22: 
            case 24: {
                return new int[]{0, 2};
            }
            case 89: {
                return new int[]{1, 2};
            }
            case 96: 
            case 98: 
            case 100: 
            case 102: 
            case 104: 
            case 106: 
            case 110: 
            case 114: 
            case 120: 
            case 122: 
            case 124: 
            case 126: 
            case 128: 
            case 130: 
            case 149: 
            case 150: {
                return new int[]{2, 1};
            }
            case 108: 
            case 112: {
                int[] nArray;
                Integer n2;
                Object object2 = Constants.value(ClassUtil.prevReal(abstractInsnNode));
                if (object2 instanceof Integer && (n2 = (Integer)object2) != 0) {
                    int[] nArray2 = new int[2];
                    nArray2[0] = 2;
                    nArray = nArray2;
                    nArray2[1] = 1;
                } else {
                    nArray = null;
                }
                return nArray;
            }
            case 97: 
            case 99: 
            case 101: 
            case 103: 
            case 105: 
            case 107: 
            case 111: 
            case 115: 
            case 127: 
            case 129: 
            case 131: {
                return new int[]{4, 2};
            }
            case 121: 
            case 123: 
            case 125: {
                return new int[]{3, 2};
            }
            case 148: 
            case 151: 
            case 152: {
                return new int[]{4, 1};
            }
            case 116: 
            case 118: 
            case 134: 
            case 139: 
            case 145: 
            case 146: 
            case 147: {
                return new int[]{1, 1};
            }
            case 133: 
            case 135: 
            case 140: 
            case 141: {
                return new int[]{1, 2};
            }
            case 136: 
            case 137: 
            case 142: 
            case 144: {
                return new int[]{2, 1};
            }
            case 117: 
            case 119: 
            case 138: 
            case 143: {
                return new int[]{2, 2};
            }
        }
        return null;
    }

    private static Set<LabelNode> referencedLabels(MethodNode methodNode) {
        HashSet<LabelNode> hashSet = new HashSet<LabelNode>();
        for (Object object = methodNode.instructions.getFirst(); object != null; object = ((AbstractInsnNode)object).getNext()) {
            if (object instanceof JumpInsnNode) {
                JumpInsnNode jumpInsnNode = (JumpInsnNode)object;
                hashSet.add(jumpInsnNode.label);
                continue;
            }
            if (object instanceof TableSwitchInsnNode) {
                TableSwitchInsnNode tableSwitchInsnNode = (TableSwitchInsnNode)object;
                hashSet.add(tableSwitchInsnNode.dflt);
                hashSet.addAll(tableSwitchInsnNode.labels);
                continue;
            }
            if (!(object instanceof LookupSwitchInsnNode)) continue;
            LookupSwitchInsnNode lookupSwitchInsnNode = (LookupSwitchInsnNode)object;
            hashSet.add(lookupSwitchInsnNode.dflt);
            hashSet.addAll(lookupSwitchInsnNode.labels);
        }
        for (TryCatchBlockNode tryCatchBlockNode : methodNode.tryCatchBlocks) {
            hashSet.add(tryCatchBlockNode.start);
            hashSet.add(tryCatchBlockNode.end);
            hashSet.add(tryCatchBlockNode.handler);
        }
        return hashSet;
    }

    private static boolean removeIdentityArithmetic(MethodNode methodNode, Counters counters) {
        boolean bl = false;
        AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst();
        while (abstractInsnNode != null) {
            AbstractInsnNode abstractInsnNode2 = abstractInsnNode.getNext();
            int n = abstractInsnNode.getOpcode();
            AbstractInsnNode abstractInsnNode3 = ClassUtil.prevReal(abstractInsnNode);
            if (abstractInsnNode3 != null && !JunkCodeRemover.hasLabelBetween(abstractInsnNode3, abstractInsnNode)) {
                Object object = Constants.value(abstractInsnNode3);
                boolean bl2 = n == 96 || n == 100 || n == 128 || n == 130 || n == 120 || n == 122 || n == 124 || n == 97 || n == 101 || n == 129 || n == 131;
                boolean bl3 = n == 121 || n == 123 || n == 125;
                boolean bl4 = n == 104 || n == 108 || n == 105 || n == 109;
                boolean bl5 = bl2 && (Integer.valueOf(0).equals(object) || Long.valueOf(0L).equals(object)) || bl3 && Integer.valueOf(0).equals(object) || bl4 && (Integer.valueOf(1).equals(object) || Long.valueOf(1L).equals(object));
                boolean bl6 = bl5;
                if (bl5) {
                    methodNode.instructions.remove(abstractInsnNode3);
                    methodNode.instructions.remove(abstractInsnNode);
                    counters.add(Stat.JUNK_INSNS, 2);
                    bl = true;
                }
            }
            abstractInsnNode = abstractInsnNode2;
        }
        return bl;
    }

    private static boolean isParameterSlot(MethodNode methodNode, int n) {
        int n2 = (methodNode.access & 8) == 0 ? 1 : 0;
        for (Type type : Type.getArgumentTypes(methodNode.desc)) {
            n2 += type.getSize();
        }
        return n < n2;
    }

    private static boolean popsTwo(int n) {
        return n >= 159 && n <= 166;
    }

    private static boolean hasLabelBetween(AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        for (AbstractInsnNode abstractInsnNode3 = abstractInsnNode.getNext(); abstractInsnNode3 != null && abstractInsnNode3 != abstractInsnNode2; abstractInsnNode3 = abstractInsnNode3.getNext()) {
            if (!(abstractInsnNode3 instanceof LabelNode)) continue;
            return true;
        }
        return false;
    }

    private static boolean onlyLabelsBetween(AbstractInsnNode abstractInsnNode, LabelNode labelNode) {
        for (AbstractInsnNode abstractInsnNode2 = abstractInsnNode.getNext(); abstractInsnNode2 != null; abstractInsnNode2 = abstractInsnNode2.getNext()) {
            if (abstractInsnNode2 == labelNode) {
                return true;
            }
            if (abstractInsnNode2.getOpcode() < 0) continue;
            return false;
        }
        return false;
    }

    private static boolean isSimplePush(AbstractInsnNode abstractInsnNode, boolean bl) {
        int n = abstractInsnNode.getOpcode();
        if (abstractInsnNode instanceof VarInsnNode) {
            boolean bl2 = n == 22 || n == 24;
            return n >= 21 && n <= 25 && bl2 == bl;
        }
        if (abstractInsnNode instanceof LdcInsnNode) {
            LdcInsnNode ldcInsnNode = (LdcInsnNode)abstractInsnNode;
            Object object = ldcInsnNode.cst;
            if (object instanceof Type || object instanceof Handle || object instanceof ConstantDynamic) {
                return false;
            }
            return Constants.isWide(object) == bl;
        }
        Object object = Constants.value(abstractInsnNode);
        if (object == null) {
            return false;
        }
        return Constants.isWide(object) == bl;
    }

    private static boolean allReachable(MethodNode methodNode) {
        int n;
        InsnList insnList = methodNode.instructions;
        int n2 = insnList.size();
        boolean[] blArray = new boolean[n2];
        int[] nArray = new int[n2 + 1];
        int n3 = 0;
        nArray[n3++] = 0;
        int[][] nArrayArray = new int[methodNode.tryCatchBlocks.size()][];
        for (int i = 0; i < nArrayArray.length; ++i) {
            TryCatchBlockNode tryCatchBlockNode = methodNode.tryCatchBlocks.get(i);
            nArrayArray[i] = new int[]{insnList.indexOf(tryCatchBlockNode.start), insnList.indexOf(tryCatchBlockNode.end), insnList.indexOf(tryCatchBlockNode.handler)};
        }
        boolean[] blArray2 = new boolean[nArrayArray.length];
        block1: while (true) {
            if (n3 > 0) {
                n = nArray[--n3];
                while (true) {
                    if (n >= n2 || blArray[n]) continue block1;
                    blArray[n] = true;
                    AbstractInsnNode abstractInsnNode = insnList.get(n);
                    int n4 = abstractInsnNode.getOpcode();
                    if (n4 == 168 || n4 == 169) {
                        return false;
                    }
                    if (abstractInsnNode instanceof JumpInsnNode) {
                        JumpInsnNode jumpInsnNode = (JumpInsnNode)abstractInsnNode;
                        if (n3 == nArray.length) {
                            return false;
                        }
                        nArray[n3++] = insnList.indexOf(jumpInsnNode.label);
                        if (n4 == 167) {
                            continue block1;
                        }
                    } else {
                        if (abstractInsnNode instanceof TableSwitchInsnNode) {
                            TableSwitchInsnNode tableSwitchInsnNode = (TableSwitchInsnNode)abstractInsnNode;
                            if (JunkCodeRemover.pushAll(insnList, tableSwitchInsnNode.dflt, tableSwitchInsnNode.labels, blArray)) continue block1;
                            return false;
                        }
                        if (abstractInsnNode instanceof LookupSwitchInsnNode) {
                            LookupSwitchInsnNode lookupSwitchInsnNode = (LookupSwitchInsnNode)abstractInsnNode;
                            if (JunkCodeRemover.pushAll(insnList, lookupSwitchInsnNode.dflt, lookupSwitchInsnNode.labels, blArray)) continue block1;
                            return false;
                        }
                        if (n4 >= 172 && n4 <= 177 || n4 == 191) continue block1;
                    }
                    if (n + 1 == n2) {
                        return false;
                    }
                    ++n;
                }
            }
            n = 0;
            block3: for (int i = 0; i < nArrayArray.length; ++i) {
                if (blArray2[i]) continue;
                int[] nArray2 = nArrayArray[i];
                for (int j = nArray2[0]; j < nArray2[1]; ++j) {
                    if (!blArray[j]) continue;
                    blArray2[i] = true;
                    if (blArray[nArray2[2]]) continue block3;
                    nArray[n3++] = nArray2[2];
                    n = 1;
                    continue block3;
                }
            }
            if (n == 0) break;
        }
        for (n = 0; n < n2; ++n) {
            AbstractInsnNode abstractInsnNode;
            if (blArray[n] || (abstractInsnNode = insnList.get(n)).getOpcode() < 0 && !(abstractInsnNode instanceof FrameNode)) continue;
            return false;
        }
        return true;
    }

    private static boolean pushAll(InsnList insnList, LabelNode labelNode, List<LabelNode> list, boolean[] blArray) {
        ArrayDeque<Integer> arrayDeque = new ArrayDeque<Integer>();
        arrayDeque.add(insnList.indexOf(labelNode));
        for (LabelNode abstractInsnNode : list) {
            arrayDeque.add(insnList.indexOf(abstractInsnNode));
        }
        block1: while (!arrayDeque.isEmpty()) {
            for (int i = ((Integer)arrayDeque.poll()).intValue(); i < blArray.length && !blArray[i]; ++i) {
                blArray[i] = true;
                AbstractInsnNode abstractInsnNode = insnList.get(i);
                int n = abstractInsnNode.getOpcode();
                if (n == 168 || n == 169) {
                    return false;
                }
                if (abstractInsnNode instanceof JumpInsnNode) {
                    JumpInsnNode jumpInsnNode = (JumpInsnNode)abstractInsnNode;
                    arrayDeque.add(insnList.indexOf(jumpInsnNode.label));
                    if (n == 167) {
                        continue block1;
                    }
                } else {
                    if (abstractInsnNode instanceof TableSwitchInsnNode) {
                        TableSwitchInsnNode tableSwitchInsnNode = (TableSwitchInsnNode)abstractInsnNode;
                        arrayDeque.add(insnList.indexOf(tableSwitchInsnNode.dflt));
                        for (LabelNode labelNode2 : tableSwitchInsnNode.labels) {
                            arrayDeque.add(insnList.indexOf(labelNode2));
                        }
                        continue block1;
                    }
                    if (abstractInsnNode instanceof LookupSwitchInsnNode) {
                        LookupSwitchInsnNode lookupSwitchInsnNode = (LookupSwitchInsnNode)abstractInsnNode;
                        arrayDeque.add(insnList.indexOf(lookupSwitchInsnNode.dflt));
                        for (LabelNode labelNode2 : lookupSwitchInsnNode.labels) {
                            arrayDeque.add(insnList.indexOf(labelNode2));
                        }
                        continue block1;
                    }
                    if (n >= 172 && n <= 177 || n == 191) continue block1;
                }
                if (i + 1 != blArray.length) continue;
                return false;
            }
        }
        return true;
    }

    private static boolean removeDeadCode(String string, MethodNode methodNode, Counters counters) {
        AbstractInsnNode abstractInsnNode;
        Frame<BasicValue>[] frameArray;
        if (JunkCodeRemover.allReachable(methodNode)) {
            return false;
        }
        try {
            frameArray = new Analyzer<BasicValue>(new BasicInterpreter()).analyze(string, methodNode);
        }
        catch (Exception | StackOverflowError throwable) {
            return false;
        }
        AbstractInsnNode[] abstractInsnNodeArray = methodNode.instructions.toArray();
        boolean bl = false;
        for (int i = 0; i < abstractInsnNodeArray.length; ++i) {
            abstractInsnNode = abstractInsnNodeArray[i];
            if (frameArray[i] == null && abstractInsnNode.getOpcode() >= 0) {
                methodNode.instructions.remove(abstractInsnNode);
                if (abstractInsnNode.getOpcode() != 167) {
                    counters.inc(Stat.DEAD_CODE);
                }
                bl = true;
                continue;
            }
            if (frameArray[i] != null || !(abstractInsnNode instanceof FrameNode)) continue;
            methodNode.instructions.remove(abstractInsnNode);
        }
        if (bl) {
            Iterator iterator = methodNode.instructions.iterator();
            while (iterator.hasNext()) {
                AbstractInsnNode abstractInsnNode2 = (AbstractInsnNode)iterator.next();
                if (!(abstractInsnNode2 instanceof LineNumberNode) || ClassUtil.nextReal(abstractInsnNode = (LineNumberNode)abstractInsnNode2) != null) continue;
                iterator.remove();
            }
        }
        return bl;
    }

    private static boolean removeFakeHandlers(MethodNode methodNode, Counters counters) {
        Object object2;
        if (methodNode.tryCatchBlocks.isEmpty()) {
            return false;
        }
        boolean bl = (methodNode.access & 0x20) != 0;
        for (object2 = methodNode.instructions.getFirst(); object2 != null && !bl; object2 = ((AbstractInsnNode)object2).getNext()) {
            if (((AbstractInsnNode)object2).getOpcode() != 194 && ((AbstractInsnNode)object2).getOpcode() != 195) continue;
            bl = true;
        }
        object2 = new HashSet();
        for (TryCatchBlockNode object3 : methodNode.tryCatchBlocks) {
            if (!JunkCodeRemover.rangeCanThrow(methodNode, object3, bl)) continue;
            ((HashSet)object2).add(object3.handler);
        }
        boolean bl2 = false;
        Iterator<TryCatchBlockNode> iterator = methodNode.tryCatchBlocks.iterator();
        while (iterator.hasNext()) {
            boolean bl3;
            TryCatchBlockNode tryCatchBlockNode = iterator.next();
            boolean bl4 = bl3 = !((HashSet)object2).contains(tryCatchBlockNode.handler) && !JunkCodeRemover.rangeCanThrow(methodNode, tryCatchBlockNode, bl) || JunkCodeRemover.handlerOnlyRethrows(tryCatchBlockNode);
            if (!bl3) continue;
            iterator.remove();
            counters.inc(Stat.FAKE_HANDLERS);
            bl2 = true;
        }
        return bl2;
    }

    private static boolean handlerOnlyRethrows(TryCatchBlockNode tryCatchBlockNode) {
        AbstractInsnNode abstractInsnNode = ClassUtil.firstReal(tryCatchBlockNode.handler);
        return abstractInsnNode != null && abstractInsnNode.getOpcode() == 191;
    }

    private static boolean rangeCanThrow(MethodNode methodNode, TryCatchBlockNode tryCatchBlockNode, boolean bl) {
        boolean bl2 = false;
        for (AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst(); abstractInsnNode != null; abstractInsnNode = abstractInsnNode.getNext()) {
            if (abstractInsnNode == tryCatchBlockNode.start) {
                bl2 = true;
            }
            if (abstractInsnNode == tryCatchBlockNode.end) break;
            if (!bl2 || abstractInsnNode.getOpcode() < 0 || !JunkCodeRemover.canThrow(abstractInsnNode, bl)) continue;
            return true;
        }
        return false;
    }

    static boolean canThrow(AbstractInsnNode abstractInsnNode, boolean bl) {
        int n = abstractInsnNode.getOpcode();
        if (n == 0 || n >= 1 && n <= 17) {
            return false;
        }
        if (n == 18) {
            Object object = ((LdcInsnNode)abstractInsnNode).cst;
            return !(object instanceof Number) && !(object instanceof String);
        }
        if (n >= 21 && n <= 25) {
            return false;
        }
        if (n >= 54 && n <= 58) {
            return false;
        }
        if (n >= 87 && n <= 95) {
            return false;
        }
        if (n >= 96 && n <= 152) {
            return n == 108 || n == 109 || n == 112 || n == 113;
        }
        if (n >= 153 && n <= 167) {
            return false;
        }
        if (n == 170 || n == 171) {
            return false;
        }
        if (n >= 172 && n <= 177) {
            return bl;
        }
        return true;
    }

    private static boolean removeEmptyTryBlocks(MethodNode methodNode) {
        boolean bl = false;
        Iterator<TryCatchBlockNode> iterator = methodNode.tryCatchBlocks.iterator();
        while (iterator.hasNext()) {
            TryCatchBlockNode tryCatchBlockNode = iterator.next();
            boolean bl2 = true;
            for (AbstractInsnNode abstractInsnNode = tryCatchBlockNode.start; abstractInsnNode != null && abstractInsnNode != tryCatchBlockNode.end; abstractInsnNode = abstractInsnNode.getNext()) {
                if (abstractInsnNode.getOpcode() < 0) continue;
                bl2 = false;
                break;
            }
            if (!bl2) continue;
            iterator.remove();
            bl = true;
        }
        return bl;
    }
}

