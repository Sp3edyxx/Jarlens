/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.transform;

import dev.jarlens.deob.ClassUtil;
import dev.jarlens.deob.Constants;
import dev.jarlens.deob.Counters;
import dev.jarlens.deob.JarIndex;
import dev.jarlens.deob.Stat;
import dev.jarlens.deob.TransformContext;
import dev.jarlens.deob.Transformer;
import dev.jarlens.deob.analysis.ConstValue;
import dev.jarlens.deob.analysis.ConstantInterpreter;
import dev.jarlens.deob.emu.Emulator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LookupSwitchInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TableSwitchInsnNode;
import org.objectweb.asm.tree.TryCatchBlockNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;
import org.objectweb.asm.tree.analysis.Analyzer;
import org.objectweb.asm.tree.analysis.Frame;

public final class StringDecryptor
implements Transformer {
    private static final String STRING_DESC = "Ljava/lang/String;";
    private ThreadLocal<Emulator> emulators;
    private final Map<String, Boolean> decryptorLike = new ConcurrentHashMap<String, Boolean>();
    private TransformContext ctx;
    private final Map<String, Optional<Boolean>> clinitAssigns = new ConcurrentHashMap<String, Optional<Boolean>>();

    @Override
    public String name() {
        return "String decryption";
    }

    @Override
    public void prepare(TransformContext transformContext) {
        this.ctx = transformContext;
        this.decryptorLike.clear();
        this.emulators = ThreadLocal.withInitial(() -> new Emulator(transformContext.snapshot::get, transformContext.hierarchy, transformContext.settings.emulatorInstructionLimit, transformContext.settings.emulatorClinitLimit));
    }

    @Override
    public boolean transform(ClassNode classNode, TransformContext transformContext, Counters counters) {
        boolean bl = false;
        for (MethodNode methodNode : classNode.methods) {
            if (methodNode.instructions.size() == 0) continue;
            bl |= this.decryptCalls(classNode, methodNode, counters);
            bl |= this.inlineStaticStrings(classNode, methodNode, counters);
        }
        return bl;
    }

    private boolean decryptCalls(ClassNode classNode, MethodNode methodNode, Counters counters) {
        Object object;
        Object object2;
        ArrayList<Frame<ConstValue>[]> arrayList = new ArrayList<Frame<ConstValue>[]>();
        for (object2 = methodNode.instructions.getFirst(); object2 != null; object2 = ((AbstractInsnNode)object2).getNext()) {
            if (!(object2 instanceof MethodInsnNode) || !this.isCandidate((MethodInsnNode)(object = (Frame<ConstValue>[])object2))) continue;
            arrayList.add((Frame<ConstValue>[])object);
        }
        if (arrayList.isEmpty()) {
            return false;
        }
        object2 = new IdentityHashMap();
        try {
            object = new Analyzer<ConstValue>(new ConstantInterpreter(null)).analyze(classNode.name, methodNode);
            AbstractInsnNode[] abstractInsnNodeArray = methodNode.instructions.toArray();
            for (int i = 0; i < abstractInsnNodeArray.length; ++i) {
                if (object[i] == null) continue;
                ((IdentityHashMap)object2).put(abstractInsnNodeArray[i], object[i]);
            }
        }
        catch (Exception | StackOverflowError throwable) {
            return false;
        }
        object = StringDecryptor.referencedLabels(methodNode);
        boolean bl = false;
        Set set = Collections.newSetFromMap(new IdentityHashMap());
        for (MethodInsnNode methodInsnNode : arrayList) {
            Object[] objectArray;
            String string;
            Object object3;
            Type[] typeArray;
            Frame frame;
            if (set.contains(methodInsnNode) || (frame = (Frame)((IdentityHashMap)object2).get(methodInsnNode)) == null) continue;
            String string2 = null;
            List<AbstractInsnNode> list = this.findSlice(methodInsnNode, (Map<AbstractInsnNode, Frame<ConstValue>>)object2, (Set<LabelNode>)object);
            Emulator emulator = this.emulator(methodInsnNode.owner);
            if (list != null) {
                try {
                    typeArray = StringDecryptor.snippet(list, methodInsnNode, (Map<AbstractInsnNode, Frame<ConstValue>>)object2);
                    object3 = emulator.evaluate(classNode.name, (MethodNode)typeArray);
                    if (object3 instanceof String) {
                        string2 = string = (String)object3;
                    }
                }
                catch (RuntimeException | StackOverflowError throwable) {
                    string2 = null;
                }
                if (string2 != null && StringDecryptor.fitsConstantPool(string2)) {
                    for (AbstractInsnNode abstractInsnNode : list) {
                        methodNode.instructions.remove(abstractInsnNode);
                    }
                    set.addAll(list);
                    methodNode.instructions.set(methodInsnNode, new LdcInsnNode(string2));
                    counters.inc(Stat.STRINGS_DECRYPTED);
                    bl = true;
                    continue;
                }
            }
            if ((objectArray = StringDecryptor.constantArgs(methodInsnNode, frame)) != null) {
                try {
                    object3 = emulator.invokeStatic(methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc, objectArray);
                    if (object3 instanceof String) {
                        string2 = string = (String)object3;
                    }
                }
                catch (RuntimeException | StackOverflowError throwable) {
                    string2 = null;
                }
                if (string2 != null && StringDecryptor.fitsConstantPool(string2)) {
                    typeArray = Type.getArgumentTypes(methodInsnNode.desc);
                    ArrayList<InsnNode> arrayList2 = new ArrayList<InsnNode>();
                    for (int i = typeArray.length - 1; i >= 0; --i) {
                        arrayList2.add(new InsnNode(typeArray[i].getSize() == 2 ? 88 : 87));
                    }
                    for (AbstractInsnNode abstractInsnNode : arrayList2) {
                        methodNode.instructions.insertBefore((AbstractInsnNode)methodInsnNode, abstractInsnNode);
                    }
                    methodNode.instructions.set(methodInsnNode, new LdcInsnNode(string2));
                    counters.inc(Stat.STRINGS_DECRYPTED);
                    bl = true;
                    continue;
                }
            }
            if (!this.isDecryptorLike(methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc)) continue;
            counters.inc(Stat.STRINGS_FAILED);
        }
        return bl;
    }

    private Emulator emulator(String string) {
        Emulator emulator = this.emulators.get();
        JarIndex jarIndex = this.ctx.index();
        emulator.setStaticReadPolicy((string2, string3, string4) -> string2.equals(string) || jarIndex.isEffectivelyFinalStatic(new JarIndex.FieldKey(string2, string3, string4)));
        return emulator;
    }

    private boolean isCandidate(MethodInsnNode methodInsnNode) {
        if (methodInsnNode.getOpcode() != 184) {
            return false;
        }
        if (!Type.getReturnType(methodInsnNode.desc).getDescriptor().equals(STRING_DESC)) {
            return false;
        }
        Type[] typeArray = Type.getArgumentTypes(methodInsnNode.desc);
        if (typeArray.length == 0) {
            return false;
        }
        for (Type type : typeArray) {
            boolean bl = type.getSort() <= 8 && type.getSort() >= 1 || type.getDescriptor().equals(STRING_DESC) || type.getSort() == 9 && type.getDimensions() == 1 && type.getElementType().getSort() <= 8 || type.getDescriptor().equals("Ljava/lang/Object;") || type.getDescriptor().equals("[Ljava/lang/Object;");
            boolean bl2 = bl;
            if (bl) continue;
            return false;
        }
        String string = this.ctx.hierarchy.resolveMethodOwner(methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc);
        return string != null && this.ctx.isJarClass(string) && this.isDecryptorLike(string, methodInsnNode.name, methodInsnNode.desc);
    }

    private boolean isDecryptorLike(String string, String string2, String string3) {
        String string5 = this.ctx.hierarchy.resolveMethodOwner(string, string2, string3);
        if (string5 == null) {
            string5 = string;
        }
        String string6 = string5 + "." + string2 + string3;
        String string7 = string5;
        return this.decryptorLike.computeIfAbsent(string6, string4 -> {
            boolean[] blArray = new boolean[2];
            this.scanDecryptor(string7, string2, string3, blArray, new HashSet<String>(), 0);
            return blArray[0] && blArray[1];
        });
    }

    private void scanDecryptor(String string, String string2, String string3, boolean[] blArray, Set<String> set, int n) {
        ClassNode classNode;
        if (n > 3 || !set.add(string + "." + string2 + string3)) {
            return;
        }
        byte[] byArray = this.ctx.snapshot.get(string);
        if (byArray == null) {
            return;
        }
        try {
            classNode = ClassUtil.read(byArray);
        }
        catch (RuntimeException runtimeException) {
            return;
        }
        for (MethodNode methodNode : classNode.methods) {
            if (!methodNode.name.equals(string2) || !methodNode.desc.equals(string3)) continue;
            for (AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst(); abstractInsnNode != null; abstractInsnNode = abstractInsnNode.getNext()) {
                TypeInsnNode typeInsnNode;
                int n2 = abstractInsnNode.getOpcode();
                if (n2 == 130 || n2 == 131 || n2 == 112 || n2 == 120 || n2 == 122 || n2 == 124) {
                    blArray[0] = true;
                }
                if (abstractInsnNode instanceof MethodInsnNode) {
                    MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
                    String string4 = methodInsnNode.owner;
                    if (string4.startsWith("javax/crypto/") || string4.equals("java/util/Base64$Decoder") || string4.equals("java/security/MessageDigest")) {
                        blArray[0] = true;
                    }
                    if (string4.equals("java/lang/String") && (methodInsnNode.name.equals("toCharArray") || methodInsnNode.name.equals("charAt") || methodInsnNode.name.equals("getBytes") || methodInsnNode.name.equals("<init>") || methodInsnNode.name.equals("valueOf") || methodInsnNode.name.equals("intern")) || string4.equals("java/lang/StringBuilder") && (methodInsnNode.name.equals("append") || methodInsnNode.name.equals("<init>")) || string4.equals("java/lang/StringBuffer") && methodInsnNode.name.equals("append")) {
                        blArray[1] = true;
                    }
                    if (this.ctx.isJarClass(methodInsnNode.owner) && methodInsnNode.getOpcode() == 184) {
                        this.scanDecryptor(methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc, blArray, set, n + 1);
                    }
                }
                if (abstractInsnNode instanceof TypeInsnNode && (typeInsnNode = (TypeInsnNode)abstractInsnNode).getOpcode() == 187 && typeInsnNode.desc.equals("java/lang/String")) {
                    blArray[1] = true;
                }
                if (!(abstractInsnNode instanceof InvokeDynamicInsnNode)) continue;
                blArray[1] = true;
            }
        }
    }

    private static Object[] constantArgs(MethodInsnNode methodInsnNode, Frame<ConstValue> frame) {
        Type[] typeArray = Type.getArgumentTypes(methodInsnNode.desc);
        Object[] objectArray = new Object[typeArray.length];
        int n = frame.getStackSize();
        for (int i = typeArray.length - 1; i >= 0; --i) {
            ConstValue constValue;
            if (!(constValue = frame.getStack(--n)).isConstant() || constValue.constant == Constants.NULL || constValue.constant instanceof Type) {
                return null;
            }
            objectArray[i] = constValue.constant;
        }
        return objectArray;
    }

    private List<AbstractInsnNode> findSlice(MethodInsnNode methodInsnNode, Map<AbstractInsnNode, Frame<ConstValue>> map, Set<LabelNode> set) {
        int n = 0;
        for (Type object : Type.getArgumentTypes(methodInsnNode.desc)) {
            n += object.getSize();
        }
        ArrayList arrayList = new ArrayList();
        AbstractInsnNode abstractInsnNode = methodInsnNode.getPrevious();
        int n2 = 0;
        while (n > 0) {
            if (abstractInsnNode == null || ++n2 > 2000) {
                return null;
            }
            if (abstractInsnNode instanceof LabelNode) {
                LabelNode labelNode = (LabelNode)abstractInsnNode;
                if (set.contains(labelNode)) {
                    return null;
                }
                abstractInsnNode = abstractInsnNode.getPrevious();
                continue;
            }
            if (abstractInsnNode.getOpcode() < 0) {
                abstractInsnNode = abstractInsnNode.getPrevious();
                continue;
            }
            int[] nArray = this.stackEffect(abstractInsnNode, map);
            if (nArray == null) {
                return null;
            }
            if ((n = n - nArray[1] + nArray[0]) < 0) {
                return null;
            }
            arrayList.add(0, abstractInsnNode);
            abstractInsnNode = abstractInsnNode.getPrevious();
        }
        return arrayList;
    }

    private int[] stackEffect(AbstractInsnNode abstractInsnNode, Map<AbstractInsnNode, Frame<ConstValue>> map) {
        int n = abstractInsnNode.getOpcode();
        Object object = Constants.value(abstractInsnNode);
        if (object != null) {
            return new int[]{0, Constants.isWide(object) ? 2 : 1};
        }
        switch (n) {
            case 21: 
            case 22: 
            case 23: 
            case 24: 
            case 25: {
                Frame<ConstValue> frame = map.get(abstractInsnNode);
                if (frame == null) {
                    return null;
                }
                ConstValue constValue = frame.getLocal(((VarInsnNode)abstractInsnNode).var);
                if (!constValue.isConstant() || constValue.constant instanceof Type) {
                    return null;
                }
                return new int[]{0, constValue.getSize()};
            }
            case 116: 
            case 145: 
            case 146: 
            case 147: 
            case 188: 
            case 189: 
            case 190: 
            case 192: {
                return new int[]{1, 1};
            }
            case 133: {
                return new int[]{1, 2};
            }
            case 136: {
                return new int[]{2, 1};
            }
            case 117: {
                return new int[]{2, 2};
            }
            case 89: {
                return new int[]{1, 2};
            }
            case 79: 
            case 81: 
            case 83: 
            case 84: 
            case 85: 
            case 86: {
                return new int[]{3, 0};
            }
            case 80: 
            case 82: {
                return new int[]{4, 0};
            }
            case 46: 
            case 50: 
            case 51: 
            case 52: 
            case 53: 
            case 96: 
            case 100: 
            case 104: 
            case 108: 
            case 112: 
            case 120: 
            case 122: 
            case 124: 
            case 126: 
            case 128: 
            case 130: {
                return new int[]{2, 1};
            }
            case 97: 
            case 101: 
            case 105: 
            case 109: 
            case 113: 
            case 127: 
            case 129: 
            case 131: {
                return new int[]{4, 2};
            }
            case 121: 
            case 123: 
            case 125: {
                return new int[]{3, 2};
            }
            case 178: {
                FieldInsnNode fieldInsnNode = (FieldInsnNode)abstractInsnNode;
                if (!this.ctx.isJarClass(fieldInsnNode.owner)) {
                    return null;
                }
                return new int[]{0, Type.getType(fieldInsnNode.desc).getSize()};
            }
            case 182: 
            case 184: {
                MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
                boolean bl = methodInsnNode.owner.equals("java/lang/String") || methodInsnNode.owner.equals("java/lang/Integer") || methodInsnNode.owner.equals("java/lang/Character") || methodInsnNode.owner.equals("java/lang/Long");
                boolean bl2 = n == 184 && this.ctx.isJarClass(methodInsnNode.owner) && this.isCandidate(methodInsnNode);
                boolean bl3 = bl2;
                if (!bl && !bl2) {
                    return null;
                }
                int n2 = n == 184 ? 0 : 1;
                for (Type type : Type.getArgumentTypes(methodInsnNode.desc)) {
                    n2 += type.getSize();
                }
                return new int[]{n2, Type.getReturnType(methodInsnNode.desc).getSize()};
            }
        }
        return null;
    }

    private static MethodNode snippet(List<AbstractInsnNode> list, MethodInsnNode methodInsnNode, Map<AbstractInsnNode, Frame<ConstValue>> map) {
        MethodNode methodNode = new MethodNode(8, "jarlens$snippet", "()Ljava/lang/String;", null, null);
        HashMap<LabelNode, LabelNode> hashMap = new HashMap<LabelNode, LabelNode>(){

            @Override
            public LabelNode get(Object object) {
                return this.computeIfAbsent((LabelNode)object, labelNode -> new LabelNode());
            }
        };
        for (AbstractInsnNode abstractInsnNode : list) {
            if (abstractInsnNode instanceof VarInsnNode) {
                VarInsnNode varInsnNode = (VarInsnNode)abstractInsnNode;
                ConstValue constValue = map.get(abstractInsnNode).getLocal(varInsnNode.var);
                methodNode.instructions.add(Constants.push(constValue.constant == Constants.NULL ? null : constValue.constant));
                continue;
            }
            methodNode.instructions.add(abstractInsnNode.clone((Map<LabelNode, LabelNode>)hashMap));
        }
        methodNode.instructions.add(methodInsnNode.clone((Map<LabelNode, LabelNode>)hashMap));
        methodNode.instructions.add(new InsnNode(176));
        methodNode.maxStack = 64 + list.size() * 2;
        methodNode.maxLocals = 0;
        return methodNode;
    }

    private static Set<LabelNode> referencedLabels(MethodNode methodNode) {
        HashSet<LabelNode> hashSet = new HashSet<LabelNode>();
        for (Object object = methodNode.instructions.getFirst(); object != null; object = ((AbstractInsnNode)object).getNext()) {
            if (object instanceof JumpInsnNode) {
                JumpInsnNode jumpInsnNode = (JumpInsnNode)object;
                hashSet.add(jumpInsnNode.label);
                continue;
            }
            if (object instanceof TableSwitchInsnNode) {
                TableSwitchInsnNode tableSwitchInsnNode = (TableSwitchInsnNode)object;
                hashSet.add(tableSwitchInsnNode.dflt);
                hashSet.addAll(tableSwitchInsnNode.labels);
                continue;
            }
            if (!(object instanceof LookupSwitchInsnNode)) continue;
            LookupSwitchInsnNode lookupSwitchInsnNode = (LookupSwitchInsnNode)object;
            hashSet.add(lookupSwitchInsnNode.dflt);
            hashSet.addAll(lookupSwitchInsnNode.labels);
        }
        for (TryCatchBlockNode tryCatchBlockNode : methodNode.tryCatchBlocks) {
            hashSet.add(tryCatchBlockNode.handler);
            hashSet.add(tryCatchBlockNode.start);
            hashSet.add(tryCatchBlockNode.end);
        }
        return hashSet;
    }

    private static boolean labelBetween(AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        for (AbstractInsnNode abstractInsnNode3 = abstractInsnNode.getNext(); abstractInsnNode3 != null && abstractInsnNode3 != abstractInsnNode2; abstractInsnNode3 = abstractInsnNode3.getNext()) {
            if (!(abstractInsnNode3 instanceof LabelNode)) continue;
            return true;
        }
        return false;
    }

    static boolean fitsConstantPool(String string) {
        if (string.length() > 65535) {
            return false;
        }
        long l = 0L;
        for (int i = 0; i < string.length(); ++i) {
            char c = string.charAt(i);
            l += c >= '\u0001' && c <= '\u007f' ? 1L : (c <= '\u07ff' ? 2L : 3L);
        }
        return l <= 65535L;
    }

    private boolean inlineStaticStrings(ClassNode classNode, MethodNode methodNode, Counters counters) {
        boolean bl = false;
        JarIndex jarIndex = null;
        for (Object object = methodNode.instructions.getFirst(); object != null; object = ((AbstractInsnNode)object).getNext()) {
            String string;
            if (((AbstractInsnNode)object).getOpcode() != 178) continue;
            FieldInsnNode fieldInsnNode = (FieldInsnNode)object;
            boolean bl2 = fieldInsnNode.desc.equals("[Ljava/lang/String;") || fieldInsnNode.desc.equals("[Ljava/lang/Object;");
            boolean bl3 = bl2;
            if (!fieldInsnNode.desc.equals(STRING_DESC) && !bl2 || (string = this.ctx.hierarchy.resolveFieldOwner(fieldInsnNode.owner, fieldInsnNode.name, fieldInsnNode.desc)) == null || !this.ctx.isJarClass(string) || methodNode.name.equals("<clinit>") && string.equals(classNode.name)) continue;
            JarIndex.FieldKey fieldKey = new JarIndex.FieldKey(string, fieldInsnNode.name, fieldInsnNode.desc);
            if (!this.clinitAssignsField(string, fieldInsnNode.name, fieldInsnNode.desc)) continue;
            if (jarIndex == null) {
                jarIndex = this.ctx.index();
            }
            if (bl2) {
                if (!jarIndex.isReadOnlyIndexedArray(fieldKey)) continue;
                AbstractInsnNode abstractInsnNode = ClassUtil.nextReal((AbstractInsnNode)object);
                AbstractInsnNode abstractInsnNode2 = ClassUtil.nextReal(abstractInsnNode);
                Integer n = Constants.intValue(abstractInsnNode);
                if (n == null || abstractInsnNode2 == null || abstractInsnNode2.getOpcode() != 50 || StringDecryptor.labelBetween((AbstractInsnNode)object, abstractInsnNode2) || !((var14_14 = this.readStatic(string, fieldInsnNode)) instanceof Object[])) continue;
                Object[] objectArray = (Object[])var14_14;
                if (n < 0 || n >= objectArray.length || !((var13_13 = objectArray[n]) instanceof String) || !StringDecryptor.fitsConstantPool(var12_12 = (String)var13_13)) continue;
                LdcInsnNode ldcInsnNode = new LdcInsnNode(var12_12);
                methodNode.instructions.set((AbstractInsnNode)object, ldcInsnNode);
                methodNode.instructions.remove(abstractInsnNode);
                methodNode.instructions.remove(abstractInsnNode2);
                object = ldcInsnNode;
            } else {
                if (!jarIndex.isEffectivelyFinalStatic(fieldKey) || jarIndex.constantStaticField(fieldKey) != null || !((var13_13 = this.readStatic(string, fieldInsnNode)) instanceof String) || !StringDecryptor.fitsConstantPool(var12_12 = (String)var13_13)) continue;
                var14_14 = new LdcInsnNode(var12_12);
                methodNode.instructions.set((AbstractInsnNode)object, (AbstractInsnNode)var14_14);
                object = var14_14;
            }
            counters.inc(Stat.STRINGS_DECRYPTED);
            bl = true;
        }
        return bl;
    }

    private boolean clinitAssignsField(String string, String string2, String string3) {
        return this.clinitAssigns.computeIfAbsent(string + "." + string2 + ":" + string3, string4 -> {
            byte[] byArray = this.ctx.snapshot.get(string);
            if (byArray == null) {
                return Optional.of(false);
            }
            ClassNode classNode = ClassUtil.read(byArray);
            for (MethodNode methodNode : classNode.methods) {
                if (!methodNode.name.equals("<clinit>")) continue;
                boolean bl = false;
                boolean bl2 = false;
                for (AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst(); abstractInsnNode != null; abstractInsnNode = abstractInsnNode.getNext()) {
                    int n;
                    FieldInsnNode fieldInsnNode;
                    if (abstractInsnNode instanceof FieldInsnNode && (fieldInsnNode = (FieldInsnNode)abstractInsnNode).getOpcode() == 179 && fieldInsnNode.name.equals(string2) && fieldInsnNode.desc.equals(string3)) {
                        bl = true;
                    }
                    if ((n = abstractInsnNode.getOpcode()) != 130) {
                        if (!(abstractInsnNode instanceof MethodInsnNode)) continue;
                        MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
                        if (!this.ctx.isJarClass(methodInsnNode.owner) || !Type.getReturnType(methodInsnNode.desc).getDescriptor().equals(STRING_DESC)) continue;
                    }
                    bl2 = true;
                }
                return Optional.of(bl && bl2);
            }
            return Optional.of(false);
        }).orElse(false);
    }

    private Object readStatic(String string, FieldInsnNode fieldInsnNode) {
        Emulator emulator = this.emulator(string);
        try {
            return emulator.readStatic(string, fieldInsnNode.name, fieldInsnNode.desc);
        }
        catch (RuntimeException | StackOverflowError throwable) {
            return null;
        }
    }
}

