/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.transform;

import dev.jarlens.deob.ClassUtil;
import dev.jarlens.deob.Constants;
import dev.jarlens.deob.Counters;
import dev.jarlens.deob.JarIndex;
import dev.jarlens.deob.Stat;
import dev.jarlens.deob.TransformContext;
import dev.jarlens.deob.Transformer;
import dev.jarlens.deob.analysis.ConstValue;
import dev.jarlens.deob.analysis.ConstantInterpreter;
import dev.jarlens.deob.analysis.Folding;
import dev.jarlens.deob.transform.StringDecryptor;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LookupSwitchInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TableSwitchInsnNode;
import org.objectweb.asm.tree.analysis.Analyzer;
import org.objectweb.asm.tree.analysis.Frame;

public final class ConstantFolder
implements Transformer {
    @Override
    public String name() {
        return "Constant folding & opaque predicates";
    }

    @Override
    public boolean transform(ClassNode classNode, TransformContext transformContext, Counters counters) {
        boolean bl = false;
        for (MethodNode methodNode : classNode.methods) {
            if (methodNode.instructions.size() == 0) continue;
            ConstantInterpreter.StaticConstants staticConstants = ConstantFolder.staticConstants(classNode, methodNode, transformContext);
            if (staticConstants != null) {
                bl |= ConstantFolder.inlineStaticConstants(methodNode, staticConstants, counters);
            }
            bl |= ConstantFolder.foldArithmetic(methodNode, counters);
            bl |= ConstantFolder.foldStringConcat(methodNode, counters);
            bl |= ConstantFolder.foldBranches(classNode.name, methodNode, staticConstants, counters);
        }
        return bl;
    }

    private static ConstantInterpreter.StaticConstants staticConstants(ClassNode classNode, MethodNode methodNode, TransformContext transformContext) {
        if (!transformContext.settings.foldStaticConstantFields) {
            return null;
        }
        boolean bl = methodNode.name.equals("<clinit>");
        return (string, string2, string3) -> {
            String string4 = transformContext.hierarchy.resolveFieldOwner(string, string2, string3);
            if (string4 == null || !transformContext.isJarClass(string4)) {
                return null;
            }
            if (bl && string4.equals(classNode.name)) {
                return null;
            }
            return transformContext.index().constantStaticField(new JarIndex.FieldKey(string4, string2, string3));
        };
    }

    private static boolean inlineStaticConstants(MethodNode methodNode, ConstantInterpreter.StaticConstants staticConstants, Counters counters) {
        boolean bl = false;
        for (AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst(); abstractInsnNode != null; abstractInsnNode = abstractInsnNode.getNext()) {
            if (abstractInsnNode.getOpcode() != 178) continue;
            FieldInsnNode fieldInsnNode = (FieldInsnNode)abstractInsnNode;
            Object object = staticConstants.get(fieldInsnNode.owner, fieldInsnNode.name, fieldInsnNode.desc);
            if (object == null) continue;
            AbstractInsnNode abstractInsnNode2 = Constants.push(object);
            methodNode.instructions.set(abstractInsnNode, abstractInsnNode2);
            abstractInsnNode = abstractInsnNode2;
            counters.inc(Stat.CONST_FIELDS);
            bl = true;
        }
        return bl;
    }

    private static boolean foldArithmetic(MethodNode methodNode, Counters counters) {
        InsnList insnList = methodNode.instructions;
        boolean bl = false;
        boolean bl2 = true;
        while (bl2) {
            bl2 = false;
            for (Object object = insnList.getFirst(); object != null; object = ((AbstractInsnNode)object).getNext()) {
                Object object2;
                Object object3;
                Object object4;
                int n = ((AbstractInsnNode)object).getOpcode();
                if (n < 96 || n > 152 || n == 132) continue;
                boolean bl3 = n >= 116 && n <= 119 || n >= 133 && n <= 147;
                AbstractInsnNode abstractInsnNode = ClassUtil.prevReal((AbstractInsnNode)object);
                if (abstractInsnNode == null || ConstantFolder.labelBetween(abstractInsnNode, (AbstractInsnNode)object) || (object4 = Constants.value(abstractInsnNode)) == null || object4 == Constants.NULL || object4 instanceof String || object4 instanceof Type) continue;
                AbstractInsnNode abstractInsnNode2 = null;
                if (bl3) {
                    object3 = Folding.unary(n, object4);
                } else {
                    abstractInsnNode2 = ClassUtil.prevReal(abstractInsnNode);
                    if (abstractInsnNode2 == null || ConstantFolder.labelBetween(abstractInsnNode2, abstractInsnNode) || (object2 = Constants.value(abstractInsnNode2)) == null || object2 == Constants.NULL || object2 instanceof String || object2 instanceof Type) continue;
                    object3 = Folding.binary(n, object2, object4);
                }
                if (object3 == null) continue;
                object2 = Constants.push(object3);
                insnList.set((AbstractInsnNode)object, (AbstractInsnNode)object2);
                insnList.remove(abstractInsnNode);
                if (abstractInsnNode2 != null) {
                    insnList.remove(abstractInsnNode2);
                }
                counters.inc(Stat.FOLDED);
                bl2 = true;
                bl = true;
                object = object2;
            }
        }
        return bl;
    }

    private static boolean directConstantOperand(AbstractInsnNode abstractInsnNode) {
        AbstractInsnNode abstractInsnNode2 = ClassUtil.prevReal(abstractInsnNode);
        return abstractInsnNode2 != null && !ConstantFolder.labelBetween(abstractInsnNode2, abstractInsnNode) && Constants.value(abstractInsnNode2) != null;
    }

    private static boolean foldStringConcat(MethodNode methodNode, Counters counters) {
        boolean bl = false;
        for (Object object = methodNode.instructions.getFirst(); object != null; object = ((AbstractInsnNode)object).getNext()) {
            Object object2;
            if (!(object instanceof InvokeDynamicInsnNode)) continue;
            InvokeDynamicInsnNode invokeDynamicInsnNode = (InvokeDynamicInsnNode)object;
            if (!invokeDynamicInsnNode.bsm.getOwner().equals("java/lang/invoke/StringConcatFactory") || !invokeDynamicInsnNode.bsm.getName().equals("makeConcatWithConstants") || invokeDynamicInsnNode.bsmArgs.length <= 0 || !((object2 = invokeDynamicInsnNode.bsmArgs[0]) instanceof String)) continue;
            String string = (String)object2;
            Type[] typeArray = Type.getArgumentTypes(invokeDynamicInsnNode.desc);
            ArrayList<AbstractInsnNode> arrayList = new ArrayList<AbstractInsnNode>();
            Object[] objectArray = new Object[typeArray.length];
            AbstractInsnNode abstractInsnNode = object;
            boolean bl2 = true;
            for (int i = typeArray.length - 1; i >= 0 && bl2; --i) {
                AbstractInsnNode abstractInsnNode2 = ClassUtil.prevReal(abstractInsnNode);
                Object object3 = Constants.value(abstractInsnNode2);
                if (abstractInsnNode2 == null || ConstantFolder.labelBetween(abstractInsnNode2, abstractInsnNode) || object3 == null || object3 instanceof Type) {
                    bl2 = false;
                    continue;
                }
                objectArray[i] = object3 == Constants.NULL ? null : object3;
                arrayList.add(abstractInsnNode2);
                abstractInsnNode = abstractInsnNode2;
            }
            if (!bl2) continue;
            StringBuilder stringBuilder = new StringBuilder();
            int n = 0;
            int n2 = 1;
            for (int i = 0; i < string.length() && bl2; ++i) {
                char c = string.charAt(i);
                if (c == '\u0001') {
                    stringBuilder.append(ConstantFolder.render(objectArray[n], typeArray[n]));
                    ++n;
                    continue;
                }
                if (c == '\u0002') {
                    if (n2 >= invokeDynamicInsnNode.bsmArgs.length) {
                        bl2 = false;
                        continue;
                    }
                    stringBuilder.append(invokeDynamicInsnNode.bsmArgs[n2++]);
                    continue;
                }
                stringBuilder.append(c);
            }
            if (!bl2 || !StringDecryptor.fitsConstantPool(stringBuilder.toString())) continue;
            for (AbstractInsnNode abstractInsnNode3 : arrayList) {
                methodNode.instructions.remove(abstractInsnNode3);
            }
            LdcInsnNode ldcInsnNode = new LdcInsnNode(stringBuilder.toString());
            methodNode.instructions.set((AbstractInsnNode)object, ldcInsnNode);
            object = ldcInsnNode;
            counters.inc(Stat.FOLDED);
            bl = true;
        }
        return bl;
    }

    private static String render(Object object, Type type) {
        switch (type.getSort()) {
            case 1: {
                return (Integer)object != 0 ? "true" : "false";
            }
            case 2: {
                return String.valueOf((char)((Integer)object).intValue());
            }
        }
        return String.valueOf(object);
    }

    private static boolean labelBetween(AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        for (AbstractInsnNode abstractInsnNode3 = abstractInsnNode.getNext(); abstractInsnNode3 != null && abstractInsnNode3 != abstractInsnNode2; abstractInsnNode3 = abstractInsnNode3.getNext()) {
            if (!(abstractInsnNode3 instanceof LabelNode)) continue;
            return true;
        }
        return false;
    }

    private static boolean foldBranches(String string, MethodNode methodNode, ConstantInterpreter.StaticConstants staticConstants, Counters counters) {
        Object object;
        int n;
        int n2;
        AbstractInsnNode abstractInsnNode;
        Frame<ConstValue>[] frameArray;
        AbstractInsnNode[] abstractInsnNodeArray;
        boolean bl = false;
        for (abstractInsnNodeArray = methodNode.instructions.getFirst(); abstractInsnNodeArray != null && !bl; abstractInsnNodeArray = abstractInsnNodeArray.getNext()) {
            bl = abstractInsnNodeArray instanceof JumpInsnNode && abstractInsnNodeArray.getOpcode() != 167 && abstractInsnNodeArray.getOpcode() != 168 || abstractInsnNodeArray instanceof TableSwitchInsnNode || abstractInsnNodeArray instanceof LookupSwitchInsnNode;
        }
        if (!bl) {
            return false;
        }
        try {
            frameArray = new Analyzer<ConstValue>(new ConstantInterpreter(staticConstants)).analyze(string, methodNode);
        }
        catch (Exception | StackOverflowError throwable) {
            return false;
        }
        abstractInsnNodeArray = methodNode.instructions.toArray();
        LinkedHashMap<AbstractInsnNode, LabelNode> linkedHashMap = new LinkedHashMap<AbstractInsnNode, LabelNode>();
        for (int i = 0; i < abstractInsnNodeArray.length; ++i) {
            Frame<ConstValue> object2 = frameArray[i];
            if (object2 == null) continue;
            abstractInsnNode = abstractInsnNodeArray[i];
            n2 = abstractInsnNode.getOpcode();
            n = object2.getStackSize();
            object = null;
            if (n2 >= 153 && n2 <= 158) {
                object = Folding.ifZero(n2, object2.getStack((int)(n - 1)).constant);
            } else if (n2 >= 159 && n2 <= 164) {
                object = Folding.ifCmp(n2, object2.getStack((int)(n - 2)).constant, object2.getStack((int)(n - 1)).constant);
            } else if (n2 == 198 || n2 == 199) {
                if (ConstantFolder.directConstantOperand(abstractInsnNode)) {
                    object = Folding.ifNull(n2, object2.getStack(n - 1));
                }
            } else if ((n2 == 165 || n2 == 166) && ConstantFolder.directConstantOperand(abstractInsnNode)) {
                var14_18 = object2.getStack(n - 2);
                var15_19 = object2.getStack(n - 1);
                var16_20 = null;
                if (((ConstValue)var14_18).constant == Constants.NULL && ((ConstValue)var15_19).constant == Constants.NULL) {
                    var16_20 = true;
                } else if (((ConstValue)var14_18).constant == Constants.NULL && ((ConstValue)var15_19).isConstant() || ((ConstValue)var15_19).constant == Constants.NULL && ((ConstValue)var14_18).isConstant()) {
                    var16_20 = false;
                }
                if (var16_20 != null) {
                    object = n2 == 165 ? (Boolean)var16_20 : !((Boolean)var16_20).booleanValue();
                }
            } else {
                if (abstractInsnNode instanceof TableSwitchInsnNode) {
                    var15_19 = (TableSwitchInsnNode)abstractInsnNode;
                    var16_20 = object2.getStack((int)(n - 1)).constant;
                    if (!(var16_20 instanceof Integer)) continue;
                    var14_18 = (Integer)var16_20;
                    LabelNode labelNode = (Integer)var14_18 >= ((TableSwitchInsnNode)var15_19).min && (Integer)var14_18 <= ((TableSwitchInsnNode)var15_19).max ? ((TableSwitchInsnNode)var15_19).labels.get((Integer)var14_18 - ((TableSwitchInsnNode)var15_19).min) : ((TableSwitchInsnNode)var15_19).dflt;
                    linkedHashMap.put(abstractInsnNode, labelNode);
                    continue;
                }
                if (abstractInsnNode instanceof LookupSwitchInsnNode) {
                    var15_19 = (LookupSwitchInsnNode)abstractInsnNode;
                    var16_20 = object2.getStack((int)(n - 1)).constant;
                    if (!(var16_20 instanceof Integer)) continue;
                    var14_18 = (Integer)var16_20;
                    int n3 = ((LookupSwitchInsnNode)var15_19).keys.indexOf(var14_18);
                    linkedHashMap.put(abstractInsnNode, n3 >= 0 ? ((LookupSwitchInsnNode)var15_19).labels.get(n3) : ((LookupSwitchInsnNode)var15_19).dflt);
                    continue;
                }
            }
            if (object == null) continue;
            linkedHashMap.put(abstractInsnNode, ((Boolean)object).booleanValue() ? ((JumpInsnNode)abstractInsnNode).label : null);
        }
        if (linkedHashMap.isEmpty()) {
            return false;
        }
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            abstractInsnNode = (AbstractInsnNode)entry.getKey();
            n2 = abstractInsnNode.getOpcode();
            n = n2 >= 159 && n2 <= 166 ? 1 : 0;
            object = new InsnList();
            ((InsnList)object).add(new InsnNode(n != 0 ? 88 : 87));
            if (entry.getValue() != null) {
                ((InsnList)object).add(new JumpInsnNode(167, (LabelNode)entry.getValue()));
            }
            methodNode.instructions.insertBefore(abstractInsnNode, (InsnList)object);
            methodNode.instructions.remove(abstractInsnNode);
            counters.inc(Stat.OPAQUE_BRANCHES);
        }
        return true;
    }
}

