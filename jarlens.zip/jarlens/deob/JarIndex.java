/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.core.ClassHierarchy;
import dev.jarlens.deob.ClassUtil;
import dev.jarlens.deob.Constants;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.InnerClassNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LookupSwitchInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TableSwitchInsnNode;
import org.objectweb.asm.tree.TryCatchBlockNode;

public final class JarIndex {
    public static final Object NO_VALUE = new Object(){

        public String toString() {
            return "NO_VALUE";
        }
    };
    private final Map<FieldKey, StaticField> staticFields = new HashMap<FieldKey, StaticField>();
    private final Map<String, Set<String>> innerClassesListed = new HashMap<String, Set<String>>();
    private boolean reflectiveFieldWrites;

    private JarIndex() {
    }

    static JarIndex build(Map<String, byte[]> map, ClassHierarchy classHierarchy) {
        JarIndex jarIndex = new JarIndex();
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        map.entrySet().parallelStream().forEach(entry -> {
            try {
                ClassNode classNode = new ClassNode();
                new ClassReader((byte[])entry.getValue()).accept(classNode, 6);
                concurrentHashMap.put((String)entry.getKey(), classNode);
            }
            catch (Exception | StackOverflowError throwable) {
                // empty catch block
            }
        });
        for (ClassNode classNode : concurrentHashMap.values()) {
            HashSet hashSet = new HashSet();
            for (InnerClassNode innerClassNode : classNode.innerClasses) {
                hashSet.add(innerClassNode.name);
            }
            jarIndex.innerClassesListed.put(classNode.name, hashSet);
            for (FieldNode fieldNode : classNode.fields) {
                if ((fieldNode.access & 8) == 0) continue;
                StaticField staticField = jarIndex.field(new FieldKey(classNode.name, fieldNode.name, fieldNode.desc));
                staticField.access = fieldNode.access;
                staticField.constantValueAttr = fieldNode.value;
            }
        }
        for (ClassNode classNode : concurrentHashMap.values()) {
            for (MethodNode methodNode : classNode.methods) {
                jarIndex.scanMethod(classNode, methodNode, classHierarchy);
            }
        }
        return jarIndex;
    }

    private StaticField field(FieldKey fieldKey2) {
        return this.staticFields.computeIfAbsent(fieldKey2, fieldKey -> new StaticField());
    }

    private void scanMethod(ClassNode classNode, MethodNode methodNode, ClassHierarchy classHierarchy) {
        AbstractInsnNode[] abstractInsnNodeArray = methodNode.instructions.toArray();
        boolean bl = methodNode.name.equals("<clinit>");
        HashMap<LabelNode, Integer> hashMap = null;
        for (int i = 0; i < abstractInsnNodeArray.length; ++i) {
            StaticField staticField;
            AbstractInsnNode abstractInsnNode;
            AbstractInsnNode abstractInsnNode2 = abstractInsnNodeArray[i];
            int n = abstractInsnNode2.getOpcode();
            if (abstractInsnNode2 instanceof MethodInsnNode) {
                abstractInsnNode = (MethodInsnNode)abstractInsnNode2;
                if (!JarIndex.isReflectiveWrite(abstractInsnNode)) continue;
                this.reflectiveFieldWrites = true;
                continue;
            }
            if (n != 179 && n != 178) continue;
            abstractInsnNode = (FieldInsnNode)abstractInsnNode2;
            String string = classHierarchy.resolveFieldOwner(((FieldInsnNode)abstractInsnNode).owner, ((FieldInsnNode)abstractInsnNode).name, ((FieldInsnNode)abstractInsnNode).desc);
            if (string == null) {
                string = ((FieldInsnNode)abstractInsnNode).owner;
            }
            FieldKey fieldKey = new FieldKey(string, ((FieldInsnNode)abstractInsnNode).name, ((FieldInsnNode)abstractInsnNode).desc);
            boolean bl2 = bl && string.equals(classNode.name);
            boolean bl3 = bl2;
            if (n == 179) {
                staticField = this.field(fieldKey);
                if (!bl2) {
                    ++staticField.writesOutsideClinit;
                    continue;
                }
                ++staticField.clinitWrites;
                staticField.clinitConst = JarIndex.constantBefore(abstractInsnNodeArray, i);
                if (hashMap == null) {
                    hashMap = JarIndex.labelIndex(abstractInsnNodeArray);
                }
                staticField.clinitWriteStraightLine = JarIndex.isStraightLine(methodNode, abstractInsnNodeArray, i, hashMap);
                continue;
            }
            if (bl2 || !((FieldInsnNode)abstractInsnNode).desc.startsWith("[")) continue;
            staticField = this.field(fieldKey);
            AbstractInsnNode abstractInsnNode3 = ClassUtil.nextReal(abstractInsnNode2);
            AbstractInsnNode abstractInsnNode4 = ClassUtil.nextReal(abstractInsnNode3);
            boolean bl4 = abstractInsnNode3 != null && abstractInsnNode4 != null && abstractInsnNode4.getOpcode() == 50 && Constants.intValue(abstractInsnNode3) != null && !JarIndex.labelBetween(abstractInsnNode2, abstractInsnNode4);
            boolean bl5 = bl4;
            if (bl4) continue;
            staticField.onlyIndexedReads = false;
        }
    }

    static boolean labelBetween(AbstractInsnNode abstractInsnNode, AbstractInsnNode abstractInsnNode2) {
        for (AbstractInsnNode abstractInsnNode3 = abstractInsnNode.getNext(); abstractInsnNode3 != null && abstractInsnNode3 != abstractInsnNode2; abstractInsnNode3 = abstractInsnNode3.getNext()) {
            if (!(abstractInsnNode3 instanceof LabelNode)) continue;
            return true;
        }
        return false;
    }

    private static Object constantBefore(AbstractInsnNode[] abstractInsnNodeArray, int n) {
        for (int i = n - 1; i >= 0; --i) {
            AbstractInsnNode abstractInsnNode = abstractInsnNodeArray[i];
            if (abstractInsnNode instanceof LabelNode) {
                return NO_VALUE;
            }
            if (abstractInsnNode.getOpcode() < 0) continue;
            Object object = Constants.value(abstractInsnNode);
            return object == null ? NO_VALUE : object;
        }
        return NO_VALUE;
    }

    private static HashMap<LabelNode, Integer> labelIndex(AbstractInsnNode[] abstractInsnNodeArray) {
        HashMap<LabelNode, Integer> hashMap = new HashMap<LabelNode, Integer>();
        for (int i = 0; i < abstractInsnNodeArray.length; ++i) {
            AbstractInsnNode abstractInsnNode = abstractInsnNodeArray[i];
            if (!(abstractInsnNode instanceof LabelNode)) continue;
            LabelNode labelNode = (LabelNode)abstractInsnNode;
            hashMap.put(labelNode, i);
        }
        return hashMap;
    }

    private static boolean isStraightLine(MethodNode methodNode, AbstractInsnNode[] abstractInsnNodeArray, int n, HashMap<LabelNode, Integer> hashMap) {
        int n2;
        for (TryCatchBlockNode object : methodNode.tryCatchBlocks) {
            n2 = hashMap.getOrDefault(object.start, -1);
            int n3 = hashMap.getOrDefault(object.end, -1);
            if (n2 > n || n >= n3) continue;
            return false;
        }
        for (int i = 0; i < n; ++i) {
            AbstractInsnNode abstractInsnNode;
            AbstractInsnNode abstractInsnNode2 = abstractInsnNodeArray[i];
            n2 = abstractInsnNode2.getOpcode();
            if (n2 >= 172 && n2 <= 177 || n2 == 191) {
                return false;
            }
            if (abstractInsnNode2 instanceof JumpInsnNode) {
                abstractInsnNode = (JumpInsnNode)abstractInsnNode2;
                if (hashMap.getOrDefault(abstractInsnNode.label, Integer.MAX_VALUE) > n) {
                    return false;
                }
            }
            if (abstractInsnNode2 instanceof TableSwitchInsnNode) {
                abstractInsnNode = (TableSwitchInsnNode)abstractInsnNode2;
                if (hashMap.getOrDefault(((TableSwitchInsnNode)abstractInsnNode).dflt, Integer.MAX_VALUE) > n) {
                    return false;
                }
                for (LabelNode labelNode : ((TableSwitchInsnNode)abstractInsnNode).labels) {
                    if (hashMap.getOrDefault(labelNode, Integer.MAX_VALUE) <= n) continue;
                    return false;
                }
            }
            if (!(abstractInsnNode2 instanceof LookupSwitchInsnNode)) continue;
            abstractInsnNode = (LookupSwitchInsnNode)abstractInsnNode2;
            if (hashMap.getOrDefault(((LookupSwitchInsnNode)abstractInsnNode).dflt, Integer.MAX_VALUE) > n) {
                return false;
            }
            for (LabelNode labelNode : ((LookupSwitchInsnNode)abstractInsnNode).labels) {
                if (hashMap.getOrDefault(labelNode, Integer.MAX_VALUE) <= n) continue;
                return false;
            }
        }
        return true;
    }

    private static boolean isReflectiveWrite(MethodInsnNode methodInsnNode) {
        String string = methodInsnNode.owner;
        String string2 = methodInsnNode.name;
        return string.equals("java/lang/reflect/Field") && string2.startsWith("set") || (string.equals("sun/misc/Unsafe") || string.equals("jdk/internal/misc/Unsafe")) && string2.startsWith("put") || string.equals("java/lang/invoke/MethodHandles$Lookup") && (string2.equals("findStaticSetter") || string2.equals("findStaticVarHandle") || string2.equals("unreflectSetter") || string2.equals("unreflectVarHandle")) || string.equals("java/lang/invoke/VarHandle");
    }

    public Object constantStaticField(FieldKey fieldKey) {
        if (this.reflectiveFieldWrites) {
            return null;
        }
        StaticField staticField = this.staticFields.get(fieldKey);
        if (staticField == null || staticField.writesOutsideClinit > 0) {
            return null;
        }
        if ((staticField.access & 0x40) != 0) {
            return null;
        }
        Type type = Type.getType(fieldKey.desc());
        boolean bl = type.getSort() >= 1 && type.getSort() <= 8;
        boolean bl2 = fieldKey.desc().equals("Ljava/lang/String;");
        if (!bl && !bl2) {
            return null;
        }
        if (staticField.clinitWrites == 0) {
            if (staticField.constantValueAttr != null) {
                return Constants.normalize(staticField.constantValueAttr, type);
            }
            if (!bl) {
                return null;
            }
            return Constants.defaultValue(type);
        }
        if (staticField.clinitWrites == 1 && staticField.clinitWriteStraightLine && staticField.clinitConst != NO_VALUE && staticField.clinitConst != Constants.NULL) {
            return Constants.normalize(staticField.clinitConst, type);
        }
        return null;
    }

    public boolean isEffectivelyFinalStatic(FieldKey fieldKey) {
        if (this.reflectiveFieldWrites) {
            return false;
        }
        StaticField staticField = this.staticFields.get(fieldKey);
        return staticField != null && staticField.writesOutsideClinit == 0 && (staticField.access & 0x40) == 0;
    }

    public boolean isReadOnlyIndexedArray(FieldKey fieldKey) {
        StaticField staticField = this.staticFields.get(fieldKey);
        return staticField != null && staticField.onlyIndexedReads && this.isEffectivelyFinalStatic(fieldKey);
    }

    public Set<String> innerClassesListedBy(String string) {
        return this.innerClassesListed.getOrDefault(string, Set.of());
    }

    public List<FieldKey> staticFieldKeysOf(String string) {
        return this.staticFields.keySet().stream().filter(fieldKey -> fieldKey.owner().equals(string)).toList();
    }

    public record FieldKey(String owner, String name, String desc) {
    }

    public static final class StaticField {
        int access;
        Object constantValueAttr;
        int writesOutsideClinit;
        int clinitWrites;
        Object clinitConst = NO_VALUE;
        boolean clinitWriteStraightLine;
        boolean onlyIndexedReads = true;
    }
}

