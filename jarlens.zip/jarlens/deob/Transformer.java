/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.deob.Counters;
import dev.jarlens.deob.TransformContext;
import org.objectweb.asm.tree.ClassNode;

public interface Transformer {
    public String name();

    default public void prepare(TransformContext transformContext) {
    }

    default public boolean mayApply(byte[] byArray) {
        return true;
    }

    public boolean transform(ClassNode var1, TransformContext var2, Counters var3);
}

