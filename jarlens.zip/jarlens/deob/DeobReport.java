/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.deob.Counters;
import dev.jarlens.deob.Stat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

public final class DeobReport {
    private static final int MAX_LOG = 2000;
    private final Map<Stat, LongAdder> stats = new ConcurrentHashMap<Stat, LongAdder>();
    private final Set<String> techniques = Collections.synchronizedSet(new LinkedHashSet());
    private final List<String> log = Collections.synchronizedList(new ArrayList());
    private volatile int passes;
    private volatile long millis;

    public void add(Stat stat2, long l) {
        if (l != 0L) {
            this.stats.computeIfAbsent(stat2, stat -> new LongAdder()).add(l);
        }
    }

    public void merge(Counters counters) {
        for (Map.Entry<Stat, Integer> entry : counters.asMap().entrySet()) {
            this.add(entry.getKey(), entry.getValue().intValue());
        }
    }

    public long get(Stat stat) {
        LongAdder longAdder = this.stats.get((Object)stat);
        return longAdder == null ? 0L : longAdder.sum();
    }

    public Map<Stat, Long> stats() {
        EnumMap<Stat, Long> enumMap = new EnumMap<Stat, Long>(Stat.class);
        for (Stat stat : Stat.values()) {
            long l = this.get(stat);
            if (l == 0L) continue;
            enumMap.put(stat, l);
        }
        return enumMap;
    }

    public void technique(String string) {
        this.techniques.add(string);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public List<String> techniques() {
        Set<String> set;
        Set<String> set2 = set = this.techniques;
        synchronized (set2) {
            return new ArrayList<String>(this.techniques);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void log(String string) {
        List<String> list;
        List<String> list2 = list = this.log;
        synchronized (list2) {
            if (this.log.size() < 2000) {
                this.log.add(string);
            } else if (this.log.size() == 2000) {
                this.log.add("\u2026 (further messages omitted)");
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public List<String> logLines() {
        List<String> list;
        List<String> list2 = list = this.log;
        synchronized (list2) {
            return new ArrayList<String>(this.log);
        }
    }

    public int passes() {
        return this.passes;
    }

    void passes(int n) {
        this.passes = n;
    }

    public long millis() {
        return this.millis;
    }

    void millis(long l) {
        this.millis = l;
    }
}

