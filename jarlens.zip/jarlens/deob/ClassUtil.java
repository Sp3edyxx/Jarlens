/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.core.ClassHierarchy;
import java.util.ArrayList;
import java.util.List;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Type;
import org.objectweb.asm.commons.JSRInlinerAdapter;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.analysis.Analyzer;
import org.objectweb.asm.tree.analysis.AnalyzerException;
import org.objectweb.asm.tree.analysis.BasicValue;
import org.objectweb.asm.tree.analysis.SimpleVerifier;

public final class ClassUtil {
    private ClassUtil() {
    }

    public static ClassNode read(byte[] byArray) {
        ClassReader classReader = new ClassReader(byArray);
        ClassNode classNode = new ClassNode(589824);
        classReader.accept(classNode, 0);
        if (!ClassUtil.hasJsr(classNode)) {
            return classNode;
        }
        ClassNode classNode2 = new ClassNode(589824){

            @Override
            public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
                MethodVisitor methodVisitor = super.visitMethod(n, string, string2, string3, stringArray);
                return new JSRInlinerAdapter(methodVisitor, n, string, string2, string3, stringArray);
            }
        };
        classReader.accept(classNode2, 0);
        return classNode2;
    }

    private static boolean hasJsr(ClassNode classNode) {
        for (MethodNode methodNode : classNode.methods) {
            for (AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst(); abstractInsnNode != null; abstractInsnNode = abstractInsnNode.getNext()) {
                if (abstractInsnNode.getOpcode() != 168) continue;
                return true;
            }
        }
        return false;
    }

    public static byte[] write(ClassNode classNode, ClassHierarchy classHierarchy) {
        int n = classNode.version & 0xFFFF;
        int n2 = n >= 50 ? 2 : 1;
        SafeClassWriter safeClassWriter = new SafeClassWriter(n2, classHierarchy);
        classNode.accept(safeClassWriter);
        return safeClassWriter.toByteArray();
    }

    public static String verify(byte[] byArray, ClassHierarchy classHierarchy) {
        ClassNode classNode;
        try {
            classNode = new ClassNode();
            new ClassReader(byArray).accept(classNode, 0);
        }
        catch (Exception | StackOverflowError throwable) {
            return "unparseable: " + String.valueOf(throwable);
        }
        Type type = Type.getObjectType(classNode.name);
        Type type2 = classNode.superName == null ? null : Type.getObjectType(classNode.superName);
        ArrayList<Type> arrayList = new ArrayList<Type>();
        if (classNode.interfaces != null) {
            for (String object : classNode.interfaces) {
                arrayList.add(Type.getObjectType(object));
            }
        }
        boolean bl = (classNode.access & 0x200) != 0;
        for (MethodNode methodNode : classNode.methods) {
            if (methodNode.instructions.size() == 0) continue;
            try {
                new Analyzer<BasicValue>(new SafeVerifier(type, type2, arrayList, bl, classHierarchy)).analyze(classNode.name, methodNode);
            }
            catch (AnalyzerException throwable) {
                return methodNode.name + methodNode.desc + ": " + throwable.getMessage();
            }
            catch (Exception | StackOverflowError throwable) {
                return methodNode.name + methodNode.desc + ": " + String.valueOf(throwable);
            }
        }
        return null;
    }

    public static int realInsnCount(MethodNode methodNode) {
        int n = 0;
        for (AbstractInsnNode abstractInsnNode = methodNode.instructions.getFirst(); abstractInsnNode != null; abstractInsnNode = abstractInsnNode.getNext()) {
            if (abstractInsnNode.getOpcode() < 0) continue;
            ++n;
        }
        return n;
    }

    public static AbstractInsnNode nextReal(AbstractInsnNode abstractInsnNode) {
        AbstractInsnNode abstractInsnNode2;
        AbstractInsnNode abstractInsnNode3 = abstractInsnNode2;
        for (abstractInsnNode2 = abstractInsnNode == null ? null : abstractInsnNode.getNext(); abstractInsnNode2 != null && abstractInsnNode2.getOpcode() < 0; abstractInsnNode2 = abstractInsnNode2.getNext()) {
        }
        return abstractInsnNode2;
    }

    public static AbstractInsnNode prevReal(AbstractInsnNode abstractInsnNode) {
        AbstractInsnNode abstractInsnNode2;
        AbstractInsnNode abstractInsnNode3 = abstractInsnNode2;
        for (abstractInsnNode2 = abstractInsnNode == null ? null : abstractInsnNode.getPrevious(); abstractInsnNode2 != null && abstractInsnNode2.getOpcode() < 0; abstractInsnNode2 = abstractInsnNode2.getPrevious()) {
        }
        return abstractInsnNode2;
    }

    public static AbstractInsnNode firstReal(AbstractInsnNode abstractInsnNode) {
        AbstractInsnNode abstractInsnNode2;
        for (abstractInsnNode2 = abstractInsnNode; abstractInsnNode2 != null && abstractInsnNode2.getOpcode() < 0; abstractInsnNode2 = abstractInsnNode2.getNext()) {
        }
        return abstractInsnNode2;
    }

    public static final class SafeClassWriter
    extends ClassWriter {
        private final ClassHierarchy hierarchy;

        public SafeClassWriter(int n, ClassHierarchy classHierarchy) {
            super(n);
            this.hierarchy = classHierarchy;
        }

        @Override
        protected String getCommonSuperClass(String string, String string2) {
            return this.hierarchy.commonSuperClass(string, string2);
        }

        @Override
        protected ClassLoader getClassLoader() {
            throw new UnsupportedOperationException("class loading is disabled");
        }
    }

    static final class SafeVerifier
    extends SimpleVerifier {
        private final ClassHierarchy hierarchy;
        private final Type self;
        private final Type selfSuper;
        private final boolean selfInterface;

        SafeVerifier(Type type, Type type2, List<Type> list, boolean bl, ClassHierarchy classHierarchy) {
            super(589824, type, type2, list, bl);
            this.hierarchy = classHierarchy;
            this.self = type;
            this.selfSuper = type2;
            this.selfInterface = bl;
        }

        @Override
        protected boolean isInterface(Type type) {
            if (type.equals(this.self)) {
                return this.selfInterface;
            }
            return this.hierarchy.isInterface(type.getInternalName());
        }

        @Override
        protected Type getSuperClass(Type type) {
            if (type.equals(this.self)) {
                return this.selfSuper;
            }
            String string = this.hierarchy.superName(type.getInternalName());
            return string == null ? null : Type.getObjectType(string);
        }

        @Override
        protected boolean isAssignableFrom(Type type, Type type2) {
            if (type.equals(type2)) {
                return true;
            }
            if (type.getSort() == 10 && type.getInternalName().equals("java/lang/Object")) {
                return true;
            }
            if (type.getSort() == 9) {
                if (type2.getSort() != 9) {
                    return false;
                }
                int n = type.getDimensions();
                int n2 = type2.getDimensions();
                Type type3 = type.getElementType();
                Type type4 = type2.getElementType();
                if (n == n2) {
                    boolean bl = type3.getSort() == 10;
                    boolean bl2 = type4.getSort() == 10;
                    boolean bl3 = bl2;
                    if (bl && bl2) {
                        return this.isAssignableFrom(type3, type4);
                    }
                    return type3.equals(type4);
                }
                if (n < n2) {
                    return SafeVerifier.isArraySuper(type3);
                }
                return false;
            }
            if (type.getSort() != 10) {
                return false;
            }
            if (type2.getSort() == 9) {
                return SafeVerifier.isArraySuper(type);
            }
            if (type2.getSort() != 10) {
                return false;
            }
            String string = type.getInternalName();
            String string2 = type2.getInternalName();
            if (this.isInterface(type)) {
                return true;
            }
            if (type2.equals(this.self) && this.selfSuper != null) {
                return type.equals(this.selfSuper) || this.isAssignableFrom(type, this.selfSuper);
            }
            Boolean bl = this.hierarchy.isSubtypeOf(string2, string);
            return bl == null || bl != false;
        }

        private static boolean isArraySuper(Type type) {
            if (type.getSort() != 10) {
                return false;
            }
            String string = type.getInternalName();
            return string.equals("java/lang/Object") || string.equals("java/lang/Cloneable") || string.equals("java/io/Serializable");
        }

        @Override
        protected Class<?> getClass(Type type) {
            throw new UnsupportedOperationException("class loading is disabled");
        }
    }
}

