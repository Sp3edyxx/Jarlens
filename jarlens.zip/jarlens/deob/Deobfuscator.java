/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.core.ClassHierarchy;
import dev.jarlens.core.JarModel;
import dev.jarlens.deob.ClassUtil;
import dev.jarlens.deob.Counters;
import dev.jarlens.deob.DeobReport;
import dev.jarlens.deob.DeobSettings;
import dev.jarlens.deob.HierarchyRemapper;
import dev.jarlens.deob.ObfuscationDetector;
import dev.jarlens.deob.Stat;
import dev.jarlens.deob.TransformContext;
import dev.jarlens.deob.Transformer;
import dev.jarlens.deob.transform.ConstantFolder;
import dev.jarlens.deob.transform.DebugInfoCleaner;
import dev.jarlens.deob.transform.IndyResolver;
import dev.jarlens.deob.transform.JunkCodeRemover;
import dev.jarlens.deob.transform.Renamer;
import dev.jarlens.deob.transform.StringDecryptor;
import dev.jarlens.mapping.MappingSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.objectweb.asm.tree.ClassNode;

public final class Deobfuscator {
    private final DeobSettings settings;
    private final Progress progress;
    private final DeobReport report = new DeobReport();

    public Deobfuscator(DeobSettings deobSettings, Progress progress) {
        this.settings = deobSettings;
        this.progress = progress == null ? (string, n, n2) -> {} : progress;
    }

    public Result run(JarModel jarModel, MappingSet mappingSet) {
        Object object;
        long l = System.currentTimeMillis();
        Map<String, byte[]> map = new TreeMap<String, byte[]>(jarModel.classes());
        LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<String, String>();
        for (String string : map.keySet()) {
            linkedHashMap.put(string, string);
        }
        ObfuscationDetector.scan(jarModel, map, this.report);
        if (mappingSet != null && !mappingSet.isEmpty()) {
            this.progress.update("Applying mappings", 0, 1);
            object = mappingSet.toRemapper(new ClassHierarchy(map), map.keySet());
            if (!((HierarchyRemapper)object).isEmpty()) {
                map = new TreeMap<String, byte[]>(((HierarchyRemapper)object).apply(map));
                Deobfuscator.updateNames(linkedHashMap, (HierarchyRemapper)object);
                this.report.add(Stat.MAPPED_NAMES, ((HierarchyRemapper)object).size());
                this.report.technique("Mapping file applied (" + ((HierarchyRemapper)object).size() + " names)");
            }
        }
        if (this.settings.enabled) {
            map = this.transformLoop(map);
            if (this.settings.renaming) {
                map = this.rename(map, linkedHashMap);
            }
        }
        object = new HashMap();
        linkedHashMap.forEach((arg_0, arg_1) -> Deobfuscator.lambda$run$0((HashMap)object, arg_0, arg_1));
        this.report.millis(System.currentTimeMillis() - l);
        ObfuscationDetector.summarize(this.report, map.size());
        return new Result(map, (Map<String, String>)object, linkedHashMap, this.report);
    }

    private static void updateNames(Map<String, String> map, HierarchyRemapper hierarchyRemapper) {
        map.replaceAll((string, string2) -> {
            String string3 = hierarchyRemapper.map((String)string2);
            return string3 == null ? string2 : string3;
        });
    }

    private void checkCancel() {
        if (this.progress.isCancelled() || Thread.currentThread().isInterrupted()) {
            throw new CancellationException();
        }
    }

    private Map<String, byte[]> transformLoop(Map<String, byte[]> map) {
        ConcurrentHashMap<String, byte[]> concurrentHashMap = new ConcurrentHashMap<String, byte[]>(map);
        ClassHierarchy classHierarchy = new ClassHierarchy(concurrentHashMap::get);
        ConcurrentHashMap<String, Boolean> concurrentHashMap2 = new ConcurrentHashMap<String, Boolean>();
        ArrayList<String> arrayList = new ArrayList<String>(concurrentHashMap.keySet());
        AtomicInteger atomicInteger = new AtomicInteger();
        this.progress.update("Verifying classes", 0, arrayList.size());
        arrayList.parallelStream().forEach(string -> {
            if (this.progress.isCancelled()) {
                return;
            }
            concurrentHashMap2.put((String)string, ClassUtil.verify((byte[])concurrentHashMap.get(string), classHierarchy) == null);
            this.progress.update("Verifying classes", atomicInteger.incrementAndGet(), arrayList.size());
        });
        this.checkCancel();
        long l = concurrentHashMap2.values().stream().filter(bl -> bl == false).count();
        if (l > 0L) {
            this.report.log(l + " classes did not verify before deobfuscation.");
        }
        ArrayList<Transformer> arrayList2 = new ArrayList<Transformer>();
        if (this.settings.junkCode) {
            arrayList2.add(new JunkCodeRemover());
        }
        if (this.settings.constantFolding) {
            arrayList2.add(new ConstantFolder());
        }
        if (this.settings.stringDecryption) {
            arrayList2.add(new StringDecryptor());
        }
        if (this.settings.indyResolution) {
            arrayList2.add(new IndyResolver());
        }
        if (this.settings.debugInfo) {
            this.step(new DebugInfoCleaner(), concurrentHashMap, classHierarchy, concurrentHashMap2, arrayList, 0);
        }
        int n = 0;
        while (n < this.settings.maxPasses && !arrayList2.isEmpty()) {
            ++n;
            boolean bl2 = false;
            for (Transformer transformer : arrayList2) {
                this.checkCancel();
                bl2 |= this.step(transformer, concurrentHashMap, classHierarchy, concurrentHashMap2, arrayList, n);
            }
            if (bl2) continue;
        }
        this.report.passes(n);
        return new TreeMap<String, byte[]>(concurrentHashMap);
    }

    private boolean step(Transformer transformer, Map<String, byte[]> map, ClassHierarchy classHierarchy, Map<String, Boolean> map2, List<String> list, int n) {
        Map<String, byte[]> map3 = Map.copyOf(map);
        TransformContext transformContext = new TransformContext(map3, classHierarchy, this.settings, this.report);
        String string = (String)(n > 0 ? "Pass " + n + ": " : "") + transformer.name();
        this.progress.update(string, 0, list.size());
        try {
            transformer.prepare(transformContext);
        }
        catch (RuntimeException runtimeException) {
            this.report.log(transformer.name() + " skipped: " + String.valueOf(runtimeException));
            return false;
        }
        AtomicInteger atomicInteger = new AtomicInteger();
        AtomicInteger atomicInteger2 = new AtomicInteger();
        list.parallelStream().forEach(string2 -> {
            if (this.progress.isCancelled()) {
                return;
            }
            try {
                if (this.apply(transformer, (String)string2, (byte[])map3.get(string2), transformContext, classHierarchy, map2, map)) {
                    atomicInteger2.incrementAndGet();
                }
            }
            finally {
                int n = atomicInteger.incrementAndGet();
                if ((n & 0x1F) == 0 || n == list.size()) {
                    this.progress.update(string, n, list.size());
                }
            }
        });
        this.checkCancel();
        return atomicInteger2.get() > 0;
    }

    private boolean apply(Transformer transformer, String string, byte[] byArray, TransformContext transformContext, ClassHierarchy classHierarchy, Map<String, Boolean> map, Map<String, byte[]> map2) {
        byte[] byArray2;
        boolean bl;
        ClassNode classNode;
        try {
            if (!transformer.mayApply(byArray)) {
                return false;
            }
            classNode = ClassUtil.read(byArray);
        }
        catch (Exception | StackOverflowError throwable) {
            return false;
        }
        Counters counters = new Counters();
        try {
            bl = transformer.transform(classNode, transformContext, counters);
        }
        catch (CancellationException cancellationException) {
            throw cancellationException;
        }
        catch (Exception | StackOverflowError throwable) {
            this.report.log(transformer.name() + " failed on " + string + ": " + String.valueOf(throwable));
            return false;
        }
        if (!bl) {
            return false;
        }
        try {
            byArray2 = ClassUtil.write(classNode, classHierarchy);
        }
        catch (Exception | StackOverflowError throwable) {
            this.report.add(Stat.REVERTED, 1L);
            this.report.log("Reverted " + transformer.name() + " on " + string + " (could not write class: " + String.valueOf(throwable) + ")");
            return false;
        }
        String string2 = ClassUtil.verify(byArray2, classHierarchy);
        boolean bl2 = map.getOrDefault(string, true);
        if (string2 != null && bl2) {
            this.report.add(Stat.REVERTED, 1L);
            this.report.log("Reverted " + transformer.name() + " on " + string + ": " + string2);
            return false;
        }
        map2.put(string, byArray2);
        map.put(string, string2 == null);
        this.report.merge(counters);
        return true;
    }

    private Map<String, byte[]> rename(Map<String, byte[]> map, Map<String, String> map2) {
        Map<String, byte[]> map3;
        HierarchyRemapper hierarchyRemapper;
        this.checkCancel();
        this.progress.update("Renaming", 0, 1);
        ClassHierarchy classHierarchy = new ClassHierarchy(map);
        try {
            hierarchyRemapper = new Renamer().renameShortNames(this.settings.renameShortNames).computeMapping(map, classHierarchy);
        }
        catch (RuntimeException runtimeException) {
            this.report.log("Renaming skipped: " + String.valueOf(runtimeException));
            return map;
        }
        if (hierarchyRemapper.isEmpty()) {
            return map;
        }
        try {
            map3 = hierarchyRemapper.apply(map);
        }
        catch (RuntimeException runtimeException) {
            this.report.log("Renaming failed and was undone: " + String.valueOf(runtimeException));
            return map;
        }
        ClassHierarchy classHierarchy2 = new ClassHierarchy(map3);
        this.progress.update("Verifying renamed classes", 0, map.size());
        List list = Collections.synchronizedList(new ArrayList());
        map.keySet().parallelStream().forEach(string -> {
            String string2 = hierarchyRemapper.classes.getOrDefault(string, (String)string);
            byte[] byArray = (byte[])map3.get(string2);
            if (byArray == null) {
                list.add(string + " (lost)");
                return;
            }
            String string3 = ClassUtil.verify(byArray, classHierarchy2);
            if (string3 != null && ClassUtil.verify((byte[])map.get(string), classHierarchy) == null) {
                list.add(string + ": " + string3);
            }
        });
        if (!list.isEmpty()) {
            this.report.log("Renaming was undone because " + list.size() + " class(es) failed verification, e.g. " + (String)list.get(0));
            return map;
        }
        this.report.add(Stat.RENAMED_CLASSES, hierarchyRemapper.renamedClassCount);
        this.report.add(Stat.RENAMED_PACKAGES, hierarchyRemapper.renamedPackageCount);
        this.report.add(Stat.RENAMED_METHODS, hierarchyRemapper.methods.size());
        this.report.add(Stat.RENAMED_FIELDS, hierarchyRemapper.fields.size());
        Deobfuscator.updateNames(map2, hierarchyRemapper);
        return new TreeMap<String, byte[]>(map3);
    }

    private static /* synthetic */ void lambda$run$0(HashMap hashMap, String string, String string2) {
        hashMap.put(string2, string);
    }

    public static interface Progress {
        public void update(String var1, int var2, int var3);

        default public boolean isCancelled() {
            return false;
        }
    }

    public record Result(Map<String, byte[]> classes, Map<String, String> newToOriginal, Map<String, String> originalToNew, DeobReport report) {
        public String originalName(String string) {
            return this.newToOriginal.getOrDefault(string, string);
        }

        public String currentName(String string) {
            return this.originalToNew.getOrDefault(string, string);
        }
    }
}

