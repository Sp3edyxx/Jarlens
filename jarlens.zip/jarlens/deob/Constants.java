/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.LdcInsnNode;

public final class Constants {
    public static final Object NULL = new Object(){

        public String toString() {
            return "null";
        }
    };

    private Constants() {
    }

    public static Object value(AbstractInsnNode abstractInsnNode) {
        if (abstractInsnNode == null) {
            return null;
        }
        int n = abstractInsnNode.getOpcode();
        if (n >= 2 && n <= 8) {
            return n - 3;
        }
        switch (n) {
            case 1: {
                return NULL;
            }
            case 9: {
                return 0L;
            }
            case 10: {
                return 1L;
            }
            case 11: {
                return Float.valueOf(0.0f);
            }
            case 12: {
                return Float.valueOf(1.0f);
            }
            case 13: {
                return Float.valueOf(2.0f);
            }
            case 14: {
                return 0.0;
            }
            case 15: {
                return 1.0;
            }
            case 16: 
            case 17: {
                return ((IntInsnNode)abstractInsnNode).operand;
            }
            case 18: {
                Type type;
                Object object = ((LdcInsnNode)abstractInsnNode).cst;
                if (object instanceof Integer || object instanceof Long || object instanceof Float || object instanceof Double || object instanceof String) {
                    return object;
                }
                if (object instanceof Type && (type = (Type)object).getSort() != 11) {
                    return type;
                }
                return null;
            }
        }
        return null;
    }

    public static Integer intValue(AbstractInsnNode abstractInsnNode) {
        Integer n;
        Object object = Constants.value(abstractInsnNode);
        return object instanceof Integer ? (n = (Integer)object) : null;
    }

    public static boolean isWide(Object object) {
        return object instanceof Long || object instanceof Double;
    }

    public static AbstractInsnNode push(Object object) {
        Comparable<Boolean> comparable;
        if (object == NULL || object == null) {
            return new InsnNode(1);
        }
        if (object instanceof Boolean) {
            comparable = (Boolean)object;
            object = ((Boolean)comparable).booleanValue() ? 1 : 0;
        }
        if (object instanceof Character) {
            comparable = (Character)object;
            object = (int)((Character)comparable).charValue();
        }
        if (object instanceof Byte || object instanceof Short) {
            object = ((Number)object).intValue();
        }
        if (object instanceof Integer) {
            comparable = (Integer)object;
            int n = (Integer)comparable;
            if (n >= -1 && n <= 5) {
                return new InsnNode(3 + n);
            }
            if (n >= -128 && n <= 127) {
                return new IntInsnNode(16, n);
            }
            if (n >= Short.MIN_VALUE && n <= Short.MAX_VALUE) {
                return new IntInsnNode(17, n);
            }
            return new LdcInsnNode((Object)n);
        }
        if (object instanceof Long) {
            comparable = (Long)object;
            if ((Long)comparable == 0L) {
                return new InsnNode(9);
            }
            if ((Long)comparable == 1L) {
                return new InsnNode(10);
            }
            return new LdcInsnNode(comparable);
        }
        if (object instanceof Float) {
            comparable = (Float)object;
            if (Float.floatToRawIntBits(((Float)comparable).floatValue()) == 0) {
                return new InsnNode(11);
            }
            if (((Float)comparable).floatValue() == 1.0f) {
                return new InsnNode(12);
            }
            if (((Float)comparable).floatValue() == 2.0f) {
                return new InsnNode(13);
            }
            return new LdcInsnNode(comparable);
        }
        if (object instanceof Double) {
            comparable = (Double)object;
            if (Double.doubleToRawLongBits((Double)comparable) == 0L) {
                return new InsnNode(14);
            }
            if ((Double)comparable == 1.0) {
                return new InsnNode(15);
            }
            return new LdcInsnNode(comparable);
        }
        if (object instanceof String || object instanceof Type) {
            return new LdcInsnNode(object);
        }
        throw new IllegalArgumentException("not a constant: " + String.valueOf(object.getClass()));
    }

    public static Object defaultValue(Type type) {
        return switch (type.getSort()) {
            case 1, 2, 3, 4, 5 -> 0;
            case 7 -> 0L;
            case 6 -> Float.valueOf(0.0f);
            case 8 -> 0.0;
            default -> NULL;
        };
    }

    public static Object normalize(Object object, Type type) {
        if (object == NULL) {
            return object;
        }
        switch (type.getSort()) {
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: {
                if (!(object instanceof Integer)) {
                    return null;
                }
                Integer n = (Integer)object;
                return switch (type.getSort()) {
                    case 1 -> n & 1;
                    case 2 -> n & 0xFFFF;
                    case 3 -> (byte)n.intValue();
                    case 4 -> (short)n.intValue();
                    default -> n;
                };
            }
            case 7: {
                return object instanceof Long ? object : null;
            }
            case 6: {
                return object instanceof Float ? object : null;
            }
            case 8: {
                return object instanceof Double ? object : null;
            }
        }
        return object instanceof String ? object : null;
    }
}

