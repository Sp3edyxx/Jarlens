/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.emu;

import dev.jarlens.deob.emu.EmuObjects;
import dev.jarlens.deob.emu.Emulator;
import java.util.List;
import java.util.Set;
import org.objectweb.asm.Type;

final class SymbolicApi {
    private static final Set<String> STATIC_OWNERS = Set.of("java/lang/invoke/MethodHandles", "java/lang/invoke/MethodType", "java/lang/Class", "java/lang/ClassLoader", "java/lang/Thread");
    private static final Set<String> CONSTRUCTED = Set.of("java/lang/invoke/ConstantCallSite", "java/lang/invoke/MutableCallSite", "java/lang/invoke/VolatileCallSite");

    private SymbolicApi() {
    }

    static boolean handlesStatic(String string) {
        return STATIC_OWNERS.contains(string);
    }

    static boolean handlesConstructor(String string) {
        return CONSTRUCTED.contains(string);
    }

    static Object invokeStatic(Emulator emulator, String string, String string2, String string3, Object[] objectArray) {
        switch (string) {
            case "java/lang/invoke/MethodHandles": {
                if (string2.equals("lookup") || string2.equals("publicLookup")) {
                    return new EmuObjects.EmuLookup(emulator.currentClassName);
                }
                if (!string2.equals("privateLookupIn")) break;
                return new EmuObjects.EmuLookup(SymbolicApi.cls((Object)objectArray[0]).type.getInternalName());
            }
            case "java/lang/Class": {
                if (!string2.equals("forName")) break;
                return SymbolicApi.classForName(objectArray[0]);
            }
            case "java/lang/ClassLoader": {
                if (!string2.equals("getSystemClassLoader") && !string2.equals("getPlatformClassLoader")) break;
                return new EmuObjects.Opaque("java/lang/ClassLoader");
            }
            case "java/lang/Thread": {
                if (!string2.equals("currentThread")) break;
                return new EmuObjects.Opaque("java/lang/Thread");
            }
            case "java/lang/invoke/MethodType": {
                return SymbolicApi.methodTypeStatic(string2, string3, objectArray);
            }
        }
        throw new Emulator.EmulationException("unsupported " + string + "." + string2 + string3);
    }

    private static EmuObjects.EmuClass classForName(Object object) {
        String string;
        if (!(object instanceof String) || (string = (String)object).isEmpty()) {
            throw new Emulator.EmulationException("Class.forName with non-constant name");
        }
        String string2 = string.replace('.', '/');
        return new EmuObjects.EmuClass(string2.startsWith("[") ? Type.getType(string2) : Type.getObjectType(string2));
    }

    private static Object methodTypeStatic(String string, String string2, Object[] objectArray) {
        switch (string) {
            case "fromMethodDescriptorString": {
                Object object = objectArray[0];
                if (!(object instanceof String)) {
                    throw new Emulator.EmulationException("non-constant descriptor");
                }
                String string3 = (String)object;
                try {
                    Type type = Type.getMethodType(string3);
                    type.getArgumentTypes();
                    return new EmuObjects.EmuMethodType(type.getDescriptor());
                }
                catch (RuntimeException runtimeException) {
                    throw new Emulator.EmulationException("bad method descriptor");
                }
            }
            case "methodType": {
                Object object;
                Type[] typeArray;
                Type type = SymbolicApi.cls((Object)objectArray[0]).type;
                if (objectArray.length == 1) {
                    typeArray = new Type[]{};
                } else if (objectArray.length == 2 && (object = objectArray[1]) instanceof EmuObjects.EmuMethodType) {
                    EmuObjects.EmuMethodType emuMethodType = (EmuObjects.EmuMethodType)object;
                    typeArray = Type.getArgumentTypes(emuMethodType.desc);
                } else if (objectArray.length == 2 && (object = objectArray[1]) instanceof Object[]) {
                    Object[] objectArray2 = (Object[])object;
                    typeArray = SymbolicApi.types(objectArray2);
                } else if (objectArray.length == 2 && (object = objectArray[1]) instanceof List) {
                    List list = (List)object;
                    typeArray = SymbolicApi.types(list.toArray());
                } else if (objectArray.length == 2) {
                    typeArray = new Type[]{SymbolicApi.cls((Object)objectArray[1]).type};
                } else if (objectArray.length == 3 && (object = objectArray[2]) instanceof Object[]) {
                    Object[] objectArray3 = (Object[])object;
                    Type[] typeArray2 = SymbolicApi.types(objectArray3);
                    typeArray = new Type[typeArray2.length + 1];
                    typeArray[0] = SymbolicApi.cls((Object)objectArray[1]).type;
                    System.arraycopy(typeArray2, 0, typeArray, 1, typeArray2.length);
                } else {
                    throw new Emulator.EmulationException("unsupported MethodType.methodType" + string2);
                }
                return new EmuObjects.EmuMethodType(Type.getMethodDescriptor(type, typeArray));
            }
        }
        throw new Emulator.EmulationException("unsupported MethodType." + string);
    }

    private static Type[] types(Object[] objectArray) {
        Type[] typeArray = new Type[objectArray.length];
        for (int i = 0; i < objectArray.length; ++i) {
            typeArray[i] = SymbolicApi.cls((Object)objectArray[i]).type;
        }
        return typeArray;
    }

    private static EmuObjects.EmuClass cls(Object object) {
        if (object instanceof EmuObjects.EmuClass) {
            EmuObjects.EmuClass emuClass = (EmuObjects.EmuClass)object;
            return emuClass;
        }
        throw new Emulator.EmulationException("expected a Class value");
    }

    private static EmuObjects.EmuMethodType mt(Object object) {
        if (object instanceof EmuObjects.EmuMethodType) {
            EmuObjects.EmuMethodType emuMethodType = (EmuObjects.EmuMethodType)object;
            return emuMethodType;
        }
        throw new Emulator.EmulationException("expected a MethodType value");
    }

    private static String str(Object object) {
        if (object instanceof String) {
            String string = (String)object;
            return string;
        }
        throw new Emulator.EmulationException("expected a String value");
    }

    static Object construct(String string, String string2, Object[] objectArray) {
        Object object;
        if (objectArray.length == 1 && (object = objectArray[0]) instanceof EmuObjects.EmuMethodHandle) {
            EmuObjects.EmuMethodHandle emuMethodHandle = (EmuObjects.EmuMethodHandle)object;
            return new EmuObjects.EmuCallSite(emuMethodHandle, string);
        }
        if (objectArray.length == 1 && objectArray[0] instanceof EmuObjects.EmuMethodType && !string.equals("java/lang/invoke/ConstantCallSite")) {
            return new EmuObjects.EmuCallSite(null, string);
        }
        throw new Emulator.EmulationException("unsupported call site construction " + string + string2);
    }

    static Object invokeOnToken(Emulator emulator, EmuObjects.Token token, String string, String string2, String string3, Object[] objectArray) {
        if (token instanceof EmuObjects.EmuLookup) {
            EmuObjects.EmuLookup emuLookup = (EmuObjects.EmuLookup)token;
            return SymbolicApi.lookup(emulator, emuLookup, string2, objectArray);
        }
        if (token instanceof EmuObjects.EmuMethodHandle) {
            EmuObjects.EmuMethodHandle emuMethodHandle = (EmuObjects.EmuMethodHandle)token;
            switch (string2) {
                case "asType": {
                    SymbolicApi.mt(objectArray[0]);
                    return emuMethodHandle;
                }
                case "asFixedArity": {
                    return emuMethodHandle;
                }
                case "withVarargs": {
                    return emuMethodHandle;
                }
                case "type": {
                    return new EmuObjects.EmuMethodType(emuMethodHandle.invocationType());
                }
            }
            throw new Emulator.EmulationException("unsupported MethodHandle." + string2);
        }
        if (token instanceof EmuObjects.EmuCallSite) {
            EmuObjects.EmuCallSite emuCallSite = (EmuObjects.EmuCallSite)token;
            switch (string2) {
                case "setTarget": {
                    EmuObjects.EmuMethodHandle emuMethodHandle;
                    Object object = objectArray[0];
                    if (!(object instanceof EmuObjects.EmuMethodHandle)) {
                        throw new Emulator.EmulationException("non-direct call site target");
                    }
                    emuCallSite.target = emuMethodHandle = (EmuObjects.EmuMethodHandle)object;
                    return null;
                }
                case "getTarget": {
                    if (emuCallSite.target == null) {
                        throw new Emulator.EmulationException("call site without target");
                    }
                    return emuCallSite.target;
                }
            }
            throw new Emulator.EmulationException("unsupported CallSite." + string2);
        }
        if (token instanceof EmuObjects.EmuMethodType) {
            EmuObjects.EmuMethodType emuMethodType = (EmuObjects.EmuMethodType)token;
            Type type = Type.getMethodType(emuMethodType.desc);
            switch (string2) {
                case "toMethodDescriptorString": {
                    return emuMethodType.desc;
                }
                case "parameterCount": {
                    return type.getArgumentTypes().length;
                }
                case "returnType": {
                    return new EmuObjects.EmuClass(type.getReturnType());
                }
                case "parameterType": {
                    return new EmuObjects.EmuClass(type.getArgumentTypes()[(Integer)objectArray[0]]);
                }
                case "parameterArray": {
                    Type[] typeArray = type.getArgumentTypes();
                    Object[] objectArray2 = new Object[typeArray.length];
                    for (int i = 0; i < typeArray.length; ++i) {
                        objectArray2[i] = new EmuObjects.EmuClass(typeArray[i]);
                    }
                    return objectArray2;
                }
                case "changeReturnType": {
                    return new EmuObjects.EmuMethodType(Type.getMethodDescriptor(SymbolicApi.cls((Object)objectArray[0]).type, type.getArgumentTypes()));
                }
                case "equals": {
                    return emuMethodType.equals(objectArray[0]) ? 1 : 0;
                }
            }
            throw new Emulator.EmulationException("unsupported MethodType." + string2);
        }
        if (token instanceof EmuObjects.EmuClass) {
            EmuObjects.EmuClass emuClass = (EmuObjects.EmuClass)token;
            switch (string2) {
                case "getName": 
                case "getTypeName": {
                    return emuClass.javaName();
                }
                case "getSimpleName": {
                    String string4 = emuClass.javaName();
                    return string4.substring(string4.lastIndexOf(46) + 1);
                }
                case "getClassLoader": {
                    return new EmuObjects.Opaque("java/lang/ClassLoader");
                }
                case "desiredAssertionStatus": {
                    return 0;
                }
                case "isInterface": {
                    return emuClass.type.getSort() == 10 && emulator.hierarchy().isInterface(emuClass.type.getInternalName()) ? 1 : 0;
                }
                case "isArray": {
                    return emuClass.type.getSort() == 9 ? 1 : 0;
                }
                case "isPrimitive": {
                    return emuClass.type.getSort() < 9 ? 1 : 0;
                }
                case "equals": {
                    return emuClass.equals(objectArray[0]) ? 1 : 0;
                }
                case "hashCode": {
                    return emuClass.javaName().hashCode();
                }
            }
            throw new Emulator.EmulationException("unsupported Class." + string2);
        }
        if (token instanceof EmuObjects.Opaque) {
            EmuObjects.Opaque opaque = (EmuObjects.Opaque)token;
            if (opaque.type.equals("java/lang/Thread") && string2.equals("getContextClassLoader")) {
                return new EmuObjects.Opaque("java/lang/ClassLoader");
            }
            if (opaque.type.equals("java/lang/ClassLoader") && string2.equals("loadClass")) {
                return SymbolicApi.classForName(objectArray[0]);
            }
            throw new Emulator.EmulationException("unsupported " + opaque.type + "." + string2);
        }
        throw new Emulator.EmulationException("unsupported call on symbolic value: " + string + "." + string2);
    }

    private static Object lookup(Emulator emulator, EmuObjects.EmuLookup emuLookup, String string, Object[] objectArray) {
        switch (string) {
            case "lookupClass": {
                return new EmuObjects.EmuClass(Type.getObjectType(emuLookup.lookupClass));
            }
            case "in": {
                return new EmuObjects.EmuLookup(SymbolicApi.cls((Object)objectArray[0]).type.getInternalName());
            }
            case "findStatic": {
                return SymbolicApi.handle(emulator, 6, SymbolicApi.cls(objectArray[0]), SymbolicApi.str(objectArray[1]), SymbolicApi.mt((Object)objectArray[2]).desc);
            }
            case "findVirtual": {
                EmuObjects.EmuClass emuClass = SymbolicApi.cls(objectArray[0]);
                boolean bl = emuClass.type.getSort() == 10 && emulator.hierarchy().isInterface(emuClass.type.getInternalName());
                return SymbolicApi.handle(emulator, bl ? 9 : 5, emuClass, SymbolicApi.str(objectArray[1]), SymbolicApi.mt((Object)objectArray[2]).desc);
            }
            case "findSpecial": {
                return SymbolicApi.handle(emulator, 7, SymbolicApi.cls(objectArray[0]), SymbolicApi.str(objectArray[1]), SymbolicApi.mt((Object)objectArray[2]).desc);
            }
            case "findConstructor": {
                return SymbolicApi.handle(emulator, 8, SymbolicApi.cls(objectArray[0]), "<init>", SymbolicApi.mt((Object)objectArray[1]).desc);
            }
            case "findGetter": {
                return SymbolicApi.handle(emulator, 1, SymbolicApi.cls(objectArray[0]), SymbolicApi.str(objectArray[1]), SymbolicApi.cls((Object)objectArray[2]).type.getDescriptor());
            }
            case "findSetter": {
                return SymbolicApi.handle(emulator, 3, SymbolicApi.cls(objectArray[0]), SymbolicApi.str(objectArray[1]), SymbolicApi.cls((Object)objectArray[2]).type.getDescriptor());
            }
            case "findStaticGetter": {
                return SymbolicApi.handle(emulator, 2, SymbolicApi.cls(objectArray[0]), SymbolicApi.str(objectArray[1]), SymbolicApi.cls((Object)objectArray[2]).type.getDescriptor());
            }
            case "findStaticSetter": {
                return SymbolicApi.handle(emulator, 4, SymbolicApi.cls(objectArray[0]), SymbolicApi.str(objectArray[1]), SymbolicApi.cls((Object)objectArray[2]).type.getDescriptor());
            }
        }
        throw new Emulator.EmulationException("unsupported Lookup." + string);
    }

    private static EmuObjects.EmuMethodHandle handle(Emulator emulator, int n, EmuObjects.EmuClass emuClass, String string, String string2) {
        if (emuClass.type.getSort() != 10) {
            throw new Emulator.EmulationException("handle on non-class type");
        }
        String string3 = emuClass.type.getInternalName();
        boolean bl = emulator.hierarchy().isInterface(string3);
        return new EmuObjects.EmuMethodHandle(n, string3, string, string2, bl);
    }
}

