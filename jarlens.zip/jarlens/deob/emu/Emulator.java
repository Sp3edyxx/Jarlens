/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.emu;

import dev.jarlens.core.ClassHierarchy;
import dev.jarlens.deob.ClassUtil;
import dev.jarlens.deob.Constants;
import dev.jarlens.deob.analysis.Folding;
import dev.jarlens.deob.emu.EmuObjects;
import dev.jarlens.deob.emu.JdkAllowlist;
import dev.jarlens.deob.emu.SymbolicApi;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.IincInsnNode;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.LookupSwitchInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.MultiANewArrayInsnNode;
import org.objectweb.asm.tree.TableSwitchInsnNode;
import org.objectweb.asm.tree.TryCatchBlockNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

public final class Emulator {
    private static final int MAX_DEPTH = 160;
    private static final long TIME_LIMIT_NANOS = 4000000000L;
    private static final int STATE_RUNNING = 1;
    private static final int STATE_DONE = 2;
    private static final int STATE_FAILED = 3;
    private final Function<String, byte[]> classBytes;
    private final ClassHierarchy hierarchy;
    private final int callLimit;
    private final int clinitLimit;
    private final Map<String, ClassNode> nodes = new HashMap<String, ClassNode>();
    private final Map<String, Map<String, Object>> statics = new HashMap<String, Map<String, Object>>();
    private final Map<String, Integer> initState = new HashMap<String, Integer>();
    private final Set<String> poisoned = new HashSet<String>();
    private final Map<MethodNode, MethodData> methodData = new IdentityHashMap<MethodNode, MethodData>();
    private long budget;
    private long deadline;
    private int depth;
    private int clinitDepth;
    private StaticReadPolicy staticReadPolicy = (string, string2, string3) -> true;
    String currentClassName;
    private static final int RETURNED = -1;
    private Object returnValue;

    public void setStaticReadPolicy(StaticReadPolicy staticReadPolicy) {
        this.staticReadPolicy = staticReadPolicy == null ? (string, string2, string3) -> true : staticReadPolicy;
    }

    public Emulator(Function<String, byte[]> function, ClassHierarchy classHierarchy, int n, int n2) {
        this.classBytes = function;
        this.hierarchy = classHierarchy;
        this.callLimit = n;
        this.clinitLimit = n2;
    }

    public Object invokeStatic(String string, String string2, String string3, Object ... objectArray) {
        this.startCall();
        Resolved resolved = this.resolveMethod(string, string2, string3, true);
        if (resolved == null) {
            throw new EmulationException("method not found " + string + "." + string2 + string3);
        }
        if ((resolved.method.access & 8) == 0) {
            throw new EmulationException("not static");
        }
        this.ensureInit(resolved.owner.name);
        try {
            return this.execute(resolved.owner, resolved.method, objectArray);
        }
        catch (EmuThrow emuThrow) {
            throw new EmulationException("emulated code threw " + Emulator.describe(emuThrow.exception));
        }
    }

    public Object evaluate(String string, MethodNode methodNode) {
        this.startCall();
        ClassNode classNode = this.node(string);
        if (classNode == null) {
            throw new EmulationException("unknown context class");
        }
        try {
            return this.execute(classNode, methodNode, new Object[0]);
        }
        catch (EmuThrow emuThrow) {
            throw new EmulationException("emulated code threw " + Emulator.describe(emuThrow.exception));
        }
    }

    public Object readStatic(String string, String string2, String string3) {
        this.startCall();
        String string4 = this.hierarchy.resolveFieldOwner(string, string2, string3);
        if (string4 == null) {
            string4 = string;
        }
        if (this.classBytes.apply(string4) == null) {
            throw new EmulationException("not a jar class");
        }
        try {
            this.ensureInit(string4);
        }
        catch (EmuThrow emuThrow) {
            throw new EmulationException("static initializer threw " + Emulator.describe(emuThrow.exception));
        }
        if (this.poisoned.contains(string4)) {
            throw new EmulationException("static initializer of " + string4 + " failed");
        }
        return this.staticsOf(string4).getOrDefault(string2 + ":" + string3, Emulator.defaultValue(Type.getType(string3)));
    }

    public boolean initialize(String string) {
        this.startCall();
        try {
            this.ensureInit(string);
            return !this.poisoned.contains(string);
        }
        catch (EmuThrow | EmulationException runtimeException) {
            return false;
        }
    }

    public EmuObjects.EmuCallSite invokeBootstrap(String string, Handle handle, String string2, String string3, Object[] objectArray) {
        Object object;
        this.startCall();
        if (handle.getTag() != 6) {
            throw new EmulationException("bootstrap is not static");
        }
        Resolved resolved = this.resolveMethod(handle.getOwner(), handle.getName(), handle.getDesc(), true);
        if (resolved == null) {
            throw new EmulationException("bootstrap not found");
        }
        ArrayList<Object> arrayList = new ArrayList<Object>();
        arrayList.add(new EmuObjects.EmuLookup(string));
        arrayList.add(string2);
        arrayList.add(new EmuObjects.EmuMethodType(string3));
        for (Object object2 : objectArray) {
            arrayList.add(this.convertConstant(object2));
        }
        Object[] objectArray2 = Type.getArgumentTypes(handle.getDesc());
        Object[] objectArray3 = Emulator.packVarargs((Type[])objectArray2, arrayList);
        this.ensureInit(resolved.owner.name);
        try {
            object = this.execute(resolved.owner, resolved.method, objectArray3);
        }
        catch (EmuThrow emuThrow) {
            throw new EmulationException("bootstrap threw " + Emulator.describe(emuThrow.exception));
        }
        if (object instanceof EmuObjects.EmuCallSite) {
            EmuObjects.EmuCallSite emuCallSite = (EmuObjects.EmuCallSite)object;
            if (emuCallSite.target != null) {
                return emuCallSite;
            }
        }
        throw new EmulationException("bootstrap did not return a resolvable call site");
    }

    private static Object[] packVarargs(Type[] typeArray, List<Object> list) {
        Object[] objectArray;
        if (typeArray.length == list.size()) {
            Type type = typeArray.length == 0 ? null : typeArray[typeArray.length - 1];
            objectArray = list.isEmpty() ? null : list.get(list.size() - 1);
            Object[] objectArray2 = objectArray;
            if (type == null || type.getSort() != 9 || objectArray instanceof Object[]) {
                return list.toArray();
            }
        }
        if (typeArray.length == 0 || typeArray[typeArray.length - 1].getSort() != 9 || list.size() < typeArray.length - 1) {
            throw new EmulationException("bootstrap signature mismatch");
        }
        objectArray = new Object[typeArray.length];
        for (int i = 0; i < typeArray.length - 1; ++i) {
            objectArray[i] = list.get(i);
        }
        Object[] objectArray3 = new Object[list.size() - (typeArray.length - 1)];
        for (int i = 0; i < objectArray3.length; ++i) {
            objectArray3[i] = list.get(typeArray.length - 1 + i);
        }
        objectArray[typeArray.length - 1] = objectArray3;
        return objectArray;
    }

    private void startCall() {
        this.budget = this.callLimit;
        this.deadline = System.nanoTime() + 4000000000L;
        this.depth = 0;
    }

    ClassNode node(String string) {
        ClassNode classNode = this.nodes.get(string);
        if (classNode != null) {
            return classNode;
        }
        byte[] byArray = this.classBytes.apply(string);
        if (byArray == null) {
            return null;
        }
        try {
            classNode = ClassUtil.read(byArray);
        }
        catch (Exception | StackOverflowError throwable) {
            throw new EmulationException("cannot parse " + string);
        }
        this.nodes.put(string, classNode);
        return classNode;
    }

    boolean isJarClass(String string) {
        return this.classBytes.apply(string) != null;
    }

    private static MethodNode findDeclared(ClassNode classNode, String string, String string2) {
        for (MethodNode methodNode : classNode.methods) {
            if (!methodNode.name.equals(string) || !methodNode.desc.equals(string2)) continue;
            return methodNode;
        }
        return null;
    }

    private Resolved resolveMethod(String string, String string2, String string3, boolean bl) {
        String string4 = string;
        HashSet<String> hashSet = new HashSet<String>();
        while (string4 != null && hashSet.add(string4)) {
            ClassNode classNode = this.node(string4);
            if (classNode == null) {
                return null;
            }
            MethodNode object = Emulator.findDeclared(classNode, string2, string3);
            if (object != null) {
                return new Resolved(classNode, object);
            }
            string4 = classNode.superName;
        }
        if (bl) {
            for (String string5 : this.hierarchy.allSupertypes(string)) {
                MethodNode methodNode;
                ClassNode classNode = this.node(string5);
                if (classNode == null || (methodNode = Emulator.findDeclared(classNode, string2, string3)) == null || (methodNode.access & 0x400) != 0) continue;
                return new Resolved(classNode, methodNode);
            }
        }
        return null;
    }

    private Map<String, Object> staticsOf(String string2) {
        return this.statics.computeIfAbsent(string2, string -> new HashMap());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void ensureInit(String string) {
        Integer n = this.initState.get(string);
        if (n != null) {
            return;
        }
        ClassNode classNode = this.node(string);
        if (classNode == null) {
            return;
        }
        this.initState.put(string, 1);
        if (classNode.superName != null && this.isJarClass(classNode.superName)) {
            this.ensureInit(classNode.superName);
        }
        Map<String, Object> map = this.staticsOf(string);
        for (FieldNode fieldNode : classNode.fields) {
            if ((fieldNode.access & 8) == 0 || fieldNode.value == null) continue;
            map.put(fieldNode.name + ":" + fieldNode.desc, Emulator.normalizeConstant(fieldNode.value, Type.getType(fieldNode.desc)));
        }
        MethodNode methodNode = Emulator.findDeclared(classNode, "<clinit>", "()V");
        if (methodNode == null) {
            this.initState.put(string, 2);
            return;
        }
        long l = this.budget;
        long l2 = this.deadline;
        int n2 = this.depth;
        this.budget = this.clinitLimit;
        this.deadline = System.nanoTime() + 8000000000L;
        ++this.clinitDepth;
        try {
            this.execute(classNode, methodNode, new Object[0]);
            this.initState.put(string, 2);
        }
        catch (EmuThrow | EmulationException runtimeException) {
            this.initState.put(string, 3);
            this.poisoned.add(string);
        }
        finally {
            --this.clinitDepth;
            this.budget = l;
            this.deadline = l2;
            this.depth = n2;
        }
    }

    private static Object normalizeConstant(Object object, Type type) {
        Object object2 = Constants.normalize(object, type);
        return object2 == null ? object : object2;
    }

    static Object defaultValue(Type type) {
        return switch (type.getSort()) {
            case 1, 2, 3, 4, 5 -> 0;
            case 7 -> 0L;
            case 6 -> Float.valueOf(0.0f);
            case 8 -> 0.0;
            default -> null;
        };
    }

    private Object convertConstant(Object object) {
        if (object instanceof Type) {
            Type type = (Type)object;
            return type.getSort() == 11 ? new EmuObjects.EmuMethodType(type.getDescriptor()) : new EmuObjects.EmuClass(type);
        }
        if (object instanceof Handle) {
            Handle handle = (Handle)object;
            return new EmuObjects.EmuMethodHandle(handle.getTag(), handle.getOwner(), handle.getName(), handle.getDesc(), handle.isInterface());
        }
        if (object instanceof ConstantDynamic) {
            throw new EmulationException("constant dynamic not supported");
        }
        return object;
    }

    private MethodData data(MethodNode methodNode) {
        Object object;
        int n;
        MethodData methodData = this.methodData.get(methodNode);
        if (methodData != null) {
            return methodData;
        }
        methodData = new MethodData();
        methodData.insns = methodNode.instructions.toArray();
        methodData.labels = new HashMap<LabelNode, Integer>();
        for (n = 0; n < methodData.insns.length; ++n) {
            object = methodData.insns[n];
            if (!(object instanceof LabelNode)) continue;
            LabelNode labelNode = (LabelNode)object;
            methodData.labels.put(labelNode, n);
        }
        methodData.handlers = new int[methodNode.tryCatchBlocks.size()][];
        methodData.handlerTypes = new String[methodNode.tryCatchBlocks.size()];
        for (n = 0; n < methodNode.tryCatchBlocks.size(); ++n) {
            object = methodNode.tryCatchBlocks.get(n);
            methodData.handlers[n] = new int[]{methodData.labels.get(((TryCatchBlockNode)object).start), methodData.labels.get(((TryCatchBlockNode)object).end), methodData.labels.get(((TryCatchBlockNode)object).handler)};
            methodData.handlerTypes[n] = ((TryCatchBlockNode)object).type;
        }
        this.methodData.put(methodNode, methodData);
        return methodData;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private Object execute(ClassNode classNode, MethodNode methodNode, Object[] objectArray) {
        if ((methodNode.access & 0x500) != 0 || methodNode.instructions.size() == 0) {
            throw new EmulationException("cannot emulate abstract/native method " + classNode.name + "." + methodNode.name);
        }
        if (++this.depth > 160) {
            --this.depth;
            throw new EmulationException("call depth limit");
        }
        String string = this.currentClassName;
        this.currentClassName = classNode.name;
        try {
            Object object;
            MethodData methodData = this.data(methodNode);
            boolean bl = (methodNode.access & 8) != 0;
            Type[] typeArray = Type.getArgumentTypes(methodNode.desc);
            int n = bl ? 0 : 1;
            for (Type type : typeArray) {
                n += type.getSize();
            }
            Frame frame = new Frame(Math.max(methodNode.maxLocals, n), methodNode.maxStack);
            int n2 = 0;
            int n3 = 0;
            if (!bl) {
                frame.locals[n2++] = objectArray[n3++];
            }
            for (Type type : typeArray) {
                frame.locals[n2++] = Emulator.coerceArg(objectArray[n3++], type);
                if (type.getSize() != 2) continue;
                frame.locals[n2++] = EmuObjects.TOP;
            }
            Object object2 = object = this.run(classNode, methodNode, methodData, frame);
            return object2;
        }
        finally {
            this.currentClassName = string;
            --this.depth;
        }
    }

    private static Object coerceArg(Object object, Type type) {
        Comparable<Boolean> comparable;
        if (object instanceof Boolean) {
            comparable = (Boolean)object;
            if (type.getSort() == 1) {
                return ((Boolean)comparable).booleanValue() ? 1 : 0;
            }
        }
        if (object instanceof Character) {
            comparable = (Character)object;
            if (type.getSort() == 2) {
                return (int)((Character)comparable).charValue();
            }
        }
        if ((object instanceof Byte || object instanceof Short) && type.getSort() <= 5) {
            return ((Number)object).intValue();
        }
        return object;
    }

    private int findHandler(MethodData methodData, int n, Object object) {
        for (int i = 0; i < methodData.handlers.length; ++i) {
            String string;
            int[] nArray = methodData.handlers[i];
            if (n < nArray[0] || n >= nArray[1] || (string = methodData.handlerTypes[i]) != null && !this.isInstance(object, string)) continue;
            return nArray[2];
        }
        return -1;
    }

    private Object run(ClassNode classNode, MethodNode methodNode, MethodData methodData, Frame frame) {
        AbstractInsnNode[] abstractInsnNodeArray = methodData.insns;
        int n = 0;
        while (true) {
            if (n >= abstractInsnNodeArray.length) {
                throw new EmulationException("fell off the end of " + methodNode.name);
            }
            if (--this.budget < 0L) {
                throw new EmulationException("instruction limit reached");
            }
            if ((this.budget & 0x3FFL) == 0L && System.nanoTime() > this.deadline) {
                throw new EmulationException("time limit reached");
            }
            AbstractInsnNode abstractInsnNode = abstractInsnNodeArray[n];
            int n2 = abstractInsnNode.getOpcode();
            if (n2 < 0) {
                ++n;
                continue;
            }
            try {
                int n3 = this.step(classNode, methodData, frame, abstractInsnNode, n2, n);
                if (n3 == -1) {
                    return this.returnValue;
                }
                n = n3;
                continue;
            }
            catch (EmuThrow emuThrow) {
                int n4 = this.findHandler(methodData, n, emuThrow.exception);
                if (n4 < 0) {
                    throw emuThrow;
                }
                frame.sp = 0;
                frame.push(emuThrow.exception);
                n = n4;
                continue;
            }
            break;
        }
    }

    private int jump(MethodData methodData, LabelNode labelNode) {
        return methodData.labels.get(labelNode);
    }

    private static EmuThrow jdkThrow(Throwable throwable) {
        return new EmuThrow((Object)throwable);
    }

    private int step(ClassNode classNode, MethodData methodData, Frame frame, AbstractInsnNode abstractInsnNode, int n, int n2) {
        switch (n) {
            case 0: {
                return n2 + 1;
            }
            case 1: {
                frame.push(null);
                return n2 + 1;
            }
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: {
                frame.push(n - 3);
                return n2 + 1;
            }
            case 9: 
            case 10: {
                frame.pushTyped(n - 9, Type.LONG_TYPE);
                return n2 + 1;
            }
            case 11: 
            case 12: 
            case 13: {
                frame.push(Float.valueOf(n - 11));
                return n2 + 1;
            }
            case 14: 
            case 15: {
                frame.pushTyped(n - 14, Type.DOUBLE_TYPE);
                return n2 + 1;
            }
            case 16: 
            case 17: {
                frame.push(((IntInsnNode)abstractInsnNode).operand);
                return n2 + 1;
            }
            case 18: {
                Object object = ((LdcInsnNode)abstractInsnNode).cst;
                if (!(object instanceof Long) && !(object instanceof Double)) {
                    frame.push(this.convertConstant(object));
                    return n2 + 1;
                }
                frame.pushTyped(object, Type.LONG_TYPE);
                return n2 + 1;
            }
            case 21: 
            case 23: 
            case 25: {
                frame.push(frame.locals[((VarInsnNode)abstractInsnNode).var]);
                return n2 + 1;
            }
            case 22: 
            case 24: {
                int n3 = ((VarInsnNode)abstractInsnNode).var;
                frame.push(frame.locals[n3]);
                frame.push(EmuObjects.TOP);
                return n2 + 1;
            }
            case 54: 
            case 56: 
            case 58: {
                frame.locals[((VarInsnNode)abstractInsnNode).var] = frame.pop();
                return n2 + 1;
            }
            case 55: 
            case 57: {
                int n4 = ((VarInsnNode)abstractInsnNode).var;
                frame.locals[n4] = frame.popWide();
                frame.locals[n4 + 1] = EmuObjects.TOP;
                return n2 + 1;
            }
            case 46: 
            case 47: 
            case 48: 
            case 49: 
            case 50: 
            case 51: 
            case 52: 
            case 53: {
                int n5 = frame.popInt();
                Object object = frame.popRef();
                Object object2 = Emulator.arrayLoad(object, n5);
                if (n != 47 && n != 49) {
                    frame.push(object2);
                    return n2 + 1;
                }
                frame.pushTyped(object2, Type.LONG_TYPE);
                return n2 + 1;
            }
            case 79: 
            case 81: 
            case 83: 
            case 84: 
            case 85: 
            case 86: {
                Object object = frame.pop();
                int n6 = frame.popInt();
                Object object3 = frame.popRef();
                Emulator.arrayStore(object3, n6, object);
                return n2 + 1;
            }
            case 80: 
            case 82: {
                Object object = frame.popWide();
                int n7 = frame.popInt();
                Object object4 = frame.popRef();
                Emulator.arrayStore(object4, n7, object);
                return n2 + 1;
            }
            case 87: {
                frame.pop();
                return n2 + 1;
            }
            case 88: {
                frame.pop();
                frame.pop();
                return n2 + 1;
            }
            case 89: {
                frame.push(frame.peek());
                return n2 + 1;
            }
            case 90: {
                Object object = frame.pop();
                Object object5 = frame.pop();
                frame.push(object);
                frame.push(object5);
                frame.push(object);
                return n2 + 1;
            }
            case 91: {
                Object object = frame.pop();
                Object object6 = frame.pop();
                Object object7 = frame.pop();
                frame.push(object);
                frame.push(object7);
                frame.push(object6);
                frame.push(object);
                return n2 + 1;
            }
            case 92: {
                Object object = frame.pop();
                Object object8 = frame.pop();
                frame.push(object8);
                frame.push(object);
                frame.push(object8);
                frame.push(object);
                return n2 + 1;
            }
            case 93: {
                Object object = frame.pop();
                Object object9 = frame.pop();
                Object object10 = frame.pop();
                frame.push(object9);
                frame.push(object);
                frame.push(object10);
                frame.push(object9);
                frame.push(object);
                return n2 + 1;
            }
            case 94: {
                Object object = frame.pop();
                Object object11 = frame.pop();
                Object object12 = frame.pop();
                Object object13 = frame.pop();
                frame.push(object11);
                frame.push(object);
                frame.push(object13);
                frame.push(object12);
                frame.push(object11);
                frame.push(object);
                return n2 + 1;
            }
            case 95: {
                Object object = frame.pop();
                Object object14 = frame.pop();
                frame.push(object);
                frame.push(object14);
                return n2 + 1;
            }
            case 96: 
            case 98: 
            case 100: 
            case 102: 
            case 104: 
            case 106: 
            case 108: 
            case 110: 
            case 112: 
            case 114: 
            case 120: 
            case 122: 
            case 124: 
            case 126: 
            case 128: 
            case 130: 
            case 149: 
            case 150: {
                Object object = frame.pop();
                Object object15 = frame.pop();
                if ((n == 108 || n == 112) && Integer.valueOf(0).equals(object)) {
                    throw Emulator.jdkThrow(new ArithmeticException("/ by zero"));
                }
                frame.push(Emulator.arith(n, object15, object));
                return n2 + 1;
            }
            case 97: 
            case 99: 
            case 101: 
            case 103: 
            case 105: 
            case 107: 
            case 109: 
            case 111: 
            case 113: 
            case 115: 
            case 127: 
            case 129: 
            case 131: {
                Object object = frame.popWide();
                Object object16 = frame.popWide();
                if ((n == 109 || n == 113) && Long.valueOf(0L).equals(object)) {
                    throw Emulator.jdkThrow(new ArithmeticException("/ by zero"));
                }
                frame.pushTyped(Emulator.arith(n, object16, object), Type.LONG_TYPE);
                return n2 + 1;
            }
            case 121: 
            case 123: 
            case 125: {
                Object object = frame.pop();
                Object object17 = frame.popWide();
                frame.pushTyped(Emulator.arith(n, object17, object), Type.LONG_TYPE);
                return n2 + 1;
            }
            case 148: 
            case 151: 
            case 152: {
                Object object = frame.popWide();
                Object object18 = frame.popWide();
                frame.push(Emulator.arith(n, object18, object));
                return n2 + 1;
            }
            case 116: 
            case 118: 
            case 134: 
            case 139: 
            case 145: 
            case 146: 
            case 147: {
                frame.push(Emulator.unary(n, frame.pop()));
                return n2 + 1;
            }
            case 117: 
            case 119: 
            case 138: 
            case 143: {
                frame.pushTyped(Emulator.unary(n, frame.popWide()), Type.LONG_TYPE);
                return n2 + 1;
            }
            case 133: 
            case 135: 
            case 140: 
            case 141: {
                frame.pushTyped(Emulator.unary(n, frame.pop()), Type.LONG_TYPE);
                return n2 + 1;
            }
            case 136: 
            case 137: 
            case 142: 
            case 144: {
                frame.push(Emulator.unary(n, frame.popWide()));
                return n2 + 1;
            }
            case 132: {
                IincInsnNode iincInsnNode = (IincInsnNode)abstractInsnNode;
                Object object = frame.locals[iincInsnNode.var];
                if (!(object instanceof Integer)) {
                    throw new EmulationException("iinc on non-int");
                }
                Integer n8 = (Integer)object;
                frame.locals[iincInsnNode.var] = n8 + iincInsnNode.incr;
                return n2 + 1;
            }
            case 153: 
            case 154: 
            case 155: 
            case 156: 
            case 157: 
            case 158: {
                Boolean bl = Folding.ifZero(n, frame.pop());
                if (bl == null) {
                    throw new EmulationException("bad branch operand");
                }
                if (bl.booleanValue()) {
                    int n9 = this.jump(methodData, ((JumpInsnNode)abstractInsnNode).label);
                    return n9;
                }
                int n10 = n2 + 1;
                return n10;
            }
            case 159: 
            case 160: 
            case 161: 
            case 162: 
            case 163: 
            case 164: {
                Object object = frame.pop();
                Object object19 = frame.pop();
                Boolean bl = Folding.ifCmp(n, object19, object);
                if (bl == null) {
                    throw new EmulationException("bad branch operands");
                }
                if (bl.booleanValue()) {
                    int n11 = this.jump(methodData, ((JumpInsnNode)abstractInsnNode).label);
                    return n11;
                }
                int n12 = n2 + 1;
                return n12;
            }
            case 165: 
            case 166: {
                boolean bl;
                Object object = frame.popRef();
                Object object20 = frame.popRef();
                boolean bl2 = Emulator.refEquals(object20, object);
                boolean bl3 = n == 165 ? bl2 : (bl = !bl2);
                if (bl) {
                    int n13 = this.jump(methodData, ((JumpInsnNode)abstractInsnNode).label);
                    return n13;
                }
                int n14 = n2 + 1;
                return n14;
            }
            case 198: 
            case 199: {
                boolean bl;
                Object object = frame.popRef();
                boolean bl4 = n == 198 ? object == null : (bl = object != null);
                if (bl) {
                    int n15 = this.jump(methodData, ((JumpInsnNode)abstractInsnNode).label);
                    return n15;
                }
                int n16 = n2 + 1;
                return n16;
            }
            case 167: {
                return this.jump(methodData, ((JumpInsnNode)abstractInsnNode).label);
            }
            case 168: 
            case 169: {
                throw new EmulationException("jsr/ret not supported");
            }
            case 170: {
                TableSwitchInsnNode tableSwitchInsnNode = (TableSwitchInsnNode)abstractInsnNode;
                int n17 = frame.popInt();
                LabelNode labelNode = n17 >= tableSwitchInsnNode.min && n17 <= tableSwitchInsnNode.max ? tableSwitchInsnNode.labels.get(n17 - tableSwitchInsnNode.min) : tableSwitchInsnNode.dflt;
                return this.jump(methodData, labelNode);
            }
            case 171: {
                LookupSwitchInsnNode lookupSwitchInsnNode = (LookupSwitchInsnNode)abstractInsnNode;
                int n18 = frame.popInt();
                int n19 = lookupSwitchInsnNode.keys.indexOf(n18);
                if (n19 >= 0) {
                    LabelNode labelNode = lookupSwitchInsnNode.labels.get(n19);
                    return this.jump(methodData, labelNode);
                }
                LabelNode labelNode = lookupSwitchInsnNode.dflt;
                return this.jump(methodData, labelNode);
            }
            case 172: 
            case 174: 
            case 176: {
                this.returnValue = frame.pop();
                return -1;
            }
            case 173: 
            case 175: {
                this.returnValue = frame.popWide();
                return -1;
            }
            case 177: {
                this.returnValue = null;
                return -1;
            }
            case 178: 
            case 179: 
            case 180: 
            case 181: {
                this.fieldInsn(frame, (FieldInsnNode)abstractInsnNode, n);
                return n2 + 1;
            }
            case 182: 
            case 183: 
            case 184: 
            case 185: {
                this.invoke(frame, (MethodInsnNode)abstractInsnNode, n);
                return n2 + 1;
            }
            case 186: {
                this.invokeDynamic(frame, (InvokeDynamicInsnNode)abstractInsnNode);
                return n2 + 1;
            }
            case 187: {
                String string = ((TypeInsnNode)abstractInsnNode).desc;
                if (this.isJarClass(string)) {
                    this.ensureInit(string);
                }
                frame.push(new EmuObjects.Uninit(string));
                return n2 + 1;
            }
            case 188: {
                int n20 = frame.popInt();
                Emulator.checkArraySize(n20);
                Object[] objectArray = switch (((IntInsnNode)abstractInsnNode).operand) {
                    case 4 -> new boolean[n20];
                    case 5 -> (Object[])new char[n20];
                    case 6 -> (Object[])new float[n20];
                    case 7 -> (Object[])new double[n20];
                    case 8 -> (Object[])new byte[n20];
                    case 9 -> (Object[])new short[n20];
                    case 10 -> (Object[])new int[n20];
                    case 11 -> (Object[])new long[n20];
                    default -> throw new EmulationException("bad newarray type");
                };
                frame.push(objectArray);
                return n2 + 1;
            }
            case 189: {
                int n21 = frame.popInt();
                Emulator.checkArraySize(n21);
                frame.push(this.newReferenceArray(((TypeInsnNode)abstractInsnNode).desc, n21));
                return n2 + 1;
            }
            case 197: {
                MultiANewArrayInsnNode multiANewArrayInsnNode = (MultiANewArrayInsnNode)abstractInsnNode;
                int[] nArray = new int[multiANewArrayInsnNode.dims];
                int n22 = multiANewArrayInsnNode.dims - 1;
                while (true) {
                    if (n22 < 0) {
                        frame.push(this.multiArray(Type.getType(multiANewArrayInsnNode.desc), nArray, 0));
                        return n2 + 1;
                    }
                    nArray[n22] = frame.popInt();
                    Emulator.checkArraySize(nArray[n22]);
                    --n22;
                }
            }
            case 190: {
                Object object = frame.popRef();
                if (object == null) {
                    throw Emulator.jdkThrow(new NullPointerException());
                }
                if (!object.getClass().isArray()) {
                    throw new EmulationException("arraylength on non-array");
                }
                frame.push(Array.getLength(object));
                return n2 + 1;
            }
            case 191: {
                Object object = frame.popRef();
                if (object != null) {
                    throw new EmuThrow(object);
                }
                throw Emulator.jdkThrow(new NullPointerException());
            }
            case 192: {
                Object object = frame.peek();
                String string = ((TypeInsnNode)abstractInsnNode).desc;
                if (object == null) {
                    return n2 + 1;
                }
                if (this.isInstance(object, string)) {
                    return n2 + 1;
                }
                throw Emulator.jdkThrow(new ClassCastException(string));
            }
            case 193: {
                Object object = frame.popRef();
                frame.push(object != null && this.isInstance(object, ((TypeInsnNode)abstractInsnNode).desc) ? 1 : 0);
                return n2 + 1;
            }
            case 194: 
            case 195: {
                if (frame.popRef() != null) {
                    return n2 + 1;
                }
                throw Emulator.jdkThrow(new NullPointerException());
            }
        }
        throw new EmulationException("unsupported opcode " + n);
    }

    private static boolean refEquals(Object object, Object object2) {
        if (object == object2) {
            return true;
        }
        if (object instanceof EmuObjects.EmuClass || object instanceof EmuObjects.EmuMethodType) {
            return object.equals(object2);
        }
        return false;
    }

    private static Object arith(int n, Object object, Object object2) {
        Object object3 = Folding.binary(n, object, object2);
        if (object3 == null) {
            throw new EmulationException("bad arithmetic operands");
        }
        return object3;
    }

    private static Object unary(int n, Object object) {
        Object object2 = Folding.unary(n, object);
        if (object2 == null) {
            throw new EmulationException("bad conversion operand");
        }
        return object2;
    }

    private static void checkArraySize(int n) {
        if (n < 0) {
            throw Emulator.jdkThrow(new NegativeArraySizeException(String.valueOf(n)));
        }
        if (n > 0x1000000) {
            throw new EmulationException("array too large");
        }
    }

    private Object newReferenceArray(String string, int n) {
        if (string.equals("java/lang/String")) {
            return new String[n];
        }
        return new Object[n];
    }

    private Object multiArray(Type type, int[] nArray, int n) {
        Type type2 = Type.getType(type.getDescriptor().substring(1));
        int n2 = nArray[n];
        if (n == nArray.length - 1) {
            switch (type2.getSort()) {
                case 1: {
                    return new boolean[n2];
                }
                case 2: {
                    return new char[n2];
                }
                case 3: {
                    return new byte[n2];
                }
                case 4: {
                    return new short[n2];
                }
                case 5: {
                    return new int[n2];
                }
                case 7: {
                    return new long[n2];
                }
                case 6: {
                    return new float[n2];
                }
                case 8: {
                    return new double[n2];
                }
            }
            return this.newReferenceArray(type2.getSort() == 9 ? type2.getDescriptor() : type2.getInternalName(), n2);
        }
        Object[] objectArray = new Object[n2];
        for (int i = 0; i < n2; ++i) {
            objectArray[i] = this.multiArray(type2, nArray, n + 1);
        }
        return objectArray;
    }

    private static Object arrayLoad(Object object, int n) {
        if (object == null) {
            throw Emulator.jdkThrow(new NullPointerException());
        }
        try {
            if (object instanceof int[]) {
                int[] nArray = (int[])object;
                return nArray[n];
            }
            if (object instanceof byte[]) {
                byte[] byArray = (byte[])object;
                return (int)byArray[n];
            }
            if (object instanceof char[]) {
                char[] cArray = (char[])object;
                return (int)cArray[n];
            }
            if (object instanceof short[]) {
                short[] sArray = (short[])object;
                return (int)sArray[n];
            }
            if (object instanceof boolean[]) {
                boolean[] blArray = (boolean[])object;
                return blArray[n] ? 1 : 0;
            }
            if (object instanceof long[]) {
                long[] lArray = (long[])object;
                return lArray[n];
            }
            if (object instanceof float[]) {
                float[] fArray = (float[])object;
                return Float.valueOf(fArray[n]);
            }
            if (object instanceof double[]) {
                double[] dArray = (double[])object;
                return dArray[n];
            }
            if (object instanceof Object[]) {
                Object[] objectArray = (Object[])object;
                return objectArray[n];
            }
        }
        catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            throw Emulator.jdkThrow(arrayIndexOutOfBoundsException);
        }
        throw new EmulationException("array load on non-array");
    }

    private static void arrayStore(Object object, int n, Object object2) {
        block13: {
            if (object == null) {
                throw Emulator.jdkThrow(new NullPointerException());
            }
            try {
                if (object instanceof int[]) {
                    int[] nArray = (int[])object;
                    nArray[n] = (Integer)object2;
                    break block13;
                }
                if (object instanceof byte[]) {
                    byte[] byArray = (byte[])object;
                    byArray[n] = (byte)((Integer)object2).intValue();
                    break block13;
                }
                if (object instanceof char[]) {
                    char[] cArray = (char[])object;
                    cArray[n] = (char)((Integer)object2).intValue();
                    break block13;
                }
                if (object instanceof short[]) {
                    short[] sArray = (short[])object;
                    sArray[n] = (short)((Integer)object2).intValue();
                    break block13;
                }
                if (object instanceof boolean[]) {
                    boolean[] blArray = (boolean[])object;
                    blArray[n] = ((Integer)object2 & 1) != 0;
                    break block13;
                }
                if (object instanceof long[]) {
                    long[] lArray = (long[])object;
                    lArray[n] = (Long)object2;
                    break block13;
                }
                if (object instanceof float[]) {
                    float[] fArray = (float[])object;
                    fArray[n] = ((Float)object2).floatValue();
                    break block13;
                }
                if (object instanceof double[]) {
                    double[] dArray = (double[])object;
                    dArray[n] = (Double)object2;
                    break block13;
                }
                if (object instanceof Object[]) {
                    Object[] objectArray = (Object[])object;
                    objectArray[n] = object2;
                    break block13;
                }
                throw new EmulationException("array store on non-array");
            }
            catch (ArrayIndexOutOfBoundsException | ArrayStoreException runtimeException) {
                throw Emulator.jdkThrow(runtimeException);
            }
            catch (ClassCastException classCastException) {
                throw new EmulationException("array store type mismatch");
            }
        }
    }

    boolean isInstance(Object object, String string) {
        if (object == null) {
            return false;
        }
        if (string.equals("java/lang/Object")) {
            return true;
        }
        if (object instanceof EmuObjects.VObject) {
            EmuObjects.VObject vObject = (EmuObjects.VObject)object;
            if (vObject.type.equals(string)) {
                return true;
            }
            Boolean bl = this.hierarchy.isSubtypeOf(vObject.type, string);
            if (bl == null) {
                throw new EmulationException("unknown hierarchy for " + vObject.type);
            }
            return bl;
        }
        if (object instanceof EmuObjects.Token) {
            EmuObjects.Token token = (EmuObjects.Token)object;
            return token.isInstanceOf(string);
        }
        if (string.startsWith("[")) {
            if (!object.getClass().isArray()) {
                return false;
            }
            Type type = Type.getType(string);
            Class<?> clazz = object.getClass().getComponentType();
            if (clazz.isPrimitive() || type.getDimensions() == 1 && type.getElementType().getSort() != 10) {
                return Type.getType(object.getClass()).equals(type);
            }
            return true;
        }
        if (this.isJarClass(string)) {
            return false;
        }
        try {
            return JdkAllowlist.jdkClass(string).isInstance(object);
        }
        catch (ClassNotFoundException classNotFoundException) {
            throw new EmulationException("unknown type " + string);
        }
    }

    private void fieldInsn(Frame frame, FieldInsnNode fieldInsnNode, int n) {
        Type type = Type.getType(fieldInsnNode.desc);
        String string = fieldInsnNode.name + ":" + fieldInsnNode.desc;
        switch (n) {
            case 178: {
                String string2 = this.hierarchy.resolveFieldOwner(fieldInsnNode.owner, fieldInsnNode.name, fieldInsnNode.desc);
                if (string2 == null) {
                    string2 = fieldInsnNode.owner;
                }
                if (this.isJarClass(string2)) {
                    this.ensureInit(string2);
                    if (this.poisoned.contains(string2)) {
                        throw new EmulationException("static state of " + string2 + " unknown");
                    }
                    if (this.clinitDepth == 0 && !this.staticReadPolicy.allowed(string2, fieldInsnNode.name, fieldInsnNode.desc)) {
                        throw new EmulationException("depends on mutable static field " + string2 + "." + fieldInsnNode.name);
                    }
                    frame.pushTyped(this.staticsOf(string2).getOrDefault(string, Emulator.defaultValue(type)), type);
                    break;
                }
                frame.pushTyped(JdkAllowlist.getStaticField(fieldInsnNode.owner, fieldInsnNode.name, fieldInsnNode.desc), type);
                break;
            }
            case 179: {
                Object object = type.getSize() == 2 ? frame.popWide() : frame.pop();
                String string3 = this.hierarchy.resolveFieldOwner(fieldInsnNode.owner, fieldInsnNode.name, fieldInsnNode.desc);
                if (string3 == null) {
                    string3 = fieldInsnNode.owner;
                }
                if (!this.isJarClass(string3)) {
                    throw new EmulationException("write to JDK static field");
                }
                this.ensureInit(string3);
                this.staticsOf(string3).put(string, object);
                break;
            }
            case 180: {
                Object object = frame.popRef();
                if (object == null) {
                    throw Emulator.jdkThrow(new NullPointerException());
                }
                if (!(object instanceof EmuObjects.VObject)) {
                    throw new EmulationException("field read on non-emulated object");
                }
                EmuObjects.VObject vObject = (EmuObjects.VObject)object;
                frame.pushTyped(vObject.fields.getOrDefault(string, Emulator.defaultValue(type)), type);
                break;
            }
            default: {
                Object object = type.getSize() == 2 ? frame.popWide() : frame.pop();
                Object object2 = frame.popRef();
                if (object2 == null) {
                    throw Emulator.jdkThrow(new NullPointerException());
                }
                if (!(object2 instanceof EmuObjects.VObject)) {
                    throw new EmulationException("field write on non-emulated object");
                }
                EmuObjects.VObject vObject = (EmuObjects.VObject)object2;
                vObject.fields.put(string, object);
            }
        }
    }

    private void invoke(Frame frame, MethodInsnNode methodInsnNode, int n) {
        Object object;
        Type[] typeArray = Type.getArgumentTypes(methodInsnNode.desc);
        Object[] objectArray = new Object[typeArray.length];
        for (int i = typeArray.length - 1; i >= 0; --i) {
            objectArray[i] = typeArray[i].getSize() == 2 ? frame.popWide() : frame.pop();
        }
        Object object2 = n == 184 ? null : frame.popRef();
        Type type = Type.getReturnType(methodInsnNode.desc);
        if (n == 183 && methodInsnNode.name.equals("<init>")) {
            this.construct(frame, methodInsnNode, object2, objectArray);
            return;
        }
        if (n == 184) {
            object = this.invokeStaticInsn(methodInsnNode, objectArray);
        } else {
            if (object2 == null) {
                throw Emulator.jdkThrow(new NullPointerException());
            }
            object = this.invokeInstance(methodInsnNode, n, object2, objectArray);
        }
        if (type.getSort() != 0) {
            frame.pushTyped(object, type);
        }
    }

    private Object invokeStaticInsn(MethodInsnNode methodInsnNode, Object[] objectArray) {
        if (this.isJarClass(methodInsnNode.owner)) {
            Resolved resolved = this.resolveMethod(methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc, true);
            if (resolved == null) {
                throw new EmulationException("unresolved " + methodInsnNode.owner + "." + methodInsnNode.name + methodInsnNode.desc);
            }
            this.ensureInit(resolved.owner.name);
            return this.execute(resolved.owner, resolved.method, objectArray);
        }
        if (SymbolicApi.handlesStatic(methodInsnNode.owner)) {
            return SymbolicApi.invokeStatic(this, methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc, objectArray);
        }
        try {
            return JdkAllowlist.fromReflective(JdkAllowlist.invoke(methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc, null, objectArray, true), Type.getReturnType(methodInsnNode.desc));
        }
        catch (JdkAllowlist.TargetException targetException) {
            throw Emulator.jdkThrow(targetException.target);
        }
    }

    private Object invokeInstance(MethodInsnNode methodInsnNode, int n, Object object, Object[] objectArray) {
        if (methodInsnNode.name.equals("getClass") && methodInsnNode.desc.equals("()Ljava/lang/Class;")) {
            if (object instanceof EmuObjects.VObject) {
                EmuObjects.VObject vObject = (EmuObjects.VObject)object;
                return new EmuObjects.EmuClass(Type.getObjectType(vObject.type));
            }
            if (object instanceof EmuObjects.Token) {
                throw new EmulationException("getClass on symbolic value");
            }
            return new EmuObjects.EmuClass(Type.getType(object.getClass()));
        }
        if (object instanceof EmuObjects.VObject) {
            EmuObjects.VObject vObject = (EmuObjects.VObject)object;
            Resolved resolved = n == 183 ? this.resolveMethod(methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc, true) : this.resolveMethod(vObject.type, methodInsnNode.name, methodInsnNode.desc, true);
            Resolved resolved2 = resolved;
            if (resolved != null) {
                return this.execute(resolved.owner, resolved.method, Emulator.prepend(object, objectArray));
            }
            if (methodInsnNode.name.equals("equals") && methodInsnNode.desc.equals("(Ljava/lang/Object;)Z")) {
                return object == objectArray[0] ? 1 : 0;
            }
            throw new EmulationException("cannot dispatch " + methodInsnNode.name + methodInsnNode.desc + " on " + vObject.type);
        }
        if (object instanceof EmuObjects.Token) {
            EmuObjects.Token token = (EmuObjects.Token)object;
            return SymbolicApi.invokeOnToken(this, token, methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc, objectArray);
        }
        if (object.getClass().isArray() && methodInsnNode.name.equals("clone") && objectArray.length == 0) {
            return Emulator.cloneArray(object);
        }
        try {
            return JdkAllowlist.fromReflective(JdkAllowlist.invoke(methodInsnNode.owner, methodInsnNode.name, methodInsnNode.desc, object, objectArray, false), Type.getReturnType(methodInsnNode.desc));
        }
        catch (JdkAllowlist.TargetException targetException) {
            throw Emulator.jdkThrow(targetException.target);
        }
    }

    private static Object cloneArray(Object object) {
        if (object instanceof int[]) {
            int[] nArray = (int[])object;
            return nArray.clone();
        }
        if (object instanceof byte[]) {
            byte[] byArray = (byte[])object;
            return byArray.clone();
        }
        if (object instanceof char[]) {
            char[] cArray = (char[])object;
            return cArray.clone();
        }
        if (object instanceof short[]) {
            short[] sArray = (short[])object;
            return sArray.clone();
        }
        if (object instanceof boolean[]) {
            boolean[] blArray = (boolean[])object;
            return blArray.clone();
        }
        if (object instanceof long[]) {
            long[] lArray = (long[])object;
            return lArray.clone();
        }
        if (object instanceof float[]) {
            float[] fArray = (float[])object;
            return fArray.clone();
        }
        if (object instanceof double[]) {
            double[] dArray = (double[])object;
            return dArray.clone();
        }
        return ((Object[])object).clone();
    }

    private static Object[] prepend(Object object, Object[] objectArray) {
        Object[] objectArray2 = new Object[objectArray.length + 1];
        objectArray2[0] = object;
        System.arraycopy(objectArray, 0, objectArray2, 1, objectArray.length);
        return objectArray2;
    }

    private void construct(Frame frame, MethodInsnNode methodInsnNode, Object object, Object[] objectArray) {
        if (object instanceof EmuObjects.Uninit) {
            EmuObjects.Uninit uninit = (EmuObjects.Uninit)object;
            if (this.isJarClass(uninit.type)) {
                EmuObjects.VObject vObject = new EmuObjects.VObject(uninit.type);
                frame.replace(uninit, vObject);
                this.runConstructor(methodInsnNode.owner, methodInsnNode.desc, vObject, objectArray);
            } else {
                Object object2 = SymbolicApi.handlesConstructor(uninit.type) ? SymbolicApi.construct(uninit.type, methodInsnNode.desc, objectArray) : this.newJdkObject(methodInsnNode, objectArray);
                frame.replace(uninit, object2);
            }
            return;
        }
        if (object instanceof EmuObjects.VObject) {
            EmuObjects.VObject vObject = (EmuObjects.VObject)object;
            if (this.isJarClass(methodInsnNode.owner)) {
                this.runConstructor(methodInsnNode.owner, methodInsnNode.desc, vObject, objectArray);
            } else if (!methodInsnNode.owner.equals("java/lang/Object")) {
                throw new EmulationException("jar class extends JDK class " + methodInsnNode.owner);
            }
            return;
        }
        throw new EmulationException("constructor call on unexpected receiver");
    }

    private Object newJdkObject(MethodInsnNode methodInsnNode, Object[] objectArray) {
        try {
            return JdkAllowlist.invoke(methodInsnNode.owner, "<init>", methodInsnNode.desc, null, objectArray, true);
        }
        catch (JdkAllowlist.TargetException targetException) {
            throw Emulator.jdkThrow(targetException.target);
        }
    }

    private void runConstructor(String string, String string2, EmuObjects.VObject vObject, Object[] objectArray) {
        ClassNode classNode = this.node(string);
        MethodNode methodNode = classNode == null ? null : Emulator.findDeclared(classNode, "<init>", string2);
        MethodNode methodNode2 = methodNode;
        if (methodNode == null) {
            throw new EmulationException("constructor not found " + string + string2);
        }
        this.execute(classNode, methodNode, Emulator.prepend(vObject, objectArray));
    }

    private void invokeDynamic(Frame frame, InvokeDynamicInsnNode invokeDynamicInsnNode) {
        Type[] typeArray = Type.getArgumentTypes(invokeDynamicInsnNode.desc);
        Object[] objectArray = new Object[typeArray.length];
        for (int i = typeArray.length - 1; i >= 0; --i) {
            objectArray[i] = typeArray[i].getSize() == 2 ? frame.popWide() : frame.pop();
        }
        Handle handle = invokeDynamicInsnNode.bsm;
        if (!handle.getOwner().equals("java/lang/invoke/StringConcatFactory")) {
            throw new EmulationException("invokedynamic inside emulation: " + handle.getOwner() + "." + handle.getName());
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (handle.getName().equals("makeConcatWithConstants")) {
            String string = (String)invokeDynamicInsnNode.bsmArgs[0];
            int n = 0;
            int n2 = 1;
            for (int i = 0; i < string.length(); ++i) {
                char c = string.charAt(i);
                if (c == '\u0001') {
                    stringBuilder.append(Emulator.stringify(objectArray[n], typeArray[n]));
                    ++n;
                } else if (c == '\u0002') {
                    stringBuilder.append(invokeDynamicInsnNode.bsmArgs[n2++]);
                } else {
                    stringBuilder.append(c);
                }
                if (stringBuilder.length() <= 0x1000000) continue;
                throw new EmulationException("string too large");
            }
        } else if (handle.getName().equals("makeConcat")) {
            for (int i = 0; i < objectArray.length; ++i) {
                stringBuilder.append(Emulator.stringify(objectArray[i], typeArray[i]));
            }
        } else {
            throw new EmulationException("unknown concat bootstrap");
        }
        frame.push(stringBuilder.toString());
    }

    private static String stringify(Object object, Type type) {
        switch (type.getSort()) {
            case 1: {
                return (Integer)object != 0 ? "true" : "false";
            }
            case 2: {
                return String.valueOf((char)((Integer)object).intValue());
            }
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: {
                return String.valueOf(object);
            }
        }
        if (object == null) {
            return "null";
        }
        if (object instanceof CharSequence || object instanceof Number || object instanceof Character || object instanceof Boolean) {
            return object.toString();
        }
        throw new EmulationException("cannot convert value to string");
    }

    private static String describe(Object object) {
        if (object instanceof Throwable) {
            Throwable throwable = (Throwable)object;
            return throwable.getClass().getName() + (String)(throwable.getMessage() == null ? "" : ": " + throwable.getMessage());
        }
        return String.valueOf(object);
    }

    ClassHierarchy hierarchy() {
        return this.hierarchy;
    }

    public static interface StaticReadPolicy {
        public boolean allowed(String var1, String var2, String var3);
    }

    private record Resolved(ClassNode owner, MethodNode method) {
    }

    public static final class EmulationException
    extends RuntimeException {
        public EmulationException(String string) {
            super(string, null, false, false);
        }
    }

    static final class EmuThrow
    extends RuntimeException {
        final Object exception;

        EmuThrow(Object object) {
            super(null, null, false, false);
            this.exception = object;
        }
    }

    private static final class MethodData {
        AbstractInsnNode[] insns;
        Map<LabelNode, Integer> labels;
        int[][] handlers;
        String[] handlerTypes;

        private MethodData() {
        }
    }

    static final class Frame {
        final Object[] locals;
        final Object[] stack;
        int sp;

        Frame(int n, int n2) {
            this.locals = new Object[n];
            this.stack = new Object[n2 + 2];
        }

        void push(Object object) {
            if (this.sp >= this.stack.length) {
                throw new EmulationException("operand stack overflow");
            }
            this.stack[this.sp++] = object;
        }

        void pushTyped(Object object, Type type) {
            this.push(object);
            if (type.getSize() == 2) {
                this.push(EmuObjects.TOP);
            }
        }

        Object pop() {
            if (this.sp <= 0) {
                throw new EmulationException("operand stack underflow");
            }
            return this.stack[--this.sp];
        }

        Object popWide() {
            this.pop();
            return this.pop();
        }

        Object peek() {
            if (this.sp <= 0) {
                throw new EmulationException("operand stack underflow");
            }
            return this.stack[this.sp - 1];
        }

        int popInt() {
            Object object = this.pop();
            if (object instanceof Integer) {
                Integer n = (Integer)object;
                return n;
            }
            throw new EmulationException("expected int");
        }

        Object popRef() {
            Object object = this.pop();
            if (object == EmuObjects.TOP) {
                throw new EmulationException("expected reference");
            }
            return object;
        }

        void replace(Object object, Object object2) {
            int n;
            for (n = 0; n < this.sp; ++n) {
                if (this.stack[n] != object) continue;
                this.stack[n] = object2;
            }
            for (n = 0; n < this.locals.length; ++n) {
                if (this.locals[n] != object) continue;
                this.locals[n] = object2;
            }
        }
    }
}

