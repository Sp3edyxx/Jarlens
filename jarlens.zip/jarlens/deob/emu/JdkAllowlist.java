/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.emu;

import dev.jarlens.core.JdkClasses;
import dev.jarlens.deob.emu.EmuObjects;
import dev.jarlens.deob.emu.Emulator;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Executable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.charset.Charset;
import java.security.Key;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.objectweb.asm.Type;

final class JdkAllowlist {
    private static final ClassLoader PLATFORM = ClassLoader.getPlatformClassLoader();
    static final int MAX_LENGTH = 0x1000000;
    private static final Set<String> OPEN_OWNERS = Set.of("java/lang/String", "java/lang/StringBuilder", "java/lang/StringBuffer", "java/lang/AbstractStringBuilder", "java/lang/CharSequence", "java/lang/Character", "java/lang/Integer", "java/lang/Long", "java/lang/Short", "java/lang/Byte", "java/lang/Boolean", "java/lang/Float", "java/lang/Double", "java/lang/Number", "java/lang/Math", "java/lang/StrictMath", "java/lang/Comparable", "java/util/Arrays", "java/util/Objects", "java/util/HashMap", "java/util/LinkedHashMap", "java/util/TreeMap", "java/util/Map", "java/util/AbstractMap", "java/util/concurrent/ConcurrentHashMap", "java/util/ArrayList", "java/util/LinkedList", "java/util/List", "java/util/AbstractList", "java/util/Collection", "java/util/HashSet", "java/util/Set", "java/util/Base64", "java/util/Base64$Decoder", "java/util/Base64$Encoder", "java/nio/charset/Charset", "javax/crypto/Cipher", "javax/crypto/spec/SecretKeySpec", "javax/crypto/spec/IvParameterSpec", "javax/crypto/spec/DESKeySpec", "javax/crypto/spec/DESedeKeySpec", "javax/crypto/spec/PBEKeySpec", "javax/crypto/spec/PBEParameterSpec", "javax/crypto/SecretKeyFactory", "javax/crypto/SecretKey", "java/security/Key", "java/security/MessageDigest", "java/math/BigInteger");
    private static final Set<String> ALLOWED_MEMBERS = Set.of("java/lang/System.arraycopy", "java/lang/Object.<init>", "java/lang/Object.equals", "java/lang/Object.hashCode", "java/lang/Object.toString", "java/lang/Throwable.getMessage", "java/lang/Throwable.<init>", "java/lang/Exception.<init>", "java/lang/RuntimeException.<init>", "java/lang/Error.<init>", "java/lang/IllegalArgumentException.<init>", "java/lang/IllegalStateException.<init>", "java/lang/NullPointerException.<init>", "java/lang/ArithmeticException.<init>", "java/lang/UnsupportedOperationException.<init>", "java/lang/ArrayIndexOutOfBoundsException.<init>", "java/lang/IndexOutOfBoundsException.<init>", "java/lang/ClassCastException.<init>");
    private static final Set<String> DENIED = Set.of("getInteger", "getLong", "getBoolean", "wait", "notify", "notifyAll", "getClass", "availableCharsets", "defaultCharset", "parallelSort", "parallelPrefix", "parallelSetAll", "setAll", "forEach", "computeIfAbsent", "computeIfPresent", "compute", "merge", "replaceAll", "removeIf", "stream", "parallelStream", "spliterator", "chars", "codePoints", "lines", "describeConstable", "resolveConstantDesc", "transform", "probablePrime", "nextProbablePrime");
    private static final Set<String> SAFE_VALUE_CLASSES = Set.of("java.lang.String", "java.lang.StringBuilder", "java.lang.StringBuffer", "java.lang.Integer", "java.lang.Long", "java.lang.Short", "java.lang.Byte", "java.lang.Character", "java.lang.Boolean", "java.lang.Float", "java.lang.Double", "java.util.HashMap", "java.util.LinkedHashMap", "java.util.TreeMap", "java.util.concurrent.ConcurrentHashMap", "java.util.ArrayList", "java.util.LinkedList", "java.util.HashSet", "java.util.Base64$Decoder", "java.util.Base64$Encoder", "javax.crypto.Cipher", "javax.crypto.spec.SecretKeySpec", "javax.crypto.spec.IvParameterSpec", "javax.crypto.spec.DESKeySpec", "javax.crypto.spec.DESedeKeySpec", "javax.crypto.spec.PBEKeySpec", "javax.crypto.spec.PBEParameterSpec", "javax.crypto.SecretKeyFactory", "java.math.BigInteger");
    private static final Set<String> SAFE_STATIC_FIELDS = Set.of("java/nio/charset/StandardCharsets", "java/lang/Integer", "java/lang/Long", "java/lang/Short", "java/lang/Byte", "java/lang/Character", "java/lang/Float", "java/lang/Double", "java/lang/Boolean", "java/math/BigInteger", "java/util/Locale");
    private static final Map<String, Optional<Executable>> CACHE = new ConcurrentHashMap<String, Optional<Executable>>();

    private JdkAllowlist() {
    }

    static boolean isAllowed(String string, String string2) {
        if (DENIED.contains(string2)) {
            return false;
        }
        if (string.startsWith("[")) {
            return string2.equals("clone");
        }
        return OPEN_OWNERS.contains(string) || ALLOWED_MEMBERS.contains(string + "." + string2);
    }

    static boolean isAllowedStaticField(String string) {
        return SAFE_STATIC_FIELDS.contains(string);
    }

    static boolean isSafeValue(Object object, int n) {
        if (object == null) {
            return true;
        }
        if (object instanceof EmuObjects.Token || object == EmuObjects.TOP) {
            return false;
        }
        Class<?> clazz = object.getClass();
        if (clazz.isArray()) {
            if (clazz.getComponentType().isPrimitive()) {
                return true;
            }
            Object[] objectArray = (Object[])object;
            if (n > 3 || objectArray.length > 100000) {
                return false;
            }
            for (Object object2 : objectArray) {
                if (JdkAllowlist.isSafeValue(object2, n + 1)) continue;
                return false;
            }
            return true;
        }
        if (object instanceof Throwable || object instanceof Charset || object instanceof MessageDigest || object instanceof Key || object instanceof Locale) {
            return true;
        }
        return SAFE_VALUE_CLASSES.contains(clazz.getName());
    }

    static Class<?> jdkClass(String string) throws ClassNotFoundException {
        if (!JdkClasses.isPlatformName(string)) {
            throw new ClassNotFoundException(string + " is not a JDK class");
        }
        return Class.forName(string.replace('/', '.'), false, PLATFORM);
    }

    static Class<?> classForType(Type type) throws ClassNotFoundException {
        switch (type.getSort()) {
            case 1: {
                return Boolean.TYPE;
            }
            case 2: {
                return Character.TYPE;
            }
            case 3: {
                return Byte.TYPE;
            }
            case 4: {
                return Short.TYPE;
            }
            case 5: {
                return Integer.TYPE;
            }
            case 7: {
                return Long.TYPE;
            }
            case 6: {
                return Float.TYPE;
            }
            case 8: {
                return Double.TYPE;
            }
            case 0: {
                return Void.TYPE;
            }
            case 9: {
                Class<?> clazz = JdkAllowlist.classForType(type.getElementType());
                for (int i = 0; i < type.getDimensions(); ++i) {
                    clazz = Array.newInstance(clazz, 0).getClass();
                }
                return clazz;
            }
        }
        return JdkAllowlist.jdkClass(type.getInternalName());
    }

    private static Executable lookup(String string, String string2, String string3) {
        return CACHE.computeIfAbsent(string + "." + string2 + string3, string4 -> {
            try {
                Class<?> clazz = JdkAllowlist.jdkClass(string);
                if (!Modifier.isPublic(clazz.getModifiers())) {
                    return Optional.empty();
                }
                Type[] typeArray = Type.getArgumentTypes(string3);
                Class[] classArray = new Class[typeArray.length];
                for (int i = 0; i < typeArray.length; ++i) {
                    classArray[i] = JdkAllowlist.classForType(typeArray[i]);
                }
                if (string2.equals("<init>")) {
                    Constructor<?> constructor = clazz.getConstructor(classArray);
                    return Optional.of(constructor);
                }
                Method method = clazz.getMethod(string2, classArray);
                if (!method.getReturnType().equals(JdkAllowlist.classForType(Type.getReturnType(string3)))) {
                    return Optional.empty();
                }
                return Optional.of(method);
            }
            catch (LinkageError | ReflectiveOperationException | RuntimeException throwable) {
                return Optional.empty();
            }
        }).orElse(null);
    }

    static Object invoke(String string, String string2, String string3, Object object, Object[] objectArray, boolean bl) throws TargetException {
        Object object2;
        Object object3;
        if (!JdkAllowlist.isAllowed(string, string2)) {
            throw new Emulator.EmulationException("JDK call not allowed: " + string + "." + string2 + string3);
        }
        if (object != null && !JdkAllowlist.isSafeValue(object, 0)) {
            throw new Emulator.EmulationException("unsafe receiver for " + string + "." + string2);
        }
        if (string.equals("java/lang/Object") && object != null && object.getClass().isArray() && !string2.equals("equals")) {
            throw new Emulator.EmulationException("identity-dependent call on array");
        }
        Type[] typeArray = Type.getArgumentTypes(string3);
        Object[] objectArray2 = new Object[objectArray.length];
        for (int i = 0; i < objectArray.length; ++i) {
            if (!JdkAllowlist.isSafeValue(objectArray[i], 0)) {
                throw new Emulator.EmulationException("unsafe argument for " + string + "." + string2);
            }
            objectArray2[i] = JdkAllowlist.toReflective(objectArray[i], typeArray[i]);
            if (typeArray[i].getSort() != 5 || !((object3 = objectArray2[i]) instanceof Integer) || (Integer)(object2 = (Integer)object3) <= 0x1000000 || !string2.equals("<init>") && !string2.startsWith("copyOf") && !string2.equals("repeat") && !string2.equals("ensureCapacity") && !string2.equals("setLength") && !string2.equals("fill")) continue;
            throw new Emulator.EmulationException("allocation too large");
        }
        Executable executable = JdkAllowlist.lookup(string, string2, string3);
        if (executable == null) {
            throw new Emulator.EmulationException("no such JDK member " + string + "." + string2 + string3);
        }
        try {
            if (executable instanceof Constructor) {
                object3 = (Constructor)executable;
                object2 = ((Constructor)object3).newInstance(objectArray2);
            } else {
                object3 = (Method)executable;
                if (Modifier.isStatic(((Method)object3).getModifiers()) != bl) {
                    throw new Emulator.EmulationException("static mismatch for " + string + "." + string2);
                }
                object2 = ((Method)object3).invoke(object, objectArray2);
            }
            JdkAllowlist.checkSize(object2);
            if (object != null) {
                JdkAllowlist.checkSize(object);
            }
            return object2;
        }
        catch (InvocationTargetException invocationTargetException) {
            object3 = invocationTargetException.getCause();
            if (object3 instanceof OutOfMemoryError || object3 instanceof StackOverflowError) {
                throw new Emulator.EmulationException("resource exhaustion in " + string + "." + string2);
            }
            throw new TargetException((Throwable)object3);
        }
        catch (IllegalAccessException | IllegalArgumentException | InstantiationException exception) {
            throw new Emulator.EmulationException("cannot call " + string + "." + string2 + ": " + String.valueOf(exception));
        }
    }

    static Object getStaticField(String string, String string2, String string3) {
        if (!JdkAllowlist.isAllowedStaticField(string)) {
            throw new Emulator.EmulationException("JDK field not allowed: " + string + "." + string2);
        }
        try {
            Field field = JdkAllowlist.jdkClass(string).getField(string2);
            if (!Modifier.isStatic(field.getModifiers()) || !Modifier.isFinal(field.getModifiers())) {
                throw new Emulator.EmulationException("JDK field not constant: " + string + "." + string2);
            }
            Object object = field.get(null);
            if (object instanceof Class) {
                Class clazz = (Class)object;
                return new EmuObjects.EmuClass(Type.getType(clazz));
            }
            return JdkAllowlist.fromReflective(object, Type.getType(string3));
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new Emulator.EmulationException("cannot read " + string + "." + string2);
        }
    }

    private static void checkSize(Object object) {
        CharSequence charSequence;
        if (object instanceof CharSequence && (charSequence = (CharSequence)object).length() > 0x1000000) {
            throw new Emulator.EmulationException("string too large");
        }
    }

    static Object toReflective(Object object, Type type) {
        switch (type.getSort()) {
            case 1: {
                return (Integer)object != 0;
            }
            case 2: {
                return Character.valueOf((char)((Integer)object).intValue());
            }
            case 3: {
                return (byte)((Integer)object).intValue();
            }
            case 4: {
                return (short)((Integer)object).intValue();
            }
        }
        return object;
    }

    static Object fromReflective(Object object, Type type) {
        switch (type.getSort()) {
            case 1: {
                return (Boolean)object != false ? 1 : 0;
            }
            case 2: {
                return (int)((Character)object).charValue();
            }
            case 3: {
                return (int)((Byte)object).byteValue();
            }
            case 4: {
                return (int)((Short)object).shortValue();
            }
        }
        return object;
    }

    static final class TargetException
    extends Exception {
        final Throwable target;

        TargetException(Throwable throwable) {
            super(null, null, false, false);
            this.target = throwable;
        }
    }
}

