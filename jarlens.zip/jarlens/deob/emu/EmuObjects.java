/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.emu;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import org.objectweb.asm.Type;

public final class EmuObjects {
    public static final Object TOP = new Object(){

        public String toString() {
            return "TOP";
        }
    };

    private EmuObjects() {
    }

    public static abstract class Token {
        abstract boolean isInstanceOf(String var1);
    }

    public static final class Uninit
    extends Token {
        final String type;

        Uninit(String string) {
            this.type = string;
        }

        @Override
        boolean isInstanceOf(String string) {
            return false;
        }

        public String toString() {
            return "uninit " + this.type;
        }
    }

    public static final class VObject
    extends Token {
        final String type;
        final Map<String, Object> fields = new HashMap<String, Object>();

        VObject(String string) {
            this.type = string;
        }

        @Override
        boolean isInstanceOf(String string) {
            return string.equals("java/lang/Object");
        }

        public String toString() {
            return "instance of " + this.type;
        }
    }

    public static final class EmuClass
    extends Token {
        final Type type;

        EmuClass(Type type) {
            this.type = type;
        }

        @Override
        boolean isInstanceOf(String string) {
            return string.equals("java/lang/Class") || string.equals("java/lang/Object") || string.equals("java/lang/reflect/Type");
        }

        String javaName() {
            if (this.type.getSort() == 9) {
                return this.type.getDescriptor().replace('/', '.');
            }
            return this.type.getClassName();
        }

        public boolean equals(Object object) {
            if (!(object instanceof EmuClass)) {
                return false;
            }
            EmuClass emuClass = (EmuClass)object;
            return emuClass.type.equals(this.type);
        }

        public int hashCode() {
            return this.type.hashCode();
        }

        public String toString() {
            return "class " + this.type.getClassName();
        }
    }

    public static final class EmuMethodType
    extends Token {
        final String desc;

        EmuMethodType(String string) {
            this.desc = string;
        }

        @Override
        boolean isInstanceOf(String string) {
            return string.equals("java/lang/invoke/MethodType") || string.equals("java/lang/Object");
        }

        public boolean equals(Object object) {
            if (!(object instanceof EmuMethodType)) {
                return false;
            }
            EmuMethodType emuMethodType = (EmuMethodType)object;
            return emuMethodType.desc.equals(this.desc);
        }

        public int hashCode() {
            return this.desc.hashCode();
        }

        public String toString() {
            return "methodtype " + this.desc;
        }
    }

    public static final class EmuMethodHandle
    extends Token {
        public final int kind;
        public final String owner;
        public final String name;
        public final String desc;
        public final boolean itf;

        EmuMethodHandle(int n, String string, String string2, String string3, boolean bl) {
            this.kind = n;
            this.owner = string;
            this.name = string2;
            this.desc = string3;
            this.itf = bl;
        }

        @Override
        boolean isInstanceOf(String string) {
            return string.equals("java/lang/invoke/MethodHandle") || string.equals("java/lang/Object");
        }

        public String invocationType() {
            Type type = Type.getObjectType(this.owner);
            switch (this.kind) {
                case 6: {
                    return this.desc;
                }
                case 5: 
                case 7: 
                case 9: {
                    Type[] typeArray = Type.getArgumentTypes(this.desc);
                    Type[] typeArray2 = new Type[typeArray.length + 1];
                    typeArray2[0] = type;
                    System.arraycopy(typeArray, 0, typeArray2, 1, typeArray.length);
                    return Type.getMethodDescriptor(Type.getReturnType(this.desc), typeArray2);
                }
                case 8: {
                    return Type.getMethodDescriptor(type, Type.getArgumentTypes(this.desc));
                }
                case 1: {
                    return "(" + type.getDescriptor() + ")" + this.desc;
                }
                case 2: {
                    return "()" + this.desc;
                }
                case 3: {
                    return "(" + type.getDescriptor() + this.desc + ")V";
                }
                case 4: {
                    return "(" + this.desc + ")V";
                }
            }
            return this.desc;
        }

        public boolean equals(Object object) {
            if (!(object instanceof EmuMethodHandle)) {
                return false;
            }
            EmuMethodHandle emuMethodHandle = (EmuMethodHandle)object;
            if (emuMethodHandle.kind != this.kind) {
                return false;
            }
            if (!emuMethodHandle.owner.equals(this.owner)) {
                return false;
            }
            if (!emuMethodHandle.name.equals(this.name)) {
                return false;
            }
            return emuMethodHandle.desc.equals(this.desc);
        }

        public int hashCode() {
            return Objects.hash(this.kind, this.owner, this.name, this.desc);
        }

        public String toString() {
            return "handle " + this.owner + "." + this.name + this.desc;
        }
    }

    public static final class EmuLookup
    extends Token {
        final String lookupClass;

        EmuLookup(String string) {
            this.lookupClass = string;
        }

        @Override
        boolean isInstanceOf(String string) {
            return string.equals("java/lang/invoke/MethodHandles$Lookup") || string.equals("java/lang/Object");
        }
    }

    public static final class EmuCallSite
    extends Token {
        EmuMethodHandle target;
        final String kindName;

        EmuCallSite(EmuMethodHandle emuMethodHandle, String string) {
            this.target = emuMethodHandle;
            this.kindName = string;
        }

        public EmuMethodHandle target() {
            return this.target;
        }

        @Override
        boolean isInstanceOf(String string) {
            return string.equals("java/lang/invoke/CallSite") || string.equals(this.kindName) || string.equals("java/lang/Object");
        }
    }

    public static final class Opaque
    extends Token {
        final String type;

        Opaque(String string) {
            this.type = string;
        }

        @Override
        boolean isInstanceOf(String string) {
            return string.equals(this.type) || string.equals("java/lang/Object");
        }
    }
}

