/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

public enum Stat {
    JUNK_INSNS("Junk instructions removed"),
    DEAD_CODE("Unreachable instructions removed"),
    FAKE_HANDLERS("Fake exception handlers removed"),
    BOGUS_DEBUG("Bogus debug info entries removed"),
    HIDDEN_FLAGS("Synthetic/bridge flags cleared (hidden members)"),
    OPAQUE_BRANCHES("Opaque predicates / constant branches simplified"),
    FOLDED("Constant expressions folded"),
    CONST_FIELDS("Constant static field reads inlined"),
    STRINGS_DECRYPTED("Strings decrypted"),
    STRINGS_FAILED("Strings left encrypted (could not emulate)"),
    INDY_RESOLVED("invokedynamic calls resolved"),
    INDY_FAILED("invokedynamic calls left unresolved"),
    RENAMED_PACKAGES("Packages renamed"),
    RENAMED_CLASSES("Classes renamed"),
    RENAMED_METHODS("Methods renamed"),
    RENAMED_FIELDS("Fields renamed"),
    MAPPED_NAMES("Names applied from mapping file"),
    REVERTED("Class changes reverted (failed verification)");

    public final String label;

    private Stat(String string2) {
        this.label = string2;
    }
}

