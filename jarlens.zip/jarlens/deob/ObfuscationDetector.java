/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.core.JarModel;
import dev.jarlens.deob.DeobReport;
import dev.jarlens.deob.Stat;
import dev.jarlens.deob.transform.Names;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.jar.Attributes;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Handle;
import org.objectweb.asm.MethodVisitor;

final class ObfuscationDetector {
    private static final List<String> KNOWN = List.of("Allatori", "ZKM", "Zelix", "KlassMaster", "Stringer", "DashO", "yGuard", "ProGuard", "Skidfuscator", "Paramorphism", "Bozar", "Radon", "Caesium", "Branchlock", "Superblaubeere", "Binscure", "Scuti", "Obzcure", "JNIC", "Qprotect", "Sandmark", "Javaguard");

    private ObfuscationDetector() {
    }

    static void scan(JarModel jarModel, final Map<String, byte[]> map, DeobReport deobReport) {
        long l;
        AtomicInteger atomicInteger = new AtomicInteger();
        AtomicInteger atomicInteger2 = new AtomicInteger();
        AtomicInteger atomicInteger3 = new AtomicInteger();
        AtomicInteger atomicInteger4 = new AtomicInteger();
        ConcurrentSkipListSet<String> concurrentSkipListSet = new ConcurrentSkipListSet<String>();
        map.values().parallelStream().forEach(byArray -> {
            try {
                ClassReader classReader = new ClassReader((byte[])byArray);
                String string = classReader.getClassName();
                String string2 = string.substring(string.lastIndexOf(47) + 1);
                if (Names.classSegmentNeedsRename(string2.split("\\$")[0], true, false)) {
                    atomicInteger.incrementAndGet();
                }
                if (string2.length() <= 2) {
                    atomicInteger2.incrementAndGet();
                }
                classReader.accept(new ClassVisitor(589824){

                    @Override
                    public void visitSource(String string, String string2) {
                        if (string != null) {
                            ObfuscationDetector.checkHint(string, concurrentSkipListSet);
                        }
                    }

                    @Override
                    public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
                        if (Names.memberNeedsRename(string, false)) {
                            atomicInteger.incrementAndGet();
                        }
                        return null;
                    }

                    @Override
                    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
                        if (Names.memberNeedsRename(string, false)) {
                            atomicInteger.incrementAndGet();
                        }
                        return new MethodVisitor(this, 589824){
                            {
                                Objects.requireNonNull(var1_1);
                                super(n);
                            }

                            @Override
                            public void visitLdcInsn(Object object) {
                                String string;
                                if (object instanceof String && (string = (String)object).length() < 200) {
                                    ObfuscationDetector.checkHint(string, concurrentSkipListSet);
                                }
                            }

                            @Override
                            public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
                                if (map.containsKey(handle.getOwner())) {
                                    atomicInteger3.incrementAndGet();
                                }
                            }

                            @Override
                            public void visitMethodInsn(int n, String string, String string2, String string3, boolean bl) {
                                if (string2.equals("getStackTrace") && (string.equals("java/lang/Thread") || string.equals("java/lang/Throwable"))) {
                                    atomicInteger4.incrementAndGet();
                                }
                            }
                        };
                    }
                }, 4);
            }
            catch (Exception | StackOverflowError throwable) {
                // empty catch block
            }
        });
        if (jarModel.manifest() != null) {
            for (Map.Entry<Object, Object> object : jarModel.manifest().getMainAttributes().entrySet()) {
                String string2 = ((Attributes.Name)object.getKey()).toString();
                String string3 = String.valueOf(object.getValue());
                if (string2.toLowerCase(Locale.ROOT).contains("obfusc") || string2.toLowerCase(Locale.ROOT).contains("protect")) {
                    concurrentSkipListSet.add("manifest attribute " + string2 + ": " + string3);
                }
                ObfuscationDetector.checkHint(string3, concurrentSkipListSet);
            }
        }
        if (atomicInteger.get() > 0) {
            deobReport.technique("Name obfuscation: " + atomicInteger.get() + " illegal, invisible, Unicode or confusable identifiers");
        }
        if (!map.isEmpty() && atomicInteger2.get() * 2 > map.size() && map.size() > 4) {
            deobReport.technique("Short meaningless names (ProGuard style) on " + atomicInteger2.get() + " classes");
        }
        if (atomicInteger3.get() > 0) {
            deobReport.technique("invokedynamic with custom bootstrap methods: " + atomicInteger3.get() + " call sites");
        }
        if (atomicInteger4.get() > 0) {
            deobReport.technique("Stack-trace based (context-dependent) code: " + atomicInteger4.get() + " uses \u2014 strings depending on it cannot be decrypted statically");
        }
        if ((l = jarModel.warnings().stream().filter(string -> string.contains("hidden behind") || string.contains("Duplicate") || string.contains("decoy") || string.contains("different path") || string.contains("malformed") || string.contains("Central directory")).count()) > 0L) {
            deobReport.technique("Archive / class file tricks: " + l + " (see warnings)");
        }
        if (!jarModel.brokenClasses().isEmpty()) {
            deobReport.technique("Deliberately broken class files: " + jarModel.brokenClasses().size());
        }
        for (String string4 : new TreeSet(concurrentSkipListSet)) {
            deobReport.technique("Possible obfuscator: " + string4);
        }
    }

    private static void checkHint(String string, Set<String> set) {
        if (string.contains("ALLATORIxDEMO")) {
            set.add("Allatori (demo watermark found)");
            return;
        }
        String string2 = string.toLowerCase(Locale.ROOT);
        for (String string3 : KNOWN) {
            String string4 = string3.toLowerCase(Locale.ROOT);
            int n = string2.indexOf(string4);
            if (n < 0) continue;
            boolean bl = n == 0 || !Character.isLetter(string2.charAt(n - 1));
            int n2 = n + string4.length();
            boolean bl2 = n2 >= string2.length() || !Character.isLetter(string2.charAt(n2));
            boolean bl3 = bl2;
            if (!bl || !bl2 || !string2.contains("obfusc") && !string2.contains("protect") && string.length() >= 40) continue;
            set.add(string3 + " (mentioned in \"" + ObfuscationDetector.abbreviate(string) + "\")");
        }
    }

    private static String abbreviate(String string) {
        String string2 = string.replaceAll("\\p{Cntrl}", " ").trim();
        return string2.length() > 60 ? string2.substring(0, 57) + "\u2026" : string2;
    }

    static void summarize(DeobReport deobReport, int n) {
        long l = deobReport.get(Stat.JUNK_INSNS) + deobReport.get(Stat.DEAD_CODE);
        if (l > (long)Math.max(20, n / 4)) {
            deobReport.technique("Junk / dead code: " + l + " instructions removed");
        }
        if (deobReport.get(Stat.FAKE_HANDLERS) > 0L) {
            deobReport.technique("Fake exception handlers: " + deobReport.get(Stat.FAKE_HANDLERS) + " removed");
        }
        if (deobReport.get(Stat.OPAQUE_BRANCHES) > 0L) {
            deobReport.technique("Opaque predicates / constant conditions: " + deobReport.get(Stat.OPAQUE_BRANCHES) + " branches simplified");
        }
        if (deobReport.get(Stat.CONST_FIELDS) > 0L) {
            deobReport.technique("Constant static fields inlined: " + deobReport.get(Stat.CONST_FIELDS) + " reads");
        }
        if (deobReport.get(Stat.FOLDED) > 0L) {
            deobReport.technique("Constant arithmetic: " + deobReport.get(Stat.FOLDED) + " expressions folded");
        }
        if (deobReport.get(Stat.STRINGS_DECRYPTED) + deobReport.get(Stat.STRINGS_FAILED) > 0L) {
            deobReport.technique("String encryption: " + deobReport.get(Stat.STRINGS_DECRYPTED) + " strings decrypted, " + deobReport.get(Stat.STRINGS_FAILED) + " left as is");
        }
        if (deobReport.get(Stat.INDY_RESOLVED) + deobReport.get(Stat.INDY_FAILED) > 0L) {
            deobReport.technique("invokedynamic obfuscation: " + deobReport.get(Stat.INDY_RESOLVED) + " resolved, " + deobReport.get(Stat.INDY_FAILED) + " left as is");
        }
        if (deobReport.get(Stat.BOGUS_DEBUG) > 0L) {
            deobReport.technique("Bogus debug info / metadata: " + deobReport.get(Stat.BOGUS_DEBUG) + " entries removed");
        }
        if (deobReport.get(Stat.HIDDEN_FLAGS) > 0L) {
            deobReport.technique("Synthetic/bridge flags removed from " + deobReport.get(Stat.HIDDEN_FLAGS) + " hidden or renamed members");
        }
    }
}

