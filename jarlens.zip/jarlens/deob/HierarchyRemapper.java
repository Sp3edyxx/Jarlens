/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.core.ClassHierarchy;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.commons.ClassRemapper;
import org.objectweb.asm.commons.Remapper;

public final class HierarchyRemapper
extends Remapper {
    private final ClassHierarchy hierarchy;
    final Map<String, String> classes = new HashMap<String, String>();
    final Map<String, String> methods = new HashMap<String, String>();
    final Map<String, String> fields = new HashMap<String, String>();
    public int renamedClassCount;
    public int renamedPackageCount;
    private final ConcurrentHashMap<String, Optional<String>> methodCache = new ConcurrentHashMap();
    private final ConcurrentHashMap<String, Optional<String>> fieldCache = new ConcurrentHashMap();
    private volatile Map<String, String> annotationAttrs;

    public HierarchyRemapper(ClassHierarchy classHierarchy) {
        super(589824);
        this.hierarchy = classHierarchy;
    }

    public void mapClass(String string, String string2) {
        this.classes.put(string, string2);
    }

    public void mapMethod(String string, String string2, String string3, String string4) {
        this.methods.put(string + "." + string2 + string3, string4);
        this.annotationAttrs = null;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private Map<String, String> annotationAttrs() {
        Map<String, String> map = this.annotationAttrs;
        if (map == null) {
            HierarchyRemapper hierarchyRemapper = this;
            synchronized (hierarchyRemapper) {
                map = this.annotationAttrs;
                if (map == null) {
                    map = new HashMap<String, String>();
                    for (Map.Entry<String, String> entry : this.methods.entrySet()) {
                        String string = entry.getKey();
                        int n = string.indexOf(40);
                        if (n < 0 || !string.startsWith("()", n)) continue;
                        map.putIfAbsent(string.substring(0, n + 2), entry.getValue());
                    }
                    this.annotationAttrs = map;
                }
            }
        }
        return map;
    }

    public void mapField(String string, String string2, String string3, String string4) {
        this.fields.put(string + "." + string2 + ":" + string3, string4);
    }

    public boolean hasClassMapping(String string) {
        return this.classes.containsKey(string);
    }

    public boolean hasMethodMapping(String string, String string2, String string3) {
        return this.methods.containsKey(string + "." + string2 + string3);
    }

    public boolean hasFieldMapping(String string, String string2, String string3) {
        return this.fields.containsKey(string + "." + string2 + ":" + string3);
    }

    public Map<String, String> classMappings() {
        return this.classes;
    }

    public boolean isEmpty() {
        return this.classes.isEmpty() && this.methods.isEmpty() && this.fields.isEmpty();
    }

    public int size() {
        return this.classes.size() + this.methods.size() + this.fields.size();
    }

    @Override
    public String map(String string) {
        return this.classes.get(string);
    }

    @Override
    public String mapMethodName(String string, String string2, String string3) {
        if (string2.startsWith("<") || string.startsWith("[")) {
            return string2;
        }
        if (this.methods.isEmpty()) {
            return string2;
        }
        String string5 = string + "." + string2 + string3;
        return this.methodCache.computeIfAbsent(string5, string4 -> {
            String string5 = this.methods.get(string4);
            if (string5 != null) {
                return Optional.of(string5);
            }
            for (String string6 : this.hierarchy.allSupertypes(string)) {
                String string7 = this.methods.get(string6 + "." + string2 + string3);
                if (string7 == null) continue;
                return Optional.of(string7);
            }
            return Optional.empty();
        }).orElse(string2);
    }

    @Override
    public String mapFieldName(String string, String string2, String string3) {
        if (this.fields.isEmpty()) {
            return string2;
        }
        String string5 = string + "." + string2 + ":" + string3;
        return this.fieldCache.computeIfAbsent(string5, string4 -> {
            String string5;
            String string6 = this.fields.get(string4);
            if (string6 != null) {
                return Optional.of(string6);
            }
            String string7 = this.hierarchy.resolveFieldOwner(string, string2, string3);
            if (string7 != null && (string5 = this.fields.get(string7 + "." + string2 + ":" + string3)) != null) {
                return Optional.of(string5);
            }
            return Optional.empty();
        }).orElse(string2);
    }

    @Override
    public String mapRecordComponentName(String string, String string2, String string3) {
        return this.mapFieldName(string, string2, string3);
    }

    @Override
    public String mapAnnotationAttributeName(String string, String string2) {
        if (this.methods.isEmpty() || string == null || !string.startsWith("L")) {
            return string2;
        }
        String string3 = string.substring(1, string.length() - 1);
        return this.annotationAttrs().getOrDefault(string3 + "." + string2 + "()", string2);
    }

    public Map<String, byte[]> apply(Map<String, byte[]> map) {
        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
        map.entrySet().parallelStream().forEach(entry -> {
            ClassWriter classWriter = new ClassWriter(0);
            new ClassReader((byte[])entry.getValue()).accept(new ClassRemapper(classWriter, this), 0);
            String string = this.classes.getOrDefault(entry.getKey(), (String)entry.getKey());
            concurrentHashMap.put(string, classWriter.toByteArray());
        });
        return new LinkedHashMap<String, byte[]>(new TreeMap(concurrentHashMap));
    }
}

