/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import java.util.prefs.Preferences;

public final class DeobSettings {
    public boolean enabled = true;
    public boolean junkCode = true;
    public boolean debugInfo = true;
    public boolean constantFolding = true;
    public boolean stringDecryption = true;
    public boolean indyResolution = true;
    public boolean renaming = true;
    public boolean renameShortNames = false;
    public boolean foldStaticConstantFields = true;
    public int maxPasses = 8;
    public int emulatorInstructionLimit = 400000;
    public int emulatorClinitLimit = 5000000;

    public DeobSettings copy() {
        DeobSettings deobSettings = new DeobSettings();
        deobSettings.enabled = this.enabled;
        deobSettings.junkCode = this.junkCode;
        deobSettings.debugInfo = this.debugInfo;
        deobSettings.constantFolding = this.constantFolding;
        deobSettings.stringDecryption = this.stringDecryption;
        deobSettings.indyResolution = this.indyResolution;
        deobSettings.renaming = this.renaming;
        deobSettings.renameShortNames = this.renameShortNames;
        deobSettings.foldStaticConstantFields = this.foldStaticConstantFields;
        deobSettings.maxPasses = this.maxPasses;
        deobSettings.emulatorInstructionLimit = this.emulatorInstructionLimit;
        deobSettings.emulatorClinitLimit = this.emulatorClinitLimit;
        return deobSettings;
    }

    public static DeobSettings load(Preferences preferences) {
        DeobSettings deobSettings = new DeobSettings();
        deobSettings.enabled = preferences.getBoolean("deob.enabled", deobSettings.enabled);
        deobSettings.junkCode = preferences.getBoolean("deob.junk", deobSettings.junkCode);
        deobSettings.debugInfo = preferences.getBoolean("deob.debug", deobSettings.debugInfo);
        deobSettings.constantFolding = preferences.getBoolean("deob.const", deobSettings.constantFolding);
        deobSettings.stringDecryption = preferences.getBoolean("deob.strings", deobSettings.stringDecryption);
        deobSettings.indyResolution = preferences.getBoolean("deob.indy", deobSettings.indyResolution);
        deobSettings.renaming = preferences.getBoolean("deob.rename", deobSettings.renaming);
        deobSettings.renameShortNames = preferences.getBoolean("deob.renameShort", deobSettings.renameShortNames);
        deobSettings.foldStaticConstantFields = preferences.getBoolean("deob.staticConst", deobSettings.foldStaticConstantFields);
        deobSettings.maxPasses = DeobSettings.clamp(preferences.getInt("deob.passes", deobSettings.maxPasses), 1, 50);
        deobSettings.emulatorInstructionLimit = DeobSettings.clamp(preferences.getInt("deob.emuLimit", deobSettings.emulatorInstructionLimit), 1000, 50000000);
        deobSettings.emulatorClinitLimit = DeobSettings.clamp(preferences.getInt("deob.emuClinitLimit", deobSettings.emulatorClinitLimit), 1000, 100000000);
        return deobSettings;
    }

    public void save(Preferences preferences) {
        preferences.putBoolean("deob.enabled", this.enabled);
        preferences.putBoolean("deob.junk", this.junkCode);
        preferences.putBoolean("deob.debug", this.debugInfo);
        preferences.putBoolean("deob.const", this.constantFolding);
        preferences.putBoolean("deob.strings", this.stringDecryption);
        preferences.putBoolean("deob.indy", this.indyResolution);
        preferences.putBoolean("deob.rename", this.renaming);
        preferences.putBoolean("deob.renameShort", this.renameShortNames);
        preferences.putBoolean("deob.staticConst", this.foldStaticConstantFields);
        preferences.putInt("deob.passes", this.maxPasses);
        preferences.putInt("deob.emuLimit", this.emulatorInstructionLimit);
        preferences.putInt("deob.emuClinitLimit", this.emulatorClinitLimit);
    }

    private static int clamp(int n, int n2, int n3) {
        return Math.max(n2, Math.min(n3, n));
    }
}

