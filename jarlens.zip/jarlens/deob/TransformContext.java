/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob;

import dev.jarlens.core.ClassHierarchy;
import dev.jarlens.deob.DeobReport;
import dev.jarlens.deob.DeobSettings;
import dev.jarlens.deob.JarIndex;
import java.util.Map;

public final class TransformContext {
    public final Map<String, byte[]> snapshot;
    public final ClassHierarchy hierarchy;
    public final DeobSettings settings;
    public final DeobReport report;
    private volatile JarIndex index;

    public TransformContext(Map<String, byte[]> map, ClassHierarchy classHierarchy, DeobSettings deobSettings, DeobReport deobReport) {
        this.snapshot = map;
        this.hierarchy = classHierarchy;
        this.settings = deobSettings;
        this.report = deobReport;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public JarIndex index() {
        JarIndex jarIndex = this.index;
        if (jarIndex == null) {
            TransformContext transformContext;
            TransformContext transformContext2 = transformContext = this;
            synchronized (transformContext2) {
                jarIndex = this.index;
                if (jarIndex == null) {
                    this.index = jarIndex = JarIndex.build(this.snapshot, this.hierarchy);
                }
            }
        }
        return jarIndex;
    }

    public boolean isJarClass(String string) {
        return this.snapshot.containsKey(string);
    }
}

