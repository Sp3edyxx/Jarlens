/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.analysis;

import dev.jarlens.deob.analysis.ConstValue;
import java.util.List;
import org.objectweb.asm.tree.MethodInsnNode;

final class PureCalls {
    private PureCalls() {
    }

    static Object fold(MethodInsnNode methodInsnNode, List<? extends ConstValue> list) {
        Object object = list.iterator();
        while (object.hasNext()) {
            Object object2 = object.next();
            if (((ConstValue)object2).isConstant()) continue;
            return null;
        }
        try {
            switch (object = methodInsnNode.owner + "." + methodInsnNode.name + methodInsnNode.desc) {
                case "java/lang/String.length()I": {
                    return PureCalls.str(list, 0).length();
                }
                case "java/lang/String.hashCode()I": {
                    return PureCalls.str(list, 0).hashCode();
                }
                case "java/lang/String.isEmpty()Z": {
                    return PureCalls.str(list, 0).isEmpty() ? 1 : 0;
                }
                case "java/lang/String.charAt(I)C": {
                    return (int)PureCalls.str(list, 0).charAt(PureCalls.integer(list, 1));
                }
                case "java/lang/String.equals(Ljava/lang/Object;)Z": {
                    Integer n;
                    Object object3 = list.get((int)1).constant;
                    if (object3 instanceof String) {
                        String string = (String)object3;
                        n = PureCalls.str(list, 0).equals(string) ? 1 : 0;
                    } else {
                        n = null;
                    }
                    return n;
                }
                case "java/lang/String.intern()Ljava/lang/String;": {
                    return PureCalls.str(list, 0);
                }
                case "java/lang/String.toString()Ljava/lang/String;": {
                    return PureCalls.str(list, 0);
                }
                case "java/lang/Math.abs(I)I": {
                    return Math.abs(PureCalls.integer(list, 0));
                }
                case "java/lang/Math.min(II)I": {
                    return Math.min(PureCalls.integer(list, 0), PureCalls.integer(list, 1));
                }
                case "java/lang/Math.max(II)I": {
                    return Math.max(PureCalls.integer(list, 0), PureCalls.integer(list, 1));
                }
                case "java/lang/Math.abs(J)J": {
                    return Math.abs((Long)list.get((int)0).constant);
                }
                case "java/lang/Integer.parseInt(Ljava/lang/String;)I": {
                    return Integer.parseInt(PureCalls.str(list, 0));
                }
                case "java/lang/Integer.reverse(I)I": {
                    return Integer.reverse(PureCalls.integer(list, 0));
                }
                case "java/lang/Integer.bitCount(I)I": {
                    return Integer.bitCount(PureCalls.integer(list, 0));
                }
                case "java/lang/Integer.rotateLeft(II)I": {
                    return Integer.rotateLeft(PureCalls.integer(list, 0), PureCalls.integer(list, 1));
                }
                case "java/lang/Integer.rotateRight(II)I": {
                    return Integer.rotateRight(PureCalls.integer(list, 0), PureCalls.integer(list, 1));
                }
            }
            return null;
        }
        catch (RuntimeException runtimeException) {
            return null;
        }
    }

    private static String str(List<? extends ConstValue> list, int n) {
        return (String)list.get((int)n).constant;
    }

    private static int integer(List<? extends ConstValue> list, int n) {
        return (Integer)list.get((int)n).constant;
    }
}

