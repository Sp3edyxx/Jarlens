/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.analysis;

import dev.jarlens.deob.Constants;
import dev.jarlens.deob.analysis.ConstValue;
import org.objectweb.asm.Type;

public final class Folding {
    private Folding() {
    }

    public static Object unary(int n, Object object) {
        try {
            switch (n) {
                case 116: {
                    return -((Integer)object).intValue();
                }
                case 117: {
                    return -((Long)object).longValue();
                }
                case 118: {
                    return Float.valueOf(-((Float)object).floatValue());
                }
                case 119: {
                    return -((Double)object).doubleValue();
                }
                case 133: {
                    return (long)((Integer)object).intValue();
                }
                case 134: {
                    return Float.valueOf(((Integer)object).intValue());
                }
                case 135: {
                    return (double)((Integer)object).intValue();
                }
                case 136: {
                    return (int)((Long)object).longValue();
                }
                case 137: {
                    return Float.valueOf(((Long)object).longValue());
                }
                case 138: {
                    return (double)((Long)object).longValue();
                }
                case 139: {
                    return (int)((Float)object).floatValue();
                }
                case 140: {
                    return (long)((Float)object).floatValue();
                }
                case 141: {
                    return (double)((Float)object).floatValue();
                }
                case 142: {
                    return (int)((Double)object).doubleValue();
                }
                case 143: {
                    return (long)((Double)object).doubleValue();
                }
                case 144: {
                    return Float.valueOf((float)((Double)object).doubleValue());
                }
                case 145: {
                    return (int)((byte)((Integer)object).intValue());
                }
                case 146: {
                    return (int)((char)((Integer)object).intValue());
                }
                case 147: {
                    return (int)((short)((Integer)object).intValue());
                }
            }
            return null;
        }
        catch (ClassCastException | NullPointerException runtimeException) {
            return null;
        }
    }

    public static Object binary(int n, Object object, Object object2) {
        try {
            switch (n) {
                case 96: {
                    return (Integer)object + (Integer)object2;
                }
                case 100: {
                    return (Integer)object - (Integer)object2;
                }
                case 104: {
                    return (Integer)object * (Integer)object2;
                }
                case 108: {
                    return (Integer)object2 == 0 ? null : Integer.valueOf((Integer)object / (Integer)object2);
                }
                case 112: {
                    return (Integer)object2 == 0 ? null : Integer.valueOf((Integer)object % (Integer)object2);
                }
                case 120: {
                    return (Integer)object << (Integer)object2;
                }
                case 122: {
                    return (Integer)object >> (Integer)object2;
                }
                case 124: {
                    return (Integer)object >>> (Integer)object2;
                }
                case 126: {
                    return (Integer)object & (Integer)object2;
                }
                case 128: {
                    return (Integer)object | (Integer)object2;
                }
                case 130: {
                    return (Integer)object ^ (Integer)object2;
                }
                case 97: {
                    return (Long)object + (Long)object2;
                }
                case 101: {
                    return (Long)object - (Long)object2;
                }
                case 105: {
                    return (Long)object * (Long)object2;
                }
                case 109: {
                    return (Long)object2 == 0L ? null : Long.valueOf((Long)object / (Long)object2);
                }
                case 113: {
                    return (Long)object2 == 0L ? null : Long.valueOf((Long)object % (Long)object2);
                }
                case 121: {
                    return (Long)object << (Integer)object2;
                }
                case 123: {
                    return (Long)object >> (Integer)object2;
                }
                case 125: {
                    return (Long)object >>> (Integer)object2;
                }
                case 127: {
                    return (Long)object & (Long)object2;
                }
                case 129: {
                    return (Long)object | (Long)object2;
                }
                case 131: {
                    return (Long)object ^ (Long)object2;
                }
                case 98: {
                    return Float.valueOf(((Float)object).floatValue() + ((Float)object2).floatValue());
                }
                case 102: {
                    return Float.valueOf(((Float)object).floatValue() - ((Float)object2).floatValue());
                }
                case 106: {
                    return Float.valueOf(((Float)object).floatValue() * ((Float)object2).floatValue());
                }
                case 110: {
                    return Float.valueOf(((Float)object).floatValue() / ((Float)object2).floatValue());
                }
                case 114: {
                    return Float.valueOf(((Float)object).floatValue() % ((Float)object2).floatValue());
                }
                case 99: {
                    return (Double)object + (Double)object2;
                }
                case 103: {
                    return (Double)object - (Double)object2;
                }
                case 107: {
                    return (Double)object * (Double)object2;
                }
                case 111: {
                    return (Double)object / (Double)object2;
                }
                case 115: {
                    return (Double)object % (Double)object2;
                }
                case 148: {
                    return Long.compare((Long)object, (Long)object2);
                }
                case 149: {
                    return Folding.fcmp(((Float)object).floatValue(), ((Float)object2).floatValue(), -1);
                }
                case 150: {
                    return Folding.fcmp(((Float)object).floatValue(), ((Float)object2).floatValue(), 1);
                }
                case 151: {
                    return Folding.dcmp((Double)object, (Double)object2, -1);
                }
                case 152: {
                    return Folding.dcmp((Double)object, (Double)object2, 1);
                }
            }
            return null;
        }
        catch (ClassCastException | NullPointerException runtimeException) {
            return null;
        }
    }

    private static int fcmp(float f, float f2, int n) {
        if (Float.isNaN(f) || Float.isNaN(f2)) {
            return n;
        }
        return f > f2 ? 1 : (f == f2 ? 0 : -1);
    }

    private static int dcmp(double d, double d2, int n) {
        if (Double.isNaN(d) || Double.isNaN(d2)) {
            return n;
        }
        return d > d2 ? 1 : (d == d2 ? 0 : -1);
    }

    public static Boolean ifZero(int n, Object object) {
        if (!(object instanceof Integer)) {
            return null;
        }
        int n2 = (Integer)object;
        return switch (n) {
            case 153 -> n2 == 0;
            case 154 -> n2 != 0;
            case 155 -> n2 < 0;
            case 156 -> n2 >= 0;
            case 157 -> n2 > 0;
            case 158 -> n2 <= 0;
            default -> null;
        };
    }

    public static Boolean ifCmp(int n, Object object, Object object2) {
        if (!(object instanceof Integer) || !(object2 instanceof Integer)) {
            return null;
        }
        int n2 = (Integer)object;
        int n3 = (Integer)object2;
        return switch (n) {
            case 159 -> n2 == n3;
            case 160 -> n2 != n3;
            case 161 -> n2 < n3;
            case 162 -> n2 >= n3;
            case 163 -> n2 > n3;
            case 164 -> n2 <= n3;
            default -> null;
        };
    }

    public static Boolean ifNull(int n, ConstValue constValue) {
        Boolean bl = null;
        if (constValue.constant == Constants.NULL) {
            bl = true;
        } else if (constValue.constant instanceof String || constValue.constant instanceof Type) {
            bl = false;
        }
        if (bl == null) {
            return null;
        }
        return n == 198 ? bl : bl == false;
    }
}

