/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.analysis;

import dev.jarlens.deob.Constants;
import dev.jarlens.deob.analysis.ConstValue;
import dev.jarlens.deob.analysis.Folding;
import dev.jarlens.deob.analysis.PureCalls;
import java.util.List;
import org.objectweb.asm.ConstantDynamic;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.IincInsnNode;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MultiANewArrayInsnNode;
import org.objectweb.asm.tree.TryCatchBlockNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.analysis.AnalyzerException;
import org.objectweb.asm.tree.analysis.Frame;
import org.objectweb.asm.tree.analysis.Interpreter;

public final class ConstantInterpreter
extends Interpreter<ConstValue> {
    private static final Type STRING = Type.getObjectType("java/lang/String");
    private static final Type CLASS = Type.getObjectType("java/lang/Class");
    private final StaticConstants statics;

    public ConstantInterpreter(StaticConstants staticConstants) {
        super(589824);
        this.statics = staticConstants;
    }

    @Override
    public ConstValue newValue(Type type) {
        if (type == null) {
            return ConstValue.UNINITIALIZED;
        }
        if (type.getSort() == 0) {
            return null;
        }
        return ConstValue.unknown(type);
    }

    @Override
    public ConstValue newParameterValue(boolean bl, int n, Type type) {
        if (bl && n == 0) {
            return ConstValue.nonNull(type);
        }
        return this.newValue(type);
    }

    @Override
    public ConstValue newExceptionValue(TryCatchBlockNode tryCatchBlockNode, Frame<ConstValue> frame, Type type) {
        return ConstValue.nonNull(type);
    }

    @Override
    public ConstValue newOperation(AbstractInsnNode abstractInsnNode) throws AnalyzerException {
        int n = abstractInsnNode.getOpcode();
        switch (n) {
            case 1: {
                return ConstValue.of(ConstValue.OBJECT, Constants.NULL);
            }
            case 2: 
            case 3: 
            case 4: 
            case 5: 
            case 6: 
            case 7: 
            case 8: {
                return ConstValue.of(Type.INT_TYPE, n - 3);
            }
            case 9: 
            case 10: {
                return ConstValue.of(Type.LONG_TYPE, n - 9);
            }
            case 11: 
            case 12: 
            case 13: {
                return ConstValue.of(Type.FLOAT_TYPE, Float.valueOf(n - 11));
            }
            case 14: 
            case 15: {
                return ConstValue.of(Type.DOUBLE_TYPE, n - 14);
            }
            case 16: 
            case 17: {
                return ConstValue.of(Type.INT_TYPE, ((IntInsnNode)abstractInsnNode).operand);
            }
            case 18: {
                Object object = ((LdcInsnNode)abstractInsnNode).cst;
                if (object instanceof Integer) {
                    return ConstValue.of(Type.INT_TYPE, object);
                }
                if (object instanceof Float) {
                    return ConstValue.of(Type.FLOAT_TYPE, object);
                }
                if (object instanceof Long) {
                    return ConstValue.of(Type.LONG_TYPE, object);
                }
                if (object instanceof Double) {
                    return ConstValue.of(Type.DOUBLE_TYPE, object);
                }
                if (object instanceof String) {
                    return ConstValue.of(STRING, object);
                }
                if (object instanceof Type) {
                    Type type = (Type)object;
                    if (type.getSort() == 11) {
                        return ConstValue.nonNull(Type.getObjectType("java/lang/invoke/MethodType"));
                    }
                    return ConstValue.of(CLASS, type);
                }
                if (object instanceof Handle) {
                    return ConstValue.nonNull(Type.getObjectType("java/lang/invoke/MethodHandle"));
                }
                if (object instanceof ConstantDynamic) {
                    ConstantDynamic constantDynamic = (ConstantDynamic)object;
                    return ConstValue.unknown(Type.getType(constantDynamic.getDescriptor()));
                }
                throw new AnalyzerException(abstractInsnNode, "Illegal LDC value " + String.valueOf(object));
            }
            case 168: {
                return ConstValue.RETURN_ADDRESS;
            }
            case 178: {
                FieldInsnNode fieldInsnNode = (FieldInsnNode)abstractInsnNode;
                Type type = Type.getType(fieldInsnNode.desc);
                Object object = this.statics == null ? null : this.statics.get(fieldInsnNode.owner, fieldInsnNode.name, fieldInsnNode.desc);
                return object != null ? ConstValue.of(type, object) : ConstValue.unknown(type);
            }
            case 187: {
                return ConstValue.nonNull(Type.getObjectType(((TypeInsnNode)abstractInsnNode).desc));
            }
        }
        throw new AnalyzerException(abstractInsnNode, "Unexpected opcode " + n);
    }

    @Override
    public ConstValue copyOperation(AbstractInsnNode abstractInsnNode, ConstValue constValue) {
        return constValue;
    }

    @Override
    public ConstValue unaryOperation(AbstractInsnNode abstractInsnNode, ConstValue constValue) {
        int n = abstractInsnNode.getOpcode();
        switch (n) {
            case 116: 
            case 136: 
            case 139: 
            case 142: 
            case 145: 
            case 146: 
            case 147: {
                return ConstantInterpreter.fold1(n, constValue, Type.INT_TYPE);
            }
            case 117: 
            case 133: 
            case 140: 
            case 143: {
                return ConstantInterpreter.fold1(n, constValue, Type.LONG_TYPE);
            }
            case 118: 
            case 134: 
            case 137: 
            case 144: {
                return ConstantInterpreter.fold1(n, constValue, Type.FLOAT_TYPE);
            }
            case 119: 
            case 135: 
            case 138: 
            case 141: {
                return ConstantInterpreter.fold1(n, constValue, Type.DOUBLE_TYPE);
            }
            case 132: {
                Object object = constValue.constant;
                if (object instanceof Integer) {
                    Integer n2 = (Integer)object;
                    return ConstValue.of(Type.INT_TYPE, n2 + ((IincInsnNode)abstractInsnNode).incr);
                }
                return ConstValue.unknown(Type.INT_TYPE);
            }
            case 180: {
                return ConstValue.unknown(Type.getType(((FieldInsnNode)abstractInsnNode).desc));
            }
            case 188: {
                return ConstValue.nonNull(Type.getType("[" + ConstantInterpreter.primitiveDesc(((IntInsnNode)abstractInsnNode).operand)));
            }
            case 189: {
                String string = ((TypeInsnNode)abstractInsnNode).desc;
                Type type = string.startsWith("[") ? Type.getType(string) : Type.getObjectType(string);
                return ConstValue.nonNull(Type.getType("[" + type.getDescriptor()));
            }
            case 190: {
                return ConstValue.unknown(Type.INT_TYPE);
            }
            case 192: {
                String string = ((TypeInsnNode)abstractInsnNode).desc;
                Type type = string.startsWith("[") ? Type.getType(string) : Type.getObjectType(string);
                Type type2 = type;
                if (constValue.constant == Constants.NULL) {
                    return ConstValue.of(type, Constants.NULL);
                }
                if (constValue.constant instanceof String && type.equals(STRING)) {
                    return constValue;
                }
                return constValue.nonNull ? ConstValue.nonNull(type) : ConstValue.unknown(type);
            }
            case 193: {
                if (constValue.constant == Constants.NULL) {
                    return ConstValue.of(Type.INT_TYPE, 0);
                }
                return ConstValue.unknown(Type.INT_TYPE);
            }
        }
        return null;
    }

    private static ConstValue fold1(int n, ConstValue constValue, Type type) {
        Object object;
        if (constValue.isConstant() && (object = Folding.unary(n, constValue.constant)) != null) {
            return ConstValue.of(type, object);
        }
        return ConstValue.unknown(type);
    }

    private static String primitiveDesc(int n) {
        return switch (n) {
            case 4 -> "Z";
            case 5 -> "C";
            case 8 -> "B";
            case 9 -> "S";
            case 10 -> "I";
            case 6 -> "F";
            case 7 -> "D";
            case 11 -> "J";
            default -> "I";
        };
    }

    @Override
    public ConstValue binaryOperation(AbstractInsnNode abstractInsnNode, ConstValue constValue, ConstValue constValue2) {
        int n = abstractInsnNode.getOpcode();
        switch (n) {
            case 46: 
            case 51: 
            case 52: 
            case 53: {
                return ConstValue.unknown(Type.INT_TYPE);
            }
            case 47: {
                return ConstValue.unknown(Type.LONG_TYPE);
            }
            case 48: {
                return ConstValue.unknown(Type.FLOAT_TYPE);
            }
            case 49: {
                return ConstValue.unknown(Type.DOUBLE_TYPE);
            }
            case 50: {
                if (constValue.type != null && constValue.type.getSort() == 9) {
                    return ConstValue.unknown(Type.getType(constValue.type.getDescriptor().substring(1)));
                }
                return ConstValue.unknown(ConstValue.OBJECT);
            }
            case 96: 
            case 100: 
            case 104: 
            case 108: 
            case 112: 
            case 120: 
            case 122: 
            case 124: 
            case 126: 
            case 128: 
            case 130: 
            case 148: 
            case 149: 
            case 150: 
            case 151: 
            case 152: {
                return ConstantInterpreter.fold2(n, constValue, constValue2, Type.INT_TYPE);
            }
            case 97: 
            case 101: 
            case 105: 
            case 109: 
            case 113: 
            case 121: 
            case 123: 
            case 125: 
            case 127: 
            case 129: 
            case 131: {
                return ConstantInterpreter.fold2(n, constValue, constValue2, Type.LONG_TYPE);
            }
            case 98: 
            case 102: 
            case 106: 
            case 110: 
            case 114: {
                return ConstantInterpreter.fold2(n, constValue, constValue2, Type.FLOAT_TYPE);
            }
            case 99: 
            case 103: 
            case 107: 
            case 111: 
            case 115: {
                return ConstantInterpreter.fold2(n, constValue, constValue2, Type.DOUBLE_TYPE);
            }
        }
        return null;
    }

    private static ConstValue fold2(int n, ConstValue constValue, ConstValue constValue2, Type type) {
        Object object;
        if (constValue.isConstant() && constValue2.isConstant() && (object = Folding.binary(n, constValue.constant, constValue2.constant)) != null) {
            return ConstValue.of(type, object);
        }
        return ConstValue.unknown(type);
    }

    @Override
    public ConstValue ternaryOperation(AbstractInsnNode abstractInsnNode, ConstValue constValue, ConstValue constValue2, ConstValue constValue3) {
        return null;
    }

    @Override
    public ConstValue naryOperation(AbstractInsnNode abstractInsnNode, List<? extends ConstValue> list) {
        String string;
        Object object;
        int n = abstractInsnNode.getOpcode();
        if (n == 197) {
            return ConstValue.nonNull(Type.getType(((MultiANewArrayInsnNode)abstractInsnNode).desc));
        }
        if (abstractInsnNode instanceof MethodInsnNode) {
            object = (MethodInsnNode)abstractInsnNode;
            string = ((MethodInsnNode)object).desc;
        } else {
            string = ((InvokeDynamicInsnNode)abstractInsnNode).desc;
        }
        object = string;
        Type type = Type.getReturnType((String)object);
        if (type.getSort() == 0) {
            return null;
        }
        if (abstractInsnNode instanceof MethodInsnNode) {
            MethodInsnNode methodInsnNode = (MethodInsnNode)abstractInsnNode;
            Object object2 = PureCalls.fold(methodInsnNode, list);
            if (object2 != null) {
                return ConstValue.of(type, object2);
            }
            if (methodInsnNode.owner.equals("java/lang/StringBuilder") && methodInsnNode.name.equals("append")) {
                return ConstValue.nonNull(type);
            }
        }
        return ConstValue.unknown(type);
    }

    @Override
    public void returnOperation(AbstractInsnNode abstractInsnNode, ConstValue constValue, ConstValue constValue2) {
    }

    @Override
    public ConstValue merge(ConstValue constValue, ConstValue constValue2) {
        Type type;
        if (constValue.equals(constValue2)) {
            return constValue;
        }
        if (constValue.type == null || constValue2.type == null || constValue.getSize() != constValue2.getSize()) {
            return ConstValue.UNINITIALIZED;
        }
        if (constValue.type.equals(constValue2.type)) {
            type = constValue.type;
        } else if (constValue.isReference() && constValue2.isReference()) {
            type = ConstValue.OBJECT;
        } else {
            return ConstValue.UNINITIALIZED;
        }
        boolean bl = constValue.nonNull && constValue2.nonNull;
        ConstValue constValue3 = bl ? ConstValue.nonNull(type) : ConstValue.unknown(type);
        return constValue3.equals(constValue) ? constValue : constValue3;
    }

    public static interface StaticConstants {
        public Object get(String var1, String var2, String var3);
    }
}

