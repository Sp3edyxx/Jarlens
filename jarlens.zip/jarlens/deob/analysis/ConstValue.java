/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.deob.analysis;

import dev.jarlens.deob.Constants;
import java.util.Objects;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.analysis.Value;

public final class ConstValue
implements Value {
    public static final ConstValue UNINITIALIZED = new ConstValue(1, null, null, false);
    public static final ConstValue RETURN_ADDRESS = new ConstValue(1, Type.VOID_TYPE, null, false);
    public static final Type OBJECT = Type.getObjectType("java/lang/Object");
    private final int size;
    public final Type type;
    public final Object constant;
    public final boolean nonNull;

    private ConstValue(int n, Type type, Object object, boolean bl) {
        this.size = n;
        this.type = type;
        this.constant = object;
        this.nonNull = bl;
    }

    public static ConstValue unknown(Type type) {
        if (type == null) {
            return UNINITIALIZED;
        }
        return new ConstValue(type.getSize(), ConstValue.normalize(type), null, false);
    }

    public static ConstValue nonNull(Type type) {
        return new ConstValue(1, ConstValue.normalize(type), null, true);
    }

    public static ConstValue of(Type type, Object object) {
        boolean bl = object != null && object != Constants.NULL && !(object instanceof Number);
        return new ConstValue(type.getSize(), ConstValue.normalize(type), object, bl);
    }

    private static Type normalize(Type type) {
        return switch (type.getSort()) {
            case 1, 2, 3, 4, 5 -> Type.INT_TYPE;
            default -> type;
        };
    }

    public boolean isConstant() {
        return this.constant != null;
    }

    public boolean isReference() {
        return this.type != null && (this.type.getSort() == 10 || this.type.getSort() == 9);
    }

    @Override
    public int getSize() {
        return this.size;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof ConstValue)) {
            return false;
        }
        ConstValue constValue = (ConstValue)object;
        return this.size == constValue.size && this.nonNull == constValue.nonNull && Objects.equals(this.type, constValue.type) && ConstValue.constEquals(this.constant, constValue.constant);
    }

    private static boolean constEquals(Object object, Object object2) {
        Number number;
        if (object instanceof Float) {
            number = (Float)object;
            if (object2 instanceof Float) {
                Float f = (Float)object2;
                return Float.floatToRawIntBits(((Float)number).floatValue()) == Float.floatToRawIntBits(f.floatValue());
            }
        }
        if (object instanceof Double) {
            number = (Double)object;
            if (object2 instanceof Double) {
                Double d = (Double)object2;
                return Double.doubleToRawLongBits((Double)number) == Double.doubleToRawLongBits(d);
            }
        }
        return Objects.equals(object, object2);
    }

    public int hashCode() {
        return 31 * (31 * (31 + this.size) + Objects.hashCode(this.type)) + Boolean.hashCode(this.nonNull);
    }

    public String toString() {
        return (this.type == null ? "?" : this.type.getDescriptor()) + (String)(this.constant != null ? "=" + String.valueOf(this.constant) : "") + (this.nonNull ? "!" : "");
    }
}

