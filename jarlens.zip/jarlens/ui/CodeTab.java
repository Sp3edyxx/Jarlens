/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import dev.jarlens.decompile.DecompilerService;
import dev.jarlens.ui.Editors;
import dev.jarlens.ui.FindBar;
import dev.jarlens.ui.Session;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.geom.Rectangle2D;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.event.HyperlinkEvent;
import javax.swing.text.BadLocationException;
import org.fife.ui.rsyntaxtextarea.LinkGenerator;
import org.fife.ui.rsyntaxtextarea.LinkGeneratorResult;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.Token;

final class CodeTab
extends JPanel {
    final String className;
    private final Session session;
    private final RSyntaxTextArea area = Editors.create("text/java");
    private final JToggleButton originalToggle = new JToggleButton("Original");
    private final JLabel status = new JLabel(" ");
    private final FindBar findBar = new FindBar(this.area);
    private Session.Variant variant;
    private DecompilerService.Engine engine;
    private SwingWorker<DecompilerService.Result, Void> worker;
    private boolean loading;
    private final List<Runnable> afterLoad = new ArrayList<Runnable>();
    private String source = "";

    CodeTab(Session session, String string, Session.Variant variant, DecompilerService.Engine engine, Navigator navigator) {
        super(new BorderLayout());
        this.session = session;
        this.className = string;
        this.variant = variant;
        this.engine = engine;
        JToolBar jToolBar = new JToolBar();
        jToolBar.setFloatable(false);
        jToolBar.setBorder(BorderFactory.createEmptyBorder(2, 4, 2, 4));
        this.originalToggle.setToolTipText("Show the class as it is in the original jar (not deobfuscated)");
        this.originalToggle.setSelected(variant == Session.Variant.ORIGINAL);
        this.originalToggle.addActionListener(actionEvent -> this.setVariant(this.originalToggle.isSelected() ? Session.Variant.ORIGINAL : Session.Variant.DEOBFUSCATED));
        jToolBar.add(this.originalToggle);
        jToolBar.addSeparator();
        this.status.putClientProperty("FlatLaf.styleClass", "small");
        this.status.setForeground(UIManager.getColor("Label.disabledForeground"));
        jToolBar.add(this.status);
        this.area.setText("// Decompiling " + string.replace('/', '.') + " \u2026");
        this.area.setHyperlinksEnabled(true);
        this.area.setLinkScanningMask(Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx());
        this.area.setLinkGenerator(new Links(this, navigator));
        this.area.registerKeyboardAction(actionEvent -> this.findBar.open(), KeyStroke.getKeyStroke(70, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()), 2);
        this.add((Component)jToolBar, "North");
        this.add((Component)Editors.scroll(this.area), "Center");
        this.add((Component)this.findBar, "South");
        this.load();
    }

    Session.Variant variant() {
        return this.variant;
    }

    String displayName() {
        String string = this.session.nameIn(this.className, this.variant);
        return string.substring(string.lastIndexOf(47) + 1);
    }

    String shownClassName() {
        return this.session.nameIn(this.className, this.variant);
    }

    String source() {
        return this.source;
    }

    RSyntaxTextArea area() {
        return this.area;
    }

    void openFind() {
        this.findBar.open();
    }

    void setVariant(Session.Variant variant) {
        if (variant == this.variant) {
            return;
        }
        this.variant = variant;
        this.originalToggle.setSelected(variant == Session.Variant.ORIGINAL);
        this.load();
    }

    void setEngine(DecompilerService.Engine engine) {
        if (engine == this.engine) {
            return;
        }
        this.engine = engine;
        this.load();
    }

    void reload() {
        this.load();
    }

    void whenLoaded(Runnable runnable) {
        if (this.loading) {
            this.afterLoad.add(runnable);
        } else {
            runnable.run();
        }
    }

    private void load() {
        if (this.worker != null) {
            this.worker.cancel(true);
        }
        this.loading = true;
        final String string = this.session.nameIn(this.className, this.variant);
        this.status.setText("Decompiling\u2026");
        final int n = this.area.getCaretPosition();
        final Session.Variant variant = this.variant;
        final DecompilerService.Engine engine = this.engine;
        this.worker = new SwingWorker<DecompilerService.Result, Void>(this){
            final /* synthetic */ CodeTab this$0;
            {
                CodeTab codeTab2 = codeTab;
                Objects.requireNonNull(codeTab2);
                this.this$0 = codeTab2;
            }

            @Override
            protected DecompilerService.Result doInBackground() {
                return this.this$0.session.decompile(string, variant, engine);
            }

            @Override
            protected void done() {
                Serializable serializable;
                DecompilerService.Result result;
                if (this.isCancelled()) {
                    return;
                }
                try {
                    result = (DecompilerService.Result)this.get();
                }
                catch (InterruptedException | ExecutionException exception) {
                    serializable = exception.getCause() != null ? exception.getCause() : exception;
                    result = new DecompilerService.Result("// Failed: " + String.valueOf(serializable), "none", ((Throwable)serializable).toString());
                }
                this.this$0.source = result.source();
                this.this$0.area.setText(this.this$0.source);
                this.this$0.area.setCaretPosition(Math.min(n, this.this$0.area.getDocument().getLength()));
                if (n == 0) {
                    this.this$0.area.setCaretPosition(0);
                }
                this.this$0.area.discardAllEdits();
                String string2 = (variant == Session.Variant.ORIGINAL ? "Original" : "Deobfuscated") + " \u00b7 " + result.engine();
                if (result.note() != null) {
                    string2 = string2 + " \u00b7 " + result.note();
                }
                this.this$0.status.setText(string2);
                this.this$0.loading = false;
                serializable = new ArrayList<Runnable>(this.this$0.afterLoad);
                this.this$0.afterLoad.clear();
                Iterator iterator = ((ArrayList)serializable).iterator();
                while (iterator.hasNext()) {
                    Runnable runnable = (Runnable)iterator.next();
                    runnable.run();
                }
            }
        };
        this.worker.execute();
    }

    void goToLine(int n, String string) {
        try {
            String string2;
            int n2;
            int n3 = Math.max(0, Math.min(n, this.area.getLineCount() - 1));
            int n4 = this.area.getLineStartOffset(n3);
            int n5 = this.area.getLineEndOffset(n3);
            this.area.requestFocusInWindow();
            if (string != null && !string.isEmpty() && (n2 = (string2 = this.area.getText(n4, n5 - n4)).toLowerCase().indexOf(string.toLowerCase())) >= 0) {
                this.select(n4 + n2, n4 + n2 + string.length());
                return;
            }
            this.select(n4, n4);
        }
        catch (BadLocationException badLocationException) {
            // empty catch block
        }
    }

    void select(int n, int n2) {
        int n3 = this.area.getDocument().getLength();
        this.area.setCaretPosition(Math.min(n, n3));
        this.area.moveCaretPosition(Math.min(n2, n3));
        this.centerCaret();
    }

    private void centerCaret() {
        SwingUtilities.invokeLater(() -> {
            try {
                Rectangle2D rectangle2D = this.area.modelToView2D(this.area.getCaretPosition());
                if (rectangle2D == null) {
                    return;
                }
                Rectangle rectangle = this.area.getVisibleRect();
                int n = (int)rectangle2D.getY() - rectangle.height / 3;
                this.area.scrollRectToVisible(new Rectangle(0, Math.max(0, n), 1, rectangle.height));
            }
            catch (BadLocationException badLocationException) {
                // empty catch block
            }
        });
    }

    boolean goToMember(String string) {
        String string2 = Pattern.quote(string);
        Pattern[] patternArray = new Pattern[]{Pattern.compile("(?m)^[ \\t]*(?:@\\w+(?:\\([^)]*\\))?\\s+)*(?:(?:public|protected|private|static|final|abstract|synchronized|native|default|strictfp)\\s+)*(?:<[^>]+>\\s+)?[\\w.$<>\\[\\],? ]+\\s+(" + string2 + ")\\s*\\([^;]*$"), Pattern.compile("(?m)^[ \\t]*(?:(?:public|protected|private|static|final|volatile|transient)\\s+)*[\\w.$<>\\[\\],? ]+\\s+(" + string2 + ")\\s*(?:=|;)"), Pattern.compile("(?m)^[ \\t]*(" + string2 + ")\\s*(?:\\(|,|;|\\{)"), Pattern.compile("\\b(" + string2 + ")\\s*\\(")};
        for (Pattern pattern : patternArray) {
            Matcher matcher = pattern.matcher(this.source);
            if (!matcher.find()) continue;
            this.select(matcher.start(1), matcher.end(1));
            return true;
        }
        return false;
    }

    private static boolean isNavigable(Token token) {
        int n = token.getType();
        if (n != 20 && n != 8 && n != 16 && n != 19) {
            return false;
        }
        String string = CodeTab.stripAt(token.getLexeme());
        return !string.isEmpty() && Character.isJavaIdentifierStart(string.charAt(0));
    }

    private static String stripAt(String string) {
        if (string == null) {
            return "";
        }
        return string.startsWith("@") ? string.substring(1) : string;
    }

    private static String qualifierBefore(RSyntaxTextArea rSyntaxTextArea, int n) {
        try {
            int n2;
            int n3 = Math.max(0, n - 300);
            String string = rSyntaxTextArea.getText(n3, n - n3);
            for (n2 = string.length() - 1; n2 >= 0 && Character.isWhitespace(string.charAt(n2)); --n2) {
            }
            if (n2 < 0 || string.charAt(n2) != '.') {
                return null;
            }
            --n2;
            while (n2 >= 0 && Character.isWhitespace(string.charAt(n2))) {
                --n2;
            }
            int n4 = n2 + 1;
            if (n2 >= 0 && string.charAt(n2) == ')') {
                return "()";
            }
            while (n2 >= 0 && (Character.isJavaIdentifierPart(string.charAt(n2)) || string.charAt(n2) == '.')) {
                --n2;
            }
            String string2 = string.substring(n2 + 1, n4);
            return string2.isEmpty() ? null : string2;
        }
        catch (BadLocationException badLocationException) {
            return null;
        }
    }

    private final class Links
    implements LinkGenerator {
        private final Navigator nav;
        final /* synthetic */ CodeTab this$0;

        Links(CodeTab codeTab, Navigator navigator) {
            CodeTab codeTab2 = codeTab;
            Objects.requireNonNull(codeTab2);
            this.this$0 = codeTab2;
            this.nav = navigator;
        }

        @Override
        public LinkGeneratorResult isLinkAtOffset(RSyntaxTextArea rSyntaxTextArea, int n) {
            Token token = rSyntaxTextArea.modelToToken(n);
            if (token == null || !CodeTab.isNavigable(token)) {
                return null;
            }
            final String string = CodeTab.stripAt(token.getLexeme());
            final int n2 = token.getOffset() + (token.getLexeme().startsWith("@") ? 1 : 0);
            final String string2 = CodeTab.qualifierBefore(rSyntaxTextArea, n2);
            return new LinkGeneratorResult(){
                final /* synthetic */ Links this$1;
                {
                    Links links2 = links;
                    Objects.requireNonNull(links2);
                    this.this$1 = links2;
                }

                @Override
                public HyperlinkEvent execute() {
                    this.this$1.nav.navigate(this.this$1.this$0, string, string2, n2);
                    return null;
                }

                @Override
                public int getSourceOffset() {
                    return n2;
                }
            };
        }
    }

    static interface Navigator {
        public void navigate(CodeTab var1, String var2, String var3, int var4);
    }
}

