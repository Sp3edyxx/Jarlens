/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;

public final class NavIndex {
    private final Map<String, Info> classes = new HashMap<String, Info>();
    private final Map<String, List<String>> bySimpleName = new HashMap<String, List<String>>();
    private final Map<String, Set<String>> memberOwners = new HashMap<String, Set<String>>();
    private static final Pattern IMPORT = Pattern.compile("(?m)^\\s*import\\s+(?:static\\s+)?([\\w.$]+)\\s*;");

    private NavIndex() {
    }

    static NavIndex build(Map<String, byte[]> map) {
        NavIndex navIndex = new NavIndex();
        for (Map.Entry<String, byte[]> entry : map.entrySet()) {
            final Info info = new Info();
            try {
                new ClassReader(entry.getValue()).accept(new ClassVisitor(589824){

                    @Override
                    public void visit(int n, int n2, String string, String string2, String string3, String[] stringArray) {
                        info.name = string;
                        info.superName = string3;
                        if (stringArray != null) {
                            info.interfaces.addAll(List.of(stringArray));
                        }
                    }

                    @Override
                    public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
                        info.members.add(string);
                        return null;
                    }

                    @Override
                    public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
                        if (!string.startsWith("<")) {
                            info.members.add(string);
                        }
                        return null;
                    }
                }, 7);
            }
            catch (Exception exception) {
                continue;
            }
            if (info.name == null) continue;
            navIndex.classes.put(info.name, info);
            navIndex.bySimpleName.computeIfAbsent(NavIndex.simpleName(info.name), string -> new ArrayList()).add(info.name);
            for (String string2 : info.members) {
                navIndex.memberOwners.computeIfAbsent(string2, string -> new TreeSet()).add(info.name);
            }
        }
        return navIndex;
    }

    static String simpleName(String string) {
        String string2 = string.substring(string.lastIndexOf(47) + 1);
        int n = string2.lastIndexOf(36);
        return n >= 0 && n < string2.length() - 1 ? string2.substring(n + 1) : string2;
    }

    static String packageOf(String string) {
        int n = string.lastIndexOf(47);
        return n < 0 ? "" : string.substring(0, n);
    }

    public boolean contains(String string) {
        return this.classes.containsKey(string);
    }

    public String resolveClass(String string, String string2, String string3) {
        List<String> list;
        String string4;
        Object object;
        Object object2;
        if (string == null || string.isEmpty()) {
            return null;
        }
        String string5 = string.replace('.', '/');
        if (this.classes.containsKey(string5)) {
            return string5;
        }
        String string6 = this.resolveNestedDots(string, string2, string3);
        if (string6 != null) {
            return string6;
        }
        if (string3 != null) {
            object2 = IMPORT.matcher(string3);
            while (((Matcher)object2).find()) {
                object = ((Matcher)object2).group(1);
                if (!((String)object).endsWith("." + string) && !((String)object).equals(string) || (string4 = this.findByDotted((String)object)) == null) continue;
                return string4;
            }
        }
        if (string2 != null) {
            string4 = string2;
            while (true) {
                if (this.classes.containsKey(object = string4 + "$" + string)) {
                    return object;
                }
                int n = string4.lastIndexOf(36);
                if (n < 0) break;
                string4 = string4.substring(0, n);
            }
            object = NavIndex.packageOf(string2);
            object2 = ((String)object).isEmpty() ? string : (String)object + "/" + string;
            String string7 = object2;
            if (this.classes.containsKey(object2)) {
                return object2;
            }
        }
        if ((list = this.bySimpleName.get(string)) != null && list.size() == 1) {
            return list.get(0);
        }
        return null;
    }

    private String resolveNestedDots(String string, String string2, String string3) {
        int n = string.indexOf(46);
        if (n < 0) {
            return null;
        }
        String string4 = this.resolveClass(string.substring(0, n), string2, string3);
        if (string4 == null) {
            return null;
        }
        String string5 = string.substring(n + 1).replace('.', '$');
        String string6 = string4 + "$" + string5;
        return this.classes.containsKey(string6) ? string6 : null;
    }

    private String findByDotted(String string) {
        Object object = string.replace('.', '/');
        while (!this.classes.containsKey(object)) {
            int n = ((String)object).lastIndexOf(47);
            if (n < 0) {
                return null;
            }
            object = ((String)object).substring(0, n) + "$" + ((String)object).substring(n + 1);
        }
        return object;
    }

    public String declaringClass(String string, String string2) {
        HashSet<String> hashSet = new HashSet<String>();
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add(string);
        while (!arrayList.isEmpty()) {
            Info info;
            String string3 = (String)arrayList.remove(0);
            if (string3 == null || !hashSet.add(string3) || (info = this.classes.get(string3)) == null) continue;
            if (info.members.contains(string2)) {
                return string3;
            }
            arrayList.add(info.superName);
            arrayList.addAll(info.interfaces);
        }
        return null;
    }

    public Set<String> ownersOf(String string) {
        return this.memberOwners.getOrDefault(string, Set.of());
    }

    public Set<String> classNames() {
        return new LinkedHashSet<String>(this.classes.keySet());
    }

    static final class Info {
        String name;
        String superName;
        List<String> interfaces = new ArrayList<String>();
        Set<String> members = new HashSet<String>();

        Info() {
        }
    }
}

