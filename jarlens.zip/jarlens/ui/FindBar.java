/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import java.awt.FlowLayout;
import java.util.Objects;
import java.util.regex.PatternSyntaxException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rtextarea.SearchContext;
import org.fife.ui.rtextarea.SearchEngine;
import org.fife.ui.rtextarea.SearchResult;

final class FindBar
extends JPanel {
    private final RSyntaxTextArea area;
    private final JTextField field = new JTextField(22);
    private final JCheckBox matchCase = new JCheckBox("Match case");
    private final JCheckBox regex = new JCheckBox("Regex");
    private final JLabel status = new JLabel();

    FindBar(RSyntaxTextArea rSyntaxTextArea) {
        super(new FlowLayout(0, 6, 2));
        this.area = rSyntaxTextArea;
        this.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIManager.getColor("Component.borderColor")));
        this.field.putClientProperty("JTextField.placeholderText", "Find in file");
        JButton jButton = new JButton("Next");
        JButton jButton2 = new JButton("Previous");
        JButton jButton3 = new JButton("\u2715");
        jButton3.putClientProperty("JButton.buttonType", "toolBarButton");
        jButton.addActionListener(actionEvent -> this.find(true));
        jButton2.addActionListener(actionEvent -> this.find(false));
        jButton3.addActionListener(actionEvent -> this.close());
        this.field.addActionListener(actionEvent -> this.find(true));
        this.field.getDocument().addDocumentListener(new DocumentListener(this){
            final /* synthetic */ FindBar this$0;
            {
                FindBar findBar2 = findBar;
                Objects.requireNonNull(findBar2);
                this.this$0 = findBar2;
            }

            @Override
            public void insertUpdate(DocumentEvent documentEvent) {
                this.this$0.markAll();
            }

            @Override
            public void removeUpdate(DocumentEvent documentEvent) {
                this.this$0.markAll();
            }

            @Override
            public void changedUpdate(DocumentEvent documentEvent) {
                this.this$0.markAll();
            }
        });
        this.matchCase.addActionListener(actionEvent -> this.markAll());
        this.regex.addActionListener(actionEvent -> this.markAll());
        this.registerKeyboardAction(actionEvent -> this.close(), KeyStroke.getKeyStroke(27, 0), 2);
        this.field.registerKeyboardAction(actionEvent -> this.find(false), KeyStroke.getKeyStroke(10, 64), 0);
        this.add(this.field);
        this.add(jButton2);
        this.add(jButton);
        this.add(this.matchCase);
        this.add(this.regex);
        this.add(this.status);
        this.add(jButton3);
        this.setVisible(false);
    }

    void open() {
        this.setVisible(true);
        String string = this.area.getSelectedText();
        if (string != null && !string.contains("\n") && string.length() < 200) {
            this.field.setText(string);
        }
        this.field.requestFocusInWindow();
        this.field.selectAll();
        this.markAll();
    }

    void close() {
        if (!this.isVisible()) {
            return;
        }
        this.setVisible(false);
        SearchEngine.markAll(this.area, new SearchContext());
        this.area.requestFocusInWindow();
    }

    private SearchContext context(boolean bl) {
        SearchContext searchContext = new SearchContext(this.field.getText());
        searchContext.setMatchCase(this.matchCase.isSelected());
        searchContext.setRegularExpression(this.regex.isSelected());
        searchContext.setSearchForward(bl);
        searchContext.setSearchWrap(true);
        searchContext.setMarkAll(true);
        return searchContext;
    }

    private void markAll() {
        if (!this.isVisible()) {
            return;
        }
        try {
            if (this.field.getText().isEmpty()) {
                SearchEngine.markAll(this.area, new SearchContext());
                this.status.setText("");
                return;
            }
            SearchResult searchResult = SearchEngine.markAll(this.area, this.context(true));
            this.status.setText(searchResult.getMarkedCount() + " matches");
        }
        catch (PatternSyntaxException patternSyntaxException) {
            this.status.setText("Invalid regex");
        }
    }

    private void find(boolean bl) {
        if (this.field.getText().isEmpty()) {
            return;
        }
        try {
            SearchResult searchResult = SearchEngine.find(this.area, this.context(bl));
            this.status.setText((String)(searchResult.wasFound() ? searchResult.getMarkedCount() + " matches" : "Not found"));
        }
        catch (PatternSyntaxException patternSyntaxException) {
            this.status.setText("Invalid regex");
        }
    }
}

