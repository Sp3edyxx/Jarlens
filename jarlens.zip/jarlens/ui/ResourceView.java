/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import dev.jarlens.ui.Editors;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;

final class ResourceView {
    private static final Set<String> IMAGE_EXT = Set.of("png", "jpg", "jpeg", "gif", "bmp", "wbmp");
    private static final Set<String> PLAIN_TEXT_EXT = Set.of("txt", "log", "list", "policy", "conf", "license", "notice", "readme", "sf", "factories", "providers", "processor", "info", "rst", "text");
    private static final char[] HEX = "0123456789abcdef".toCharArray();
    private static final Map<String, String> SYNTAX = Map.ofEntries(Map.entry("json", "text/jshintrc"), Map.entry("mcmeta", "text/jshintrc"), Map.entry("xml", "text/xml"), Map.entry("svg", "text/xml"), Map.entry("fxml", "text/xml"), Map.entry("xsd", "text/xml"), Map.entry("pom", "text/xml"), Map.entry("tld", "text/xml"), Map.entry("properties", "text/properties"), Map.entry("mf", "text/properties"), Map.entry("lang", "text/properties"), Map.entry("yml", "text/yaml"), Map.entry("yaml", "text/yaml"), Map.entry("html", "text/html"), Map.entry("htm", "text/html"), Map.entry("js", "text/javascript"), Map.entry("css", "text/css"), Map.entry("md", "text/markdown"), Map.entry("java", "text/java"), Map.entry("kt", "text/kotlin"), Map.entry("groovy", "text/groovy"), Map.entry("gradle", "text/groovy"), Map.entry("sh", "text/unix"), Map.entry("bat", "text/bat"), Map.entry("cmd", "text/bat"), Map.entry("ini", "text/ini"), Map.entry("cfg", "text/ini"), Map.entry("toml", "text/ini"), Map.entry("sql", "text/sql"), Map.entry("csv", "text/csv"), Map.entry("py", "text/python"), Map.entry("lua", "text/lua"), Map.entry("c", "text/c"), Map.entry("h", "text/c"), Map.entry("dockerfile", "text/dockerfile"));
    private static final int MAX_TEXT = 0x800000;
    private static final int MAX_HEX = 262144;

    private ResourceView() {
    }

    static String extension(String string) {
        String string2 = string.substring(string.lastIndexOf(47) + 1);
        int n = string2.lastIndexOf(46);
        return n < 0 ? string2.toLowerCase(Locale.ROOT) : string2.substring(n + 1).toLowerCase(Locale.ROOT);
    }

    static boolean isImage(String string) {
        return IMAGE_EXT.contains(ResourceView.extension(string));
    }

    static boolean isText(String string, byte[] byArray) {
        String string2 = ResourceView.extension(string);
        if (SYNTAX.containsKey(string2) || PLAIN_TEXT_EXT.contains(string2)) {
            return true;
        }
        if (string.startsWith("META-INF/services/")) {
            return true;
        }
        if (byArray == null) {
            return false;
        }
        return ResourceView.decodeUtf8(byArray, Math.min(byArray.length, 8192)) != null;
    }

    private static String decodeUtf8(byte[] byArray, int n) {
        for (int i = 0; i < n; ++i) {
            int n2 = byArray[i] & 0xFF;
            if (n2 != 0 && n2 >= 9 && (n2 <= 13 || n2 >= 32 || n2 == 27)) continue;
            return null;
        }
        try {
            return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(byArray, 0, n)).toString();
        }
        catch (CharacterCodingException characterCodingException) {
            return n < byArray.length ? ResourceView.decodeLenient(byArray, n) : null;
        }
    }

    private static String decodeLenient(byte[] byArray, int n2) {
        String string = new String(byArray, 0, n2, StandardCharsets.UTF_8);
        long l = string.chars().filter(n -> n == 65533).count();
        return l <= 2L ? string : null;
    }

    static JComponent create(String string, byte[] byArray, Runnable runnable) {
        JComponent jComponent;
        if (runnable != null) {
            return ResourceView.nestedJar(string, byArray, runnable);
        }
        if (ResourceView.isImage(string) && (jComponent = ResourceView.image(byArray)) != null) {
            return jComponent;
        }
        if (ResourceView.isText(string, byArray)) {
            return ResourceView.text(string, byArray);
        }
        return ResourceView.hex(byArray);
    }

    private static JComponent nestedJar(String string, byte[] byArray, Runnable runnable) {
        JPanel jPanel = new JPanel(new BorderLayout());
        JLabel jLabel = new JLabel("<html><h2>Nested archive</h2><p>" + ResourceView.escape(string) + " (" + ResourceView.human(byArray.length) + ")</p><p>Open it in a new window to browse, deobfuscate and decompile its contents.</p></html>");
        jLabel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        JButton jButton = new JButton("Open nested jar");
        jButton.addActionListener(actionEvent -> runnable.run());
        JPanel jPanel2 = new JPanel(new FlowLayout(0));
        jPanel2.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        jPanel2.add(jButton);
        jPanel.add((Component)jLabel, "North");
        jPanel.add((Component)jPanel2, "Center");
        return jPanel;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive exception aggregation
     */
    private static JComponent image(byte[] byArray) {
        try (ImageInputStream imageInputStream = ImageIO.createImageInputStream(new ByteArrayInputStream(byArray));){
            int n;
            int n2;
            ImageReader imageReader;
            block17: {
                if (imageInputStream == null) {
                    JComponent jComponent = null;
                    return jComponent;
                }
                Iterator<ImageReader> iterator = ImageIO.getImageReaders(imageInputStream);
                if (!iterator.hasNext()) {
                    JComponent jComponent = null;
                    return jComponent;
                }
                imageReader = iterator.next();
                try {
                    imageReader.setInput(imageInputStream);
                    n2 = imageReader.getWidth(0);
                    n = imageReader.getHeight(0);
                    if ((long)n2 * (long)n <= 50000000L) break block17;
                    JComponent jComponent = ResourceView.message("Image is too large to display (" + n2 + " \u00d7 " + n + ").");
                    imageReader.dispose();
                    return jComponent;
                }
                catch (Throwable throwable) {
                    imageReader.dispose();
                    throw throwable;
                }
            }
            BufferedImage bufferedImage = imageReader.read(0);
            JLabel jLabel = new JLabel(new ImageIcon(bufferedImage));
            jLabel.setHorizontalAlignment(0);
            JPanel jPanel = new JPanel(new BorderLayout());
            jPanel.add((Component)new JScrollPane(jLabel), "Center");
            JLabel jLabel2 = new JLabel(n2 + " \u00d7 " + n + " px, " + ResourceView.human(byArray.length));
            jLabel2.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
            jPanel.add((Component)jLabel2, "South");
            JPanel jPanel2 = jPanel;
            imageReader.dispose();
            return jPanel2;
        }
        catch (Exception | OutOfMemoryError throwable) {
            return null;
        }
    }

    private static JComponent text(String string, byte[] byArray) {
        int n = Math.min(byArray.length, 0x800000);
        Object object = new String(byArray, 0, n, StandardCharsets.UTF_8);
        if (n < byArray.length) {
            object = (String)object + "\n\n[\u2026 truncated, " + ResourceView.human(byArray.length) + " total]";
        }
        RSyntaxTextArea rSyntaxTextArea = Editors.create(SYNTAX.getOrDefault(ResourceView.extension(string), "text/plain"));
        rSyntaxTextArea.setText((String)object);
        rSyntaxTextArea.setCaretPosition(0);
        return Editors.scroll(rSyntaxTextArea);
    }

    private static JComponent hex(byte[] byArray) {
        int n = Math.min(byArray.length, 262144);
        StringBuilder stringBuilder = new StringBuilder((n / 16 + 1) * 80 + 64);
        StringBuilder stringBuilder2 = new StringBuilder(16);
        for (int i = 0; i < n; i += 16) {
            int n2;
            for (n2 = 28; n2 >= 0; n2 -= 4) {
                stringBuilder.append(HEX[i >>> n2 & 0xF]);
            }
            stringBuilder.append("  ");
            stringBuilder2.setLength(0);
            for (n2 = 0; n2 < 16; ++n2) {
                if (i + n2 < n) {
                    int n3 = byArray[i + n2] & 0xFF;
                    stringBuilder.append(HEX[n3 >>> 4]).append(HEX[n3 & 0xF]).append(' ');
                    stringBuilder2.append(n3 >= 32 && n3 < 127 ? (char)n3 : (char)'.');
                } else {
                    stringBuilder.append("   ");
                }
                if (n2 != 7) continue;
                stringBuilder.append(' ');
            }
            stringBuilder.append(" |").append((CharSequence)stringBuilder2).append("|\n");
        }
        if (n < byArray.length) {
            stringBuilder.append("\n[\u2026 showing first ").append(ResourceView.human(n)).append(" of ").append(ResourceView.human(byArray.length)).append("]\n");
        }
        RSyntaxTextArea rSyntaxTextArea = Editors.create("text/plain");
        rSyntaxTextArea.setText(stringBuilder.toString());
        rSyntaxTextArea.setCaretPosition(0);
        rSyntaxTextArea.setCodeFoldingEnabled(false);
        return Editors.scroll(rSyntaxTextArea);
    }

    static JComponent message(String string) {
        JLabel jLabel = new JLabel("<html>" + ResourceView.escape(string).replace("\n", "<br>") + "</html>");
        jLabel.setVerticalAlignment(1);
        jLabel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        return jLabel;
    }

    static String human(long l) {
        if (l < 1024L) {
            return l + " B";
        }
        if (l < 0x100000L) {
            return String.format("%.1f KB", (double)l / 1024.0);
        }
        return String.format("%.1f MB", (double)l / 1048576.0);
    }

    static String escape(String string) {
        return string.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}

