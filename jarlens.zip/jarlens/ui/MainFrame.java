/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.FlatLightLaf;
import dev.jarlens.core.JarLoader;
import dev.jarlens.core.JarModel;
import dev.jarlens.decompile.DecompilerService;
import dev.jarlens.deob.DeobSettings;
import dev.jarlens.deob.Deobfuscator;
import dev.jarlens.export.Exporter;
import dev.jarlens.mapping.MappingReader;
import dev.jarlens.mapping.MappingSet;
import dev.jarlens.ui.AppSettings;
import dev.jarlens.ui.CodeTab;
import dev.jarlens.ui.Editors;
import dev.jarlens.ui.FileTreePanel;
import dev.jarlens.ui.Icons;
import dev.jarlens.ui.InfoPanel;
import dev.jarlens.ui.NavIndex;
import dev.jarlens.ui.ResourceView;
import dev.jarlens.ui.SearchDialog;
import dev.jarlens.ui.Session;
import dev.jarlens.ui.SettingsDialog;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.TransferHandler;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.JTextComponent;

public final class MainFrame
extends JFrame {
    private static final List<MainFrame> WINDOWS = new ArrayList<MainFrame>();
    private static final int MENU = Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx();
    private final AppSettings settings;
    private final DecompilerService decompiler;
    private final FileTreePanel tree = new FileTreePanel();
    private final InfoPanel info = new InfoPanel();
    private final JTabbedPane tabs = new JTabbedPane();
    private final JLabel statusLabel = new JLabel(" ");
    private final JProgressBar progress = new JProgressBar();
    private final JMenu recentMenu = new JMenu("Open Recent");
    private final Deque<Location> back = new ArrayDeque<Location>();
    private final Deque<Location> forward = new ArrayDeque<Location>();
    private Session session;
    private SwingWorker<?, ?> busy;
    private final AtomicBoolean cancelRequested = new AtomicBoolean();
    private Path currentFile;
    private static final Pattern PACKAGE_LIKE = Pattern.compile("[a-z_][\\w]*(\\.[a-z_][\\w]*)*");
    private static final Pattern GENERIC_DECL = Pattern.compile("([A-Za-z_$][\\w$.]*)\\s*(?:<[^;=(){}]*>)?\\s*(?:\\[\\s*])*\\s+");

    public static void warmUpInBackground(DecompilerService decompilerService) {
        Thread thread = new Thread(() -> {
            try {
                Editors.warmUp();
                decompilerService.warmUp();
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }, "warm-up");
        thread.setDaemon(true);
        thread.setPriority(1);
        thread.start();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public MainFrame(AppSettings appSettings, DecompilerService decompilerService) {
        super("JarLens");
        this.settings = appSettings;
        this.decompiler = decompilerService;
        Editors.configure(appSettings.darkTheme, appSettings.fontSize);
        this.setIconImages(Icons.appImages());
        this.setDefaultCloseOperation(2);
        this.addWindowListener(new WindowAdapter(this){
            final /* synthetic */ MainFrame this$0;
            {
                MainFrame mainFrame2 = mainFrame;
                Objects.requireNonNull(mainFrame2);
                this.this$0 = mainFrame2;
            }

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             */
            @Override
            public void windowClosed(WindowEvent windowEvent) {
                List<MainFrame> list;
                if (this.this$0.busy != null) {
                    this.this$0.busy.cancel(true);
                }
                List<MainFrame> list2 = list = WINDOWS;
                synchronized (list2) {
                    WINDOWS.remove(this.this$0);
                }
            }
        });
        List<MainFrame> list = WINDOWS;
        Object object = list;
        synchronized (object) {
            WINDOWS.add(this);
        }
        this.tabs.putClientProperty("JTabbedPane.tabClosable", true);
        this.tabs.putClientProperty("JTabbedPane.tabCloseCallback", this.tabs::removeTabAt);
        this.tabs.putClientProperty("JTabbedPane.scrollButtonsPolicy", "asNeeded");
        this.tabs.setTabLayoutPolicy(1);
        this.tabs.addChangeListener(changeEvent -> this.updateStatusForTab());
        this.tree.onOpen(this::openItem);
        this.tree.onOpenOriginal(item -> this.openClass(item.path(), Session.Variant.ORIGINAL, null));
        this.tree.setSession(null);
        this.info.onClassLink(string -> {
            if (this.session == null) {
                return;
            }
            String string2 = this.session.currentName((String)string, Session.Variant.ORIGINAL);
            if (this.session.classes(Session.Variant.DEOBFUSCATED).containsKey(string2)) {
                this.openClass(string2, Session.Variant.DEOBFUSCATED, null);
            }
        });
        object = new JSplitPane(0, this.tree, this.info);
        ((JSplitPane)object).setResizeWeight(0.72);
        ((JComponent)object).setBorder(BorderFactory.createEmptyBorder());
        JSplitPane jSplitPane = new JSplitPane(1, (Component)object, this.tabs);
        jSplitPane.setDividerLocation(330);
        jSplitPane.setBorder(BorderFactory.createEmptyBorder());
        this.tabs.addTab("Welcome", this.welcome());
        JPanel jPanel = new JPanel(new BorderLayout(8, 0));
        jPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIManager.getColor("Component.borderColor")), BorderFactory.createEmptyBorder(3, 8, 3, 8)));
        this.progress.setVisible(false);
        this.progress.setPreferredSize(new Dimension(220, this.progress.getPreferredSize().height));
        jPanel.add((Component)this.statusLabel, "Center");
        jPanel.add((Component)this.progress, "East");
        this.getContentPane().setLayout(new BorderLayout());
        this.getContentPane().add((Component)jSplitPane, "Center");
        this.getContentPane().add((Component)jPanel, "South");
        this.setJMenuBar(this.buildMenu());
        FileDropHandler fileDropHandler = new FileDropHandler(this, null);
        this.getRootPane().setTransferHandler(fileDropHandler);
        this.tabs.setTransferHandler(fileDropHandler);
        this.info.setTransferHandler(fileDropHandler);
        this.installDropRecursively(this.tree);
        this.setSize(1360, 860);
        this.setMinimumSize(new Dimension(800, 500));
        this.setLocationByPlatform(true);
    }

    private void installDropRecursively(Component component) {
        Container container;
        if (component instanceof JComponent) {
            container = (JComponent)component;
            if (!(component instanceof JTextComponent)) {
                ((JComponent)container).setTransferHandler(new FileDropHandler(this, ((JComponent)container).getTransferHandler()));
            }
        }
        if (component instanceof Container) {
            container = (Container)component;
            for (Component component2 : container.getComponents()) {
                this.installDropRecursively(component2);
            }
        }
    }

    private JComponent welcome() {
        JLabel jLabel = new JLabel("<html><div style='text-align:center'><h1>JarLens</h1><p>Drag a <b>.jar</b> onto this window or use <b>File \u2192 Open</b>.</p><br><p>The jar is deobfuscated automatically and then decompiled class by class.</p><p>Nothing from the jar is ever executed \u2014 everything is static analysis.</p></div></html>", 0);
        jLabel.setForeground(UIManager.getColor("Label.disabledForeground"));
        return jLabel;
    }

    private JMenuBar buildMenu() {
        JMenuBar jMenuBar = new JMenuBar();
        JMenu jMenu = new JMenu("File");
        jMenu.setMnemonic('F');
        jMenu.add(MainFrame.item("Open\u2026", KeyStroke.getKeyStroke(79, MENU), actionEvent -> this.chooseAndOpen()));
        jMenu.add(this.recentMenu);
        this.rebuildRecent();
        jMenu.addSeparator();
        jMenu.add(MainFrame.item("Load Mapping File\u2026", null, actionEvent -> this.loadMapping()));
        jMenu.add(MainFrame.item("Clear Mapping", null, actionEvent -> this.clearMapping()));
        jMenu.addSeparator();
        jMenu.add(MainFrame.item("Export Cleaned Jar\u2026", KeyStroke.getKeyStroke(69, MENU | 0x40), actionEvent -> this.exportJar()));
        jMenu.add(MainFrame.item("Export Sources as ZIP\u2026", KeyStroke.getKeyStroke(83, MENU | 0x40), actionEvent -> this.exportSources()));
        jMenu.addSeparator();
        jMenu.add(MainFrame.item("Close Tab", KeyStroke.getKeyStroke(87, MENU), actionEvent -> {
            int n = this.tabs.getSelectedIndex();
            if (n >= 0) {
                this.tabs.removeTabAt(n);
            }
        }));
        jMenu.add(MainFrame.item("Close Jar", null, actionEvent -> this.closeJar()));
        jMenu.add(MainFrame.item("Exit", KeyStroke.getKeyStroke(81, MENU), actionEvent -> {
            for (MainFrame mainFrame : new ArrayList<MainFrame>(WINDOWS)) {
                mainFrame.dispose();
            }
        }));
        jMenuBar.add(jMenu);
        JMenu jMenu2 = new JMenu("Search");
        jMenu2.setMnemonic('S');
        jMenu2.add(MainFrame.item("Filter Classes", KeyStroke.getKeyStroke(78, MENU | 0x40), actionEvent -> this.tree.focusFilter()));
        jMenu2.add(MainFrame.item("Search in Code\u2026", KeyStroke.getKeyStroke(70, MENU | 0x40), actionEvent -> this.openSearch()));
        jMenu2.add(MainFrame.item("Find in File", null, actionEvent -> {
            Component component = this.tabs.getSelectedComponent();
            if (component instanceof CodeTab) {
                CodeTab codeTab = (CodeTab)component;
                codeTab.openFind();
            }
        }));
        jMenu2.addSeparator();
        jMenu2.add(MainFrame.item("Back", KeyStroke.getKeyStroke(37, 512), actionEvent -> this.goBack()));
        jMenu2.add(MainFrame.item("Forward", KeyStroke.getKeyStroke(39, 512), actionEvent -> this.goForward()));
        jMenuBar.add(jMenu2);
        JMenu jMenu3 = new JMenu("View");
        jMenu3.setMnemonic('V');
        JCheckBoxMenuItem jCheckBoxMenuItem = new JCheckBoxMenuItem("Dark Theme", this.settings.darkTheme);
        jCheckBoxMenuItem.addActionListener(actionEvent -> this.setTheme(jCheckBoxMenuItem.isSelected()));
        jMenu3.add(jCheckBoxMenuItem);
        jMenu3.add(MainFrame.item("Toggle Original / Deobfuscated", KeyStroke.getKeyStroke(84, MENU | 0x40), actionEvent -> {
            Component component = this.tabs.getSelectedComponent();
            if (component instanceof CodeTab) {
                CodeTab codeTab;
                codeTab.setVariant((codeTab = (CodeTab)component).variant() == Session.Variant.ORIGINAL ? Session.Variant.DEOBFUSCATED : Session.Variant.ORIGINAL);
                this.updateStatusForTab();
            }
        }));
        JMenu jMenu4 = new JMenu("Decompiler");
        ButtonGroup buttonGroup = new ButtonGroup();
        for (DecompilerService.Engine engine : DecompilerService.Engine.values()) {
            JRadioButtonMenuItem jRadioButtonMenuItem = new JRadioButtonMenuItem(engine.label, engine == this.settings.engine);
            jRadioButtonMenuItem.addActionListener(actionEvent -> this.setEngine(engine));
            buttonGroup.add(jRadioButtonMenuItem);
            jMenu4.add(jRadioButtonMenuItem);
        }
        jMenu3.add(jMenu4);
        jMenu3.addSeparator();
        jMenu3.add(MainFrame.item("Increase Font Size", KeyStroke.getKeyStroke(61, MENU), actionEvent -> this.setFontSize(this.settings.fontSize + 1)));
        jMenu3.add(MainFrame.item("Decrease Font Size", KeyStroke.getKeyStroke(45, MENU), actionEvent -> this.setFontSize(this.settings.fontSize - 1)));
        jMenu3.add(MainFrame.item("Reset Font Size", KeyStroke.getKeyStroke(48, MENU), actionEvent -> this.setFontSize(13)));
        jMenuBar.add(jMenu3);
        JMenu jMenu5 = new JMenu("Deobfuscation");
        jMenu5.setMnemonic('D');
        jMenu5.add(MainFrame.item("Settings\u2026", KeyStroke.getKeyStroke(44, MENU), actionEvent -> this.openSettings()));
        jMenu5.add(MainFrame.item("Re-run Deobfuscation", KeyStroke.getKeyStroke(116, 0), actionEvent -> this.rerun()));
        jMenuBar.add(jMenu5);
        JMenu jMenu6 = new JMenu("Help");
        jMenu6.add(MainFrame.item("Keyboard Shortcuts", null, actionEvent -> this.showShortcuts()));
        jMenu6.add(MainFrame.item("Safety & Limitations", null, actionEvent -> this.showSafety()));
        jMenu6.add(MainFrame.item("About JarLens", null, actionEvent -> JOptionPane.showMessageDialog(this, "<html><h2>JarLens 1.0</h2><p>Java decompiler with generic, static deobfuscation.</p><br><p>Decompilers: Vineflower, CFR \u00b7 Bytecode: ASM \u00b7 UI: FlatLaf, RSyntaxTextArea</p><p>Java " + System.getProperty("java.version") + "</p></html>", "About JarLens", 1, new ImageIcon(Icons.appImage(64)))));
        jMenuBar.add(jMenu6);
        return jMenuBar;
    }

    private static JMenuItem item(String string, KeyStroke keyStroke, final Consumer<ActionEvent> consumer) {
        JMenuItem jMenuItem = new JMenuItem(new AbstractAction(string){

            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                consumer.accept(actionEvent);
            }
        });
        if (keyStroke != null) {
            jMenuItem.setAccelerator(keyStroke);
        }
        return jMenuItem;
    }

    private void rebuildRecent() {
        this.recentMenu.removeAll();
        for (String string : this.settings.recentFiles) {
            this.recentMenu.add(MainFrame.item(string, null, actionEvent -> this.open(Path.of(string, new String[0]))));
        }
        this.recentMenu.setEnabled(!this.settings.recentFiles.isEmpty());
    }

    private void chooseAndOpen() {
        JFileChooser jFileChooser = new JFileChooser(this.currentFile != null ? this.currentFile.getParent().toFile() : null);
        jFileChooser.setDialogTitle("Open Jar");
        jFileChooser.setFileFilter(new FileNameExtensionFilter("Java archives (*.jar, *.war, *.ear, *.zip, *.jmod)", "jar", "war", "ear", "zip", "jmod"));
        if (jFileChooser.showOpenDialog(this) == 0) {
            this.open(jFileChooser.getSelectedFile().toPath());
        }
    }

    public void open(Path path) {
        if (!Files.isRegularFile(path, new LinkOption[0])) {
            this.error("Cannot open", "File not found:\n" + String.valueOf(path));
            return;
        }
        this.currentFile = path;
        this.settings.addRecent(path.toAbsolutePath().toString());
        for (MainFrame mainFrame : WINDOWS) {
            mainFrame.rebuildRecent();
        }
        this.load(path.getFileName().toString(), () -> JarLoader.load(path));
    }

    public void openNested(String string, byte[] byArray) {
        MainFrame mainFrame = new MainFrame(this.settings, this.decompiler);
        mainFrame.setLocation(this.getX() + 40, this.getY() + 40);
        mainFrame.setVisible(true);
        mainFrame.load(string, () -> JarLoader.load(string, byArray));
    }

    private void load(final String string, final Callable<JarModel> callable) {
        SwingWorker<Session, String> swingWorker;
        if (this.busy != null) {
            this.busy.cancel(true);
        }
        this.closeTabs();
        this.session = null;
        this.back.clear();
        this.forward.clear();
        this.setTitle("JarLens \u2014 " + string);
        this.tree.setSession(null);
        this.info.showMessage("Loading " + string + " \u2026");
        this.cancelRequested.set(false);
        this.startProgress("Reading " + string + " \u2026");
        final DeobSettings deobSettings = this.settings.deob.copy();
        this.busy = swingWorker = new SwingWorker<Session, String>(this){
            final /* synthetic */ MainFrame this$0;
            {
                MainFrame mainFrame2 = mainFrame;
                Objects.requireNonNull(mainFrame2);
                this.this$0 = mainFrame2;
            }

            @Override
            protected Session doInBackground() throws Exception {
                JarModel jarModel = (JarModel)callable.call();
                Session session = new Session(jarModel, this.this$0.decompiler);
                SwingUtilities.invokeLater(() -> this.this$0.info.showProgress(jarModel, deobSettings2.enabled ? "Deobfuscating\u2026" : "Preparing\u2026"));
                session.deobfuscate(deobSettings, this.this$0.progressFor());
                return session;
            }

            @Override
            protected void done() {
                this.this$0.stopProgress();
                if (this.isCancelled()) {
                    return;
                }
                try {
                    this.this$0.session = (Session)this.get();
                }
                catch (InterruptedException | CancellationException exception) {
                    return;
                }
                catch (ExecutionException executionException) {
                    Throwable throwable = executionException.getCause() != null ? executionException.getCause() : executionException;
                    this.this$0.info.showMessage("Could not open " + string + ".");
                    this.this$0.status("Failed to open " + string);
                    this.this$0.error("Cannot open " + string, MainFrame.describeFailure(throwable));
                    return;
                }
                this.this$0.showSession();
            }
        };
        swingWorker.execute();
    }

    private static String describeFailure(Throwable throwable) {
        if (throwable instanceof OutOfMemoryError) {
            return "Not enough memory to process this jar.\nStart JarLens with more memory, e.g. java -Xmx4g -jar JarLens.jar";
        }
        if (throwable instanceof StackOverflowError) {
            return "The jar is too deeply nested to analyse (stack overflow).";
        }
        String string = JarLoader.describe(throwable);
        if (throwable instanceof JarLoader.JarLoadException) {
            string = throwable.getMessage();
        }
        return string;
    }

    private void showSession() {
        Session session = this.session;
        Thread thread = new Thread(() -> session.index(Session.Variant.DEOBFUSCATED), "nav-index");
        thread.setDaemon(true);
        thread.setPriority(1);
        thread.start();
        this.tree.setSession(this.session);
        this.info.update(this.session);
        Deobfuscator.Result result = this.session.result();
        String string = result == null ? "" : (result.report().techniques().isEmpty() ? " \u00b7 no obfuscation detected" : " \u00b7 deobfuscated in " + result.report().millis() + " ms");
        this.status(this.session.model().classes().size() + " classes, " + this.session.model().resources().size() + " resources" + string);
        String string2 = this.session.model().mainClass();
        if (string2 != null) {
            String string3 = this.session.currentName(string2.replace('.', '/'), Session.Variant.ORIGINAL);
            if (this.session.classes(Session.Variant.DEOBFUSCATED).containsKey(string3)) {
                this.tree.reveal(string3);
            }
        }
        if (!this.session.model().warnings().isEmpty() && this.session.model().classes().isEmpty()) {
            this.error("Archive problems", "No class could be read from this archive. See the info panel for details.");
        }
    }

    private Deobfuscator.Progress progressFor() {
        final AtomicLong atomicLong = new AtomicLong();
        return new Deobfuscator.Progress(){
            final /* synthetic */ MainFrame this$0;
            {
                MainFrame mainFrame2 = mainFrame;
                Objects.requireNonNull(mainFrame2);
                this.this$0 = mainFrame2;
            }

            @Override
            public void update(String string, int n, int n2) {
                long l = System.nanoTime();
                if (l - atomicLong.get() < 50000000L && n != n2) {
                    return;
                }
                atomicLong.set(l);
                SwingUtilities.invokeLater(() -> {
                    this.this$0.progress.setIndeterminate(n2 <= 1);
                    this.this$0.progress.setMaximum(Math.max(1, n2));
                    this.this$0.progress.setValue(n);
                    this.this$0.statusLabel.setText(string + (String)(n2 > 1 ? "  " + n + " / " + n2 : ""));
                });
            }

            @Override
            public boolean isCancelled() {
                return this.this$0.cancelRequested.get() || Thread.currentThread().isInterrupted();
            }
        };
    }

    private void rerun() {
        SwingWorker<Void, Void> swingWorker;
        if (this.session == null) {
            return;
        }
        if (this.busy != null && !this.busy.isDone()) {
            return;
        }
        final Session session = this.session;
        Deobfuscator.Result result = session.result();
        final ArrayList<Location> arrayList = new ArrayList<Location>();
        for (int i = 0; i < this.tabs.getTabCount(); ++i) {
            Component component = this.tabs.getComponentAt(i);
            if (!(component instanceof CodeTab)) continue;
            CodeTab codeTab = (CodeTab)component;
            arrayList.add(new Location(result == null ? codeTab.className : result.originalName(codeTab.className), codeTab.variant(), codeTab.area().getCaretPosition()));
        }
        final DeobSettings deobSettings = this.settings.deob.copy();
        this.cancelRequested.set(false);
        this.startProgress("Deobfuscating\u2026");
        this.info.showProgress(session.model(), "Deobfuscating\u2026");
        this.busy = swingWorker = new SwingWorker<Void, Void>(this){
            final /* synthetic */ MainFrame this$0;
            {
                MainFrame mainFrame2 = mainFrame;
                Objects.requireNonNull(mainFrame2);
                this.this$0 = mainFrame2;
            }

            @Override
            protected Void doInBackground() {
                session.deobfuscate(deobSettings, this.this$0.progressFor());
                return null;
            }

            @Override
            protected void done() {
                this.this$0.stopProgress();
                try {
                    this.get();
                }
                catch (InterruptedException | CancellationException exception) {
                    return;
                }
                catch (ExecutionException executionException) {
                    this.this$0.error("Deobfuscation failed", MainFrame.describeFailure(executionException.getCause()));
                    return;
                }
                this.this$0.closeTabs();
                this.this$0.back.clear();
                this.this$0.forward.clear();
                this.this$0.showSession();
                for (Location location : arrayList) {
                    String string = session.currentName(location.className, Session.Variant.ORIGINAL);
                    if (!session.classes(Session.Variant.DEOBFUSCATED).containsKey(string)) continue;
                    this.this$0.openClass(string, location.variant, null);
                }
            }
        };
        swingWorker.execute();
    }

    private void closeJar() {
        if (this.busy != null) {
            this.busy.cancel(true);
        }
        this.closeTabs();
        this.session = null;
        this.tree.setSession(null);
        this.info.showMessage("No jar opened.");
        this.setTitle("JarLens");
        this.status(" ");
        this.tabs.addTab("Welcome", this.welcome());
    }

    private void closeTabs() {
        this.tabs.removeAll();
    }

    private void openItem(FileTreePanel.Item item) {
        if (this.session == null) {
            return;
        }
        switch (item.kind()) {
            case CLASS: {
                this.openClass(item.path(), Session.Variant.DEOBFUSCATED, null);
                break;
            }
            case RESOURCE: 
            case BROKEN: {
                this.openResource(item.path(), false);
                break;
            }
            case NESTED_JAR: {
                this.openResource(item.path(), true);
            }
        }
    }

    private int findTab(String string) {
        for (int i = 0; i < this.tabs.getTabCount(); ++i) {
            JComponent jComponent;
            Component component = this.tabs.getComponentAt(i);
            if (!(component instanceof JComponent) || !string.equals((jComponent = (JComponent)component).getClientProperty("jarlens.key"))) continue;
            return i;
        }
        return -1;
    }

    CodeTab openClass(String string, Session.Variant variant, Consumer<CodeTab> consumer) {
        Object object;
        CodeTab codeTab;
        if (this.session == null) {
            return null;
        }
        Map<String, byte[]> map = this.session.classes(Session.Variant.DEOBFUSCATED);
        String string2 = Session.topLevel(string, map);
        String string3 = "class:" + string2;
        int n = this.findTab(string3);
        if (n >= 0) {
            codeTab = (CodeTab)this.tabs.getComponentAt(n);
            this.tabs.setSelectedIndex(n);
            codeTab.setVariant(variant);
        } else {
            this.removeWelcome();
            codeTab = new CodeTab(this.session, string2, variant, this.settings.engine, this::navigate);
            codeTab.putClientProperty("jarlens.key", string3);
            this.tabs.addTab(codeTab.displayName(), Icons.CLASS, codeTab, string2.replace('/', '.'));
            this.tabs.setSelectedComponent(codeTab);
            this.installEditorDrop(codeTab);
        }
        this.tree.reveal(string2);
        if (!string2.equals(string)) {
            object = NavIndex.simpleName(this.session.nameIn(string, codeTab.variant()));
            codeTab.whenLoaded(() -> MainFrame.lambda$openClass$0(codeTab, (String)object));
        }
        object = codeTab;
        if (consumer != null) {
            codeTab.whenLoaded(() -> MainFrame.lambda$openClass$1(consumer, (CodeTab)object));
        }
        this.updateStatusForTab();
        return codeTab;
    }

    private void removeWelcome() {
        for (int i = this.tabs.getTabCount() - 1; i >= 0; --i) {
            if (!(this.tabs.getComponentAt(i) instanceof JLabel)) continue;
            this.tabs.removeTabAt(i);
        }
    }

    private void installEditorDrop(CodeTab codeTab) {
        codeTab.area().setTransferHandler(new FileDropHandler(this, codeTab.area().getTransferHandler()));
    }

    private void openResource(String string, boolean bl) {
        JComponent jComponent;
        byte[] byArray = this.session.model().resources().get(string);
        if (byArray == null) {
            return;
        }
        if (bl) {
            this.openNested(string.substring(string.lastIndexOf(47) + 1), byArray);
            return;
        }
        String string2 = "res:" + string;
        int n = this.findTab(string2);
        if (n >= 0) {
            this.tabs.setSelectedIndex(n);
            return;
        }
        this.removeWelcome();
        JarModel.BrokenClass brokenClass2 = this.session.model().brokenClasses().stream().filter(brokenClass -> brokenClass.entryPath().equals(string)).findFirst().orElse(null);
        if (brokenClass2 != null) {
            jComponent = new JPanel(new BorderLayout());
            jComponent.add((Component)ResourceView.message("This class file could not be parsed (" + brokenClass2.error() + ").\nIt may be deliberately corrupted. Its raw bytes are shown below."), "North");
            jComponent.add((Component)ResourceView.create(string + ".bin", byArray, null), "Center");
        } else {
            jComponent = ResourceView.create(string, byArray, null);
        }
        jComponent.putClientProperty("jarlens.key", string2);
        String string3 = string.substring(string.lastIndexOf(47) + 1);
        this.tabs.addTab(string3, brokenClass2 != null ? Icons.BROKEN : (ResourceView.isImage(string) ? Icons.IMAGE : Icons.TEXT), jComponent, string);
        this.tabs.setSelectedComponent(jComponent);
    }

    private void updateStatusForTab() {
        Component component = this.tabs.getSelectedComponent();
        if (component instanceof CodeTab) {
            CodeTab codeTab = (CodeTab)component;
            this.setTitle("JarLens \u2014 " + this.session.model().displayName() + " \u2014 " + codeTab.shownClassName().replace('/', '.'));
        } else if (this.session != null) {
            this.setTitle("JarLens \u2014 " + this.session.model().displayName());
        }
    }

    private void setEngine(DecompilerService.Engine engine) {
        this.settings.engine = engine;
        this.settings.save();
        for (int i = 0; i < this.tabs.getTabCount(); ++i) {
            Component component = this.tabs.getComponentAt(i);
            if (!(component instanceof CodeTab)) continue;
            CodeTab codeTab = (CodeTab)component;
            codeTab.setEngine(engine);
        }
    }

    private void navigate(CodeTab codeTab, String string, String string2, int n) {
        Set<String> set;
        Object object;
        int n2;
        Object object2;
        if (this.session == null) {
            return;
        }
        Session.Variant variant = codeTab.variant();
        NavIndex navIndex = this.session.index(variant);
        String string3 = codeTab.shownClassName();
        String string4 = codeTab.source();
        Location location = new Location(codeTab.className, variant, n);
        String string5 = null;
        if (string2 == null) {
            string5 = navIndex.resolveClass(string, string3, string4);
        } else if (PACKAGE_LIKE.matcher(string2).matches() && !MainFrame.isVariable(string4, string2)) {
            string5 = navIndex.resolveClass(string2 + "." + string, string3, string4);
        } else if (Character.isUpperCase(string.charAt(0))) {
            string5 = navIndex.resolveClass(string2 + "." + string, string3, string4);
        }
        if (!(string5 == null || string2 == null && MainFrame.declaresMember(navIndex, string3, string) && MainFrame.isCallOrField(string4, n, string))) {
            this.pushBack(location);
            this.openInVariant(string5, variant, null);
            return;
        }
        String string6 = null;
        if (string2 == null || string2.equals("this") || string2.equals("super")) {
            string6 = string3;
        } else if (!string2.equals("()")) {
            object2 = string2;
            n2 = ((String)object2).lastIndexOf(46);
            object = n2 >= 0 ? ((String)object2).substring(n2 + 1) : object2;
            string6 = navIndex.resolveClass((String)object2, string3, string4);
            if (string6 == null && (set = MainFrame.typeOfVariable(string4, (String)object, n)) != null) {
                string6 = navIndex.resolveClass((String)((Object)set), string3, string4);
            }
        }
        if (string6 != null) {
            set = navIndex.declaringClass(string6, string);
            if (set == null && string6.equals(string3) && codeTab.goToMember(string)) {
                this.pushBack(location);
                return;
            }
            if (set != null) {
                this.pushBack(location);
                this.openInVariant((String)((Object)set), variant, string);
                return;
            }
        }
        if (string2 == null && codeTab.goToMember(string)) {
            this.pushBack(location);
            return;
        }
        set = navIndex.ownersOf(string);
        if (set.size() == 1) {
            this.pushBack(location);
            this.openInVariant((String)set.iterator().next(), variant, string);
        } else if (set.size() > 1) {
            object2 = new JPopupMenu();
            n2 = 0;
            for (String string7 : set) {
                if (n2++ >= 40) {
                    ((JPopupMenu)object2).add(new JMenuItem("\u2026 " + (set.size() - 40) + " more")).setEnabled(false);
                    break;
                }
                ((JPopupMenu)object2).add(MainFrame.item(string7.replace('/', '.') + "." + string, null, actionEvent -> {
                    this.pushBack(location);
                    this.openInVariant(string7, variant, string);
                }));
            }
            object = MainFrame.caretPoint(codeTab);
            ((JPopupMenu)object2).show(codeTab.area(), ((Point)object).x, ((Point)object).y);
        } else {
            this.status("Cannot resolve '" + string + "' \u2014 it is probably part of the JDK or a library not in this jar.");
        }
    }

    private static boolean declaresMember(NavIndex navIndex, String string, String string2) {
        return navIndex.declaringClass(string, string2) != null;
    }

    private static boolean isCallOrField(String string, int n, String string2) {
        int n2;
        int n3;
        for (n3 = n2 = n + string2.length(); n3 < string.length() && Character.isWhitespace(string.charAt(n3)); ++n3) {
        }
        return n3 < string.length() && string.charAt(n3) == '(';
    }

    private static boolean isVariable(String string, String string2) {
        return Pattern.compile("[\\w>\\]]\\s+" + Pattern.quote(string2) + "\\s*[=;,):]").matcher(string).find();
    }

    static String typeOfVariable(String string, String string2, int n) {
        Pattern pattern = Pattern.compile(GENERIC_DECL.pattern() + Pattern.quote(string2) + "\\s*[=;,):]");
        Matcher matcher = pattern.matcher(string);
        String string3 = null;
        String string4 = null;
        while (matcher.find()) {
            String string5 = matcher.group(1);
            if (Set.of("return", "new", "throw", "else", "case", "instanceof", "package", "import").contains(string5)) continue;
            if (string4 == null) {
                string4 = string5;
            }
            if (matcher.start() > n) break;
            string3 = string5;
        }
        return string3 != null ? string3 : string4;
    }

    private void openInVariant(String string, Session.Variant variant, String string2) {
        String string3 = this.session.currentName(string, variant);
        if (!this.session.classes(Session.Variant.DEOBFUSCATED).containsKey(string3)) {
            this.status("Class not found: " + string.replace('/', '.'));
            return;
        }
        this.openClass(string3, variant, codeTab -> {
            if (string2 == null) {
                MainFrame.goToTypeDeclaration(codeTab, NavIndex.simpleName(string));
            } else if (!codeTab.goToMember(string2)) {
                this.status("Declaration of '" + string2 + "' not found in the decompiled source");
            }
        });
    }

    private static void goToTypeDeclaration(CodeTab codeTab, String string) {
        Matcher matcher = Pattern.compile("\\b(?:class|interface|enum|record)\\s+(" + Pattern.quote(string) + ")\\b").matcher(codeTab.source());
        if (matcher.find()) {
            codeTab.select(matcher.start(1), matcher.end(1));
        }
    }

    private static Point caretPoint(CodeTab codeTab) {
        try {
            Rectangle2D rectangle2D = codeTab.area().modelToView2D(codeTab.area().getCaretPosition());
            if (rectangle2D != null) {
                return new Point((int)rectangle2D.getX(), (int)(rectangle2D.getY() + rectangle2D.getHeight()));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return new Point(40, 40);
    }

    private void pushBack(Location location) {
        this.back.push(location);
        while (this.back.size() > 100) {
            this.back.removeLast();
        }
        this.forward.clear();
    }

    private Location currentLocation() {
        Component component = this.tabs.getSelectedComponent();
        if (component instanceof CodeTab) {
            CodeTab codeTab = (CodeTab)component;
            return new Location(codeTab.className, codeTab.variant(), codeTab.area().getCaretPosition());
        }
        return null;
    }

    private void goBack() {
        if (this.back.isEmpty()) {
            return;
        }
        Location location = this.currentLocation();
        if (location != null) {
            this.forward.push(location);
        }
        this.restore(this.back.pop());
    }

    private void goForward() {
        if (this.forward.isEmpty()) {
            return;
        }
        Location location = this.currentLocation();
        if (location != null) {
            this.back.push(location);
        }
        this.restore(this.forward.pop());
    }

    private void restore(Location location) {
        if (this.session == null) {
            return;
        }
        this.openClass(location.className, location.variant, codeTab -> {
            int n = Math.min(location.caret, codeTab.area().getDocument().getLength());
            codeTab.select(n, n);
        });
    }

    private void openSearch() {
        String string;
        CodeTab codeTab;
        if (this.session == null) {
            this.status("Open a jar first.");
            return;
        }
        SearchDialog searchDialog = new SearchDialog(this, this.session, this.settings.engine, hit -> this.openClass(hit.className(), Session.Variant.DEOBFUSCATED, codeTab -> {
            if (hit.line() >= 0) {
                codeTab.goToLine(hit.line(), hit.match());
            } else if (hit.match() != null) {
                int n = codeTab.source().indexOf(hit.match());
                if (n >= 0) {
                    codeTab.select(n, n + hit.match().length());
                } else {
                    codeTab.goToMember(hit.match());
                }
            } else {
                String string = hit.text();
                int n = string.startsWith("\"") ? codeTab.source().indexOf(string) : -1;
                int n2 = n;
                if (n >= 0) {
                    codeTab.select(n, n + string.length());
                }
            }
        }));
        Component component = this.tabs.getSelectedComponent();
        if (component instanceof CodeTab) {
            codeTab = (CodeTab)component;
            string = codeTab.area().getSelectedText();
        } else {
            string = null;
        }
        codeTab = string;
        searchDialog.prefill((String)((Object)codeTab));
        searchDialog.setVisible(true);
    }

    private void loadMapping() {
        if (this.session == null) {
            this.status("Open a jar first, then load its mapping file.");
            return;
        }
        JFileChooser jFileChooser = new JFileChooser(this.currentFile != null ? this.currentFile.getParent().toFile() : null);
        jFileChooser.setDialogTitle("Load Mapping (ProGuard, Tiny v1/v2, Enigma)");
        jFileChooser.setFileFilter(new FileNameExtensionFilter("Mapping files (*.txt, *.map, *.tiny, *.mapping, *.mappings)", "txt", "map", "tiny", "mapping", "mappings", "pro", "srg"));
        jFileChooser.setAcceptAllFileFilterUsed(true);
        if (jFileChooser.showOpenDialog(this) != 0) {
            return;
        }
        Path path = jFileChooser.getSelectedFile().toPath();
        try {
            MappingSet mappingSet = MappingReader.read(path);
            this.session.mapping(mappingSet);
            this.status("Loaded " + mappingSet.format() + " mapping: " + mappingSet.classCount() + " classes, " + mappingSet.methodCount() + " methods, " + mappingSet.fieldCount() + " fields");
            this.rerun();
        }
        catch (Exception exception) {
            this.error("Cannot load mapping", JarLoader.describe(exception));
        }
    }

    private void clearMapping() {
        if (this.session == null || this.session.mapping() == null) {
            return;
        }
        this.session.mapping(null);
        this.rerun();
    }

    private void openSettings() {
        new SettingsDialog(this, this.settings, this.session != null, bl -> {
            for (int i = 0; i < this.tabs.getTabCount(); ++i) {
                Component component = this.tabs.getComponentAt(i);
                if (!(component instanceof CodeTab)) continue;
                CodeTab codeTab = (CodeTab)component;
                codeTab.setEngine(this.settings.engine);
            }
            if (bl.booleanValue()) {
                this.rerun();
            }
        }).setVisible(true);
    }

    private void exportJar() {
        if (this.session == null || this.session.result() == null) {
            this.status("Open a jar first.");
            return;
        }
        String string = MainFrame.stripExtension(this.session.model().displayName());
        final Path path = this.chooseSave("Export Cleaned Jar", string + "-deobf.jar", "jar");
        if (path == null) {
            return;
        }
        final Session session = this.session;
        this.startProgress("Writing " + String.valueOf(path.getFileName()) + " \u2026");
        new SwingWorker<Void, Void>(this){
            final /* synthetic */ MainFrame this$0;
            {
                MainFrame mainFrame2 = mainFrame;
                Objects.requireNonNull(mainFrame2);
                this.this$0 = mainFrame2;
            }

            @Override
            protected Void doInBackground() throws Exception {
                Deobfuscator.Result result = session.result();
                Exporter.exportCleanJar(session.model(), result.classes(), string -> result.originalToNew().get(string), path);
                return null;
            }

            @Override
            protected void done() {
                this.this$0.stopProgress();
                try {
                    this.get();
                    this.this$0.status("Saved " + String.valueOf(path));
                    JOptionPane.showMessageDialog(this.this$0, "Cleaned jar saved to\n" + String.valueOf(path) + "\n\nIt can be opened in Luyten, Recaf or any other decompiler.", "Export complete", 1);
                }
                catch (Exception exception) {
                    this.this$0.error("Export failed", MainFrame.describeFailure(exception.getCause() != null ? exception.getCause() : exception));
                }
            }
        }.execute();
    }

    private void exportSources() {
        if (this.session == null || this.session.result() == null) {
            this.status("Open a jar first.");
            return;
        }
        String string = MainFrame.stripExtension(this.session.model().displayName());
        final Path path = this.chooseSave("Export Sources", string + "-sources.zip", "zip");
        if (path == null) {
            return;
        }
        final Session session = this.session;
        final DecompilerService.Engine engine = this.settings.engine;
        Map<String, byte[]> map = session.classes(Session.Variant.DEOBFUSCATED);
        final ArrayList<String> arrayList = new ArrayList<String>();
        for (String object2 : map.keySet()) {
            if (!Session.topLevel(object2, map).equals(object2)) continue;
            arrayList.add(object2);
        }
        final JDialog jDialog = new JDialog(this, "Exporting sources", false);
        final JProgressBar jProgressBar = new JProgressBar(0, Math.max(1, arrayList.size()));
        jProgressBar.setStringPainted(true);
        final JLabel jLabel = new JLabel(" ");
        JButton jButton = new JButton("Cancel");
        final AtomicBoolean atomicBoolean = new AtomicBoolean();
        jButton.addActionListener(actionEvent -> atomicBoolean.set(true));
        JPanel jPanel = new JPanel(new BorderLayout(8, 8));
        jPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        jPanel.add((Component)new JLabel("Decompiling " + arrayList.size() + " classes to " + String.valueOf(path.getFileName())), "North");
        jPanel.add((Component)jProgressBar, "Center");
        JPanel jPanel2 = new JPanel(new BorderLayout(8, 0));
        jPanel2.add((Component)jLabel, "Center");
        jPanel2.add((Component)jButton, "East");
        jPanel.add((Component)jPanel2, "South");
        jDialog.setContentPane(jPanel);
        jDialog.setSize(520, 150);
        jDialog.setLocationRelativeTo(this);
        jDialog.setDefaultCloseOperation(0);
        jDialog.setVisible(true);
        final int n = Math.max(1, Runtime.getRuntime().availableProcessors() - 1);
        new SwingWorker<Integer, Void>(this){
            final /* synthetic */ MainFrame this$0;
            {
                MainFrame mainFrame2 = mainFrame;
                Objects.requireNonNull(mainFrame2);
                this.this$0 = mainFrame2;
            }

            @Override
            protected Integer doInBackground() throws Exception {
                return Exporter.exportSources(session.model(), arrayList, string -> session.decompile((String)string, Session.Variant.DEOBFUSCATED, engine, false).source(), true, path, n, (n, n2, string) -> SwingUtilities.invokeLater(() -> {
                    jProgressBar.setValue(n);
                    jLabel.setText(string.replace('/', '.'));
                }), atomicBoolean::get);
            }

            @Override
            protected void done() {
                jDialog.dispose();
                try {
                    int n2 = (Integer)this.get();
                    this.this$0.status("Exported " + n2 + " classes to " + String.valueOf(path));
                    JOptionPane.showMessageDialog(this.this$0, "Exported " + n2 + " decompiled classes to\n" + String.valueOf(path), "Export complete", 1);
                }
                catch (ExecutionException executionException) {
                    if (executionException.getCause() instanceof CancellationException) {
                        this.this$0.status("Export cancelled");
                    } else {
                        this.this$0.error("Export failed", MainFrame.describeFailure(executionException.getCause()));
                    }
                }
                catch (InterruptedException | CancellationException exception) {
                    this.this$0.status("Export cancelled");
                }
            }
        }.execute();
    }

    private Path chooseSave(String string, String string2, String string3) {
        JFileChooser jFileChooser = new JFileChooser(this.currentFile != null ? this.currentFile.getParent().toFile() : null);
        jFileChooser.setDialogTitle(string);
        jFileChooser.setSelectedFile(new File(jFileChooser.getCurrentDirectory(), string2));
        jFileChooser.setFileFilter(new FileNameExtensionFilter("*." + string3, string3));
        if (jFileChooser.showSaveDialog(this) != 0) {
            return null;
        }
        Path path = jFileChooser.getSelectedFile().toPath();
        if (!path.getFileName().toString().toLowerCase().endsWith("." + string3)) {
            path = path.resolveSibling(String.valueOf(path.getFileName()) + "." + string3);
        }
        if (this.currentFile != null && path.toAbsolutePath().equals(this.currentFile.toAbsolutePath())) {
            this.error("Export", "Choose a different file; the opened jar cannot be overwritten.");
            return null;
        }
        if (Files.exists(path, new LinkOption[0]) && JOptionPane.showConfirmDialog(this, String.valueOf(path.getFileName()) + " already exists. Replace it?", string, 0) != 0) {
            return null;
        }
        return path;
    }

    private static String stripExtension(String string) {
        int n = string.lastIndexOf(46);
        return n > 0 ? string.substring(0, n) : string;
    }

    private void setTheme(boolean bl) {
        this.settings.darkTheme = bl;
        this.settings.save();
        if (bl) {
            FlatDarkLaf.setup();
        } else {
            FlatLightLaf.setup();
        }
        FlatLaf.updateUI();
        Editors.configure(bl, this.settings.fontSize);
        for (MainFrame mainFrame : WINDOWS) {
            if (mainFrame.session != null) {
                mainFrame.info.update(mainFrame.session);
            }
            mainFrame.tree.rebuild();
        }
    }

    private void setFontSize(int n) {
        this.settings.fontSize = Math.max(8, Math.min(40, n));
        this.settings.save();
        Editors.configure(this.settings.darkTheme, this.settings.fontSize);
    }

    private void showShortcuts() {
        String string = Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx() == 256 ? "\u2318" : "Ctrl+";
        JOptionPane.showMessageDialog(this, "<html><table cellpadding=2>" + MainFrame.row(string + "O", "Open jar") + MainFrame.row(string + "Shift+N", "Filter classes in the tree") + MainFrame.row(string + "Shift+F", "Search in code / strings / names") + MainFrame.row(string + "F", "Find in current file") + MainFrame.row(string + "click", "Go to declaration of a class, method or field") + MainFrame.row("Alt+\u2190 / Alt+\u2192", "Navigate back / forward") + MainFrame.row(string + "Shift+T", "Toggle original / deobfuscated") + MainFrame.row(string + "W", "Close tab") + MainFrame.row("F5", "Re-run deobfuscation") + MainFrame.row(string + ",", "Deobfuscation settings") + MainFrame.row(string + "Shift+E", "Export cleaned jar") + MainFrame.row(string + "Shift+S", "Export sources as ZIP") + MainFrame.row(string + "+ / " + string + "\u2212", "Font size") + "</table></html>", "Keyboard Shortcuts", -1);
    }

    private static String row(String string, String string2) {
        return "<tr><td><b>" + string + "</b></td><td>" + string2 + "</td></tr>";
    }

    private void showSafety() {
        JOptionPane.showMessageDialog(this, "<html><body style='width:420px'><h3>Static analysis only</h3><p>JarLens never executes code from an opened jar: no class loader is created for it, no static initializer runs, and no reflection is used on its classes. String decryption and invokedynamic resolution use a small built-in bytecode <i>emulator</i> with an instruction limit, a time limit and an allowlist of pure JDK methods (strings, numbers, arrays, Base64, javax.crypto). Class objects and method handles inside the emulator are symbolic names only.</p><h3>Limitations</h3><ul><li>Strings whose decryption depends on runtime context (stack traces, class loaders, files, network, native code) stay encrypted.</li><li>Control-flow flattening and virtualization obfuscators are only partially undone.</li><li>Opaque predicates are removed when the condition is provably constant; arithmetic tricks that need algebra are not.</li><li>Names restored by renaming are generated (class_001 \u2026) unless a mapping file is loaded.</li></ul></body></html>", "Safety & Limitations", 1);
    }

    private void status(String string) {
        this.statusLabel.setText(string);
    }

    private void startProgress(String string) {
        this.status(string);
        this.progress.setVisible(true);
        this.progress.setIndeterminate(true);
    }

    private void stopProgress() {
        this.progress.setVisible(false);
        this.progress.setIndeterminate(false);
    }

    private void error(String string, String string2) {
        JOptionPane.showMessageDialog(this, string2, string, 0);
    }

    private static /* synthetic */ void lambda$openClass$1(Consumer consumer, CodeTab codeTab) {
        consumer.accept(codeTab);
    }

    private static /* synthetic */ void lambda$openClass$0(CodeTab codeTab, String string) {
        MainFrame.goToTypeDeclaration(codeTab, string);
    }

    private final class FileDropHandler
    extends TransferHandler {
        private final TransferHandler delegate;
        final /* synthetic */ MainFrame this$0;

        FileDropHandler(MainFrame mainFrame, TransferHandler transferHandler) {
            MainFrame mainFrame2 = mainFrame;
            Objects.requireNonNull(mainFrame2);
            this.this$0 = mainFrame2;
            this.delegate = transferHandler;
        }

        @Override
        public boolean canImport(TransferHandler.TransferSupport transferSupport) {
            if (transferSupport.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                return true;
            }
            return this.delegate != null && this.delegate.canImport(transferSupport);
        }

        @Override
        public boolean importData(TransferHandler.TransferSupport transferSupport) {
            if (transferSupport.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                try {
                    List list = (List)transferSupport.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                    if (list.isEmpty()) {
                        return false;
                    }
                    File file = (File)list.get(0);
                    SwingUtilities.invokeLater(() -> this.this$0.open(file.toPath()));
                    return true;
                }
                catch (Exception exception) {
                    return false;
                }
            }
            return this.delegate != null && this.delegate.importData(transferSupport);
        }

        @Override
        public int getSourceActions(JComponent jComponent) {
            return this.delegate != null ? this.delegate.getSourceActions(jComponent) : 0;
        }

        @Override
        public void exportToClipboard(JComponent jComponent, Clipboard clipboard, int n) {
            if (this.delegate != null) {
                this.delegate.exportToClipboard(jComponent, clipboard, n);
            }
        }

        @Override
        public void exportAsDrag(JComponent jComponent, InputEvent inputEvent, int n) {
            if (this.delegate != null) {
                this.delegate.exportAsDrag(jComponent, inputEvent, n);
            }
        }
    }

    private record Location(String className, Session.Variant variant, int caret) {
    }
}

