/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Icon;
import javax.swing.UIManager;

final class Icons {
    static final Icon CLASS = new Badge("C", new Color(4033497));
    static final Icon INTERFACE = new Badge("I", new Color(4891482));
    static final Icon ENUM = new Badge("E", new Color(13206827));
    static final Icon ANNOTATION = new Badge("@", new Color(10250974));
    static final Icon RECORD = new Badge("R", new Color(2793880));
    static final Icon ABSTRACT = new Badge("A", new Color(6193062));
    static final Icon BROKEN = new Badge("!", new Color(14042437));
    static final Icon JAR = new Badge("J", new Color(11887901));
    static final Icon IMAGE = new Badge("\u25a3", new Color(8162201));
    static final Icon TEXT = new Badge("T", new Color(8162201));
    static final Icon BINARY = new Badge("B", new Color(0x6E6E6E));

    private Icons() {
    }

    static Icon folder(boolean bl) {
        Icon icon = UIManager.getIcon(bl ? "Tree.openIcon" : "Tree.closedIcon");
        return icon != null ? icon : TEXT;
    }

    private static int scaled(int n) {
        Font font = UIManager.getFont("Tree.font");
        if (font == null) {
            return n;
        }
        return Math.max(n, Math.round((float)n * font.getSize2D() / 13.0f));
    }

    static BufferedImage appImage(int n) {
        BufferedImage bufferedImage = new BufferedImage(n, n, 2);
        Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        float f = n;
        graphics2D.setPaint(new GradientPaint(0.0f, 0.0f, new Color(2840694), f, f, new Color(5129078)));
        graphics2D.fill(new RoundRectangle2D.Float(0.0f, 0.0f, f, f, f * 0.28f, f * 0.28f));
        graphics2D.setColor(new Color(255, 255, 255, 60));
        graphics2D.fill(new RoundRectangle2D.Float(f * 0.18f, f * 0.3f, f * 0.42f, f * 0.52f, f * 0.12f, f * 0.12f));
        graphics2D.fill(new RoundRectangle2D.Float(f * 0.24f, f * 0.2f, f * 0.3f, f * 0.1f, f * 0.05f, f * 0.05f));
        float f2 = f * 0.24f;
        float f3 = f * 0.56f;
        float f4 = f * 0.46f;
        graphics2D.setColor(new Color(10217471));
        graphics2D.fill(new Ellipse2D.Float(f3 - f2, f4 - f2, 2.0f * f2, 2.0f * f2));
        graphics2D.setColor(Color.WHITE);
        graphics2D.setStroke(new BasicStroke(Math.max(1.5f, f * 0.07f), 1, 1));
        graphics2D.draw(new Ellipse2D.Float(f3 - f2, f4 - f2, 2.0f * f2, 2.0f * f2));
        graphics2D.setStroke(new BasicStroke(Math.max(2.0f, f * 0.1f), 1, 1));
        graphics2D.draw(new Line2D.Float(f3 + f2 * 0.72f, f4 + f2 * 0.72f, f * 0.86f, f * 0.86f));
        if (n >= 24) {
            graphics2D.setColor(new Color(1784407));
            graphics2D.setFont(new Font("Monospaced", 1, Math.round(f2 * 1.1f)));
            FontMetrics fontMetrics = graphics2D.getFontMetrics();
            String string = "{}";
            graphics2D.drawString(string, f3 - (float)fontMetrics.stringWidth(string) / 2.0f, f4 + (float)fontMetrics.getAscent() / 2.8f);
        }
        graphics2D.dispose();
        return bufferedImage;
    }

    static List<Image> appImages() {
        ArrayList<Image> arrayList = new ArrayList<Image>();
        for (int n : new int[]{16, 20, 24, 32, 40, 48, 64, 128, 256}) {
            arrayList.add(Icons.appImage(n));
        }
        return arrayList;
    }

    private static final class Badge
    implements Icon {
        private final String letter;
        private final Color color;

        Badge(String string, Color color) {
            this.letter = string;
            this.color = color;
        }

        @Override
        public void paintIcon(Component component, Graphics graphics, int n, int n2) {
            Graphics2D graphics2D = (Graphics2D)graphics.create();
            graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int n3 = this.getIconWidth();
            graphics2D.setColor(this.color);
            graphics2D.fill(new Ellipse2D.Float(n + 1, n2 + 1, n3 - 2, n3 - 2));
            graphics2D.setColor(Color.WHITE);
            graphics2D.setFont(new Font("SansSerif", 1, Math.round((float)n3 * 0.62f)));
            FontMetrics fontMetrics = graphics2D.getFontMetrics();
            int n4 = n + (n3 - fontMetrics.stringWidth(this.letter)) / 2;
            int n5 = n2 + (n3 - fontMetrics.getHeight()) / 2 + fontMetrics.getAscent();
            graphics2D.drawString(this.letter, n4, n5);
            graphics2D.dispose();
        }

        @Override
        public int getIconWidth() {
            return Icons.scaled(16);
        }

        @Override
        public int getIconHeight() {
            return Icons.scaled(16);
        }
    }
}

