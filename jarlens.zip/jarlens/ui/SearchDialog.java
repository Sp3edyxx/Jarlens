/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import dev.jarlens.decompile.DecompilerService;
import dev.jarlens.ui.ResourceView;
import dev.jarlens.ui.Session;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingWorker;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Handle;
import org.objectweb.asm.MethodVisitor;

final class SearchDialog
extends JDialog {
    private static final int MAX_HITS = 5000;
    private final Session session;
    private final DecompilerService.Engine engine;
    private final OpenHandler handler;
    private final JTextField query = new JTextField(30);
    private final JCheckBox matchCase = new JCheckBox("Match case");
    private final JCheckBox regex = new JCheckBox("Regex");
    private final JComboBox<Scope> scope = new JComboBox<Scope>(Scope.values());
    private final JButton go = new JButton("Search");
    private final JProgressBar progress = new JProgressBar();
    private final JLabel status = new JLabel(" ");
    private final DefaultListModel<Hit> results = new DefaultListModel();
    private final JList<Hit> list = new JList<Hit>(this.results);
    private SwingWorker<Void, Hit> worker;

    SearchDialog(JFrame jFrame, Session session, DecompilerService.Engine engine, OpenHandler openHandler) {
        super(jFrame, "Search in " + session.model().displayName(), false);
        this.session = session;
        this.engine = engine;
        this.handler = openHandler;
        this.query.putClientProperty("JTextField.placeholderText", "Text to find in the code");
        JPanel jPanel = new JPanel(new BorderLayout(6, 6));
        jPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 4, 8));
        jPanel.add((Component)this.query, "Center");
        jPanel.add((Component)this.go, "East");
        JPanel jPanel2 = new JPanel(new FlowLayout(0, 6, 0));
        jPanel2.add(new JLabel("In:"));
        jPanel2.add(this.scope);
        jPanel2.add(this.matchCase);
        jPanel2.add(this.regex);
        jPanel.add((Component)jPanel2, "South");
        this.list.setSelectionMode(0);
        this.list.setCellRenderer(new DefaultListCellRenderer(this){
            final /* synthetic */ SearchDialog this$0;
            {
                SearchDialog searchDialog2 = searchDialog;
                Objects.requireNonNull(searchDialog2);
                this.this$0 = searchDialog2;
            }

            @Override
            public Component getListCellRendererComponent(JList<?> jList, Object object, int n, boolean bl, boolean bl2) {
                super.getListCellRendererComponent(jList, object, n, bl, bl2);
                if (object instanceof Hit) {
                    Hit hit = (Hit)object;
                    String string = hit.className.replace('/', '.');
                    String string2 = hit.line >= 0 ? ":" + (hit.line + 1) : "";
                    this.setText("<html><b>" + ResourceView.escape(string) + string2 + "</b>&nbsp;&nbsp;<span style='font-family:monospace'>" + ResourceView.escape(SearchDialog.abbreviate(hit.text)) + "</span></html>");
                }
                return this;
            }
        });
        this.list.addMouseListener(new MouseAdapter(this){
            final /* synthetic */ SearchDialog this$0;
            {
                SearchDialog searchDialog2 = searchDialog;
                Objects.requireNonNull(searchDialog2);
                this.this$0 = searchDialog2;
            }

            @Override
            public void mouseClicked(MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    this.this$0.openSelected();
                }
            }
        });
        this.list.registerKeyboardAction(actionEvent -> this.openSelected(), KeyStroke.getKeyStroke(10, 0), 0);
        JPanel jPanel3 = new JPanel(new BorderLayout(6, 0));
        jPanel3.setBorder(BorderFactory.createEmptyBorder(4, 8, 8, 8));
        this.progress.setVisible(false);
        jPanel3.add((Component)this.status, "Center");
        jPanel3.add((Component)this.progress, "East");
        this.go.addActionListener(actionEvent -> {
            if (this.worker != null && !this.worker.isDone()) {
                this.worker.cancel(true);
            } else {
                this.start();
            }
        });
        this.query.addActionListener(actionEvent -> this.start());
        this.getRootPane().registerKeyboardAction(actionEvent -> this.dispose(), KeyStroke.getKeyStroke(27, 0), 2);
        this.setLayout(new BorderLayout());
        this.add((Component)jPanel, "North");
        JScrollPane jScrollPane = new JScrollPane(this.list);
        jScrollPane.setPreferredSize(new Dimension(760, 420));
        this.add((Component)jScrollPane, "Center");
        this.add((Component)jPanel3, "South");
        this.pack();
        this.setLocationRelativeTo(jFrame);
    }

    void prefill(String string) {
        if (string != null && !string.isBlank() && !string.contains("\n")) {
            this.query.setText(string.trim());
        }
        this.query.requestFocusInWindow();
        this.query.selectAll();
    }

    @Override
    public void dispose() {
        if (this.worker != null) {
            this.worker.cancel(true);
        }
        super.dispose();
    }

    private void openSelected() {
        Hit hit = this.list.getSelectedValue();
        if (hit != null) {
            this.handler.open(hit);
        }
    }

    private static String abbreviate(String string) {
        String string2 = string.strip();
        return string2.length() > 160 ? string2.substring(0, 157) + "\u2026" : string2;
    }

    private void start() {
        Pattern pattern;
        String string = this.query.getText();
        if (string.isEmpty()) {
            return;
        }
        try {
            int n = this.matchCase.isSelected() ? 0 : 66;
            pattern = Pattern.compile(this.regex.isSelected() ? string : Pattern.quote(string), n);
        }
        catch (PatternSyntaxException patternSyntaxException) {
            this.status.setText("Invalid regular expression: " + patternSyntaxException.getDescription());
            return;
        }
        if (this.worker != null) {
            this.worker.cancel(true);
        }
        this.results.clear();
        final Scope scope = (Scope)((Object)this.scope.getSelectedItem());
        final Map<String, byte[]> map = this.session.classes(Session.Variant.DEOBFUSCATED);
        final ArrayList<String> arrayList = new ArrayList<String>();
        for (String string2 : map.keySet()) {
            if (scope == Scope.CODE && !Session.topLevel(string2, map).equals(string2)) continue;
            arrayList.add(string2);
        }
        this.progress.setVisible(true);
        this.progress.setMaximum(Math.max(1, arrayList.size()));
        this.progress.setValue(0);
        this.go.setText("Stop");
        this.status.setText(scope == Scope.CODE ? "Decompiling and searching (results appear as they are found)\u2026" : "Searching\u2026");
        this.worker = new SwingWorker<Void, Hit>(this){
            int count;
            int done;
            final /* synthetic */ SearchDialog this$0;
            {
                SearchDialog searchDialog2 = searchDialog;
                Objects.requireNonNull(searchDialog2);
                this.this$0 = searchDialog2;
            }

            @Override
            protected Void doInBackground() throws Exception {
                if (scope == Scope.CODE) {
                    this.searchCode(arrayList);
                } else {
                    for (String string : arrayList) {
                        if (this.isCancelled() || this.count >= 5000) break;
                        if (scope == Scope.STRINGS) {
                            this.searchStrings(string, (byte[])map.get(string));
                        } else {
                            this.searchNames(string, (byte[])map.get(string));
                        }
                        ++this.done;
                        this.setProgress(Math.min(100, this.done * 100 / Math.max(1, arrayList.size())));
                    }
                }
                return null;
            }

            /*
             * WARNING - Removed try catching itself - possible behaviour change.
             */
            private void searchCode(List<String> list) throws InterruptedException {
                int n = Math.max(1, Runtime.getRuntime().availableProcessors() - 1);
                ExecutorService executorService = Executors.newFixedThreadPool(n, runnable -> {
                    Thread thread = new Thread(runnable, "search");
                    thread.setDaemon(true);
                    return thread;
                });
                try {
                    ExecutorCompletionService<Object[]> executorCompletionService = new ExecutorCompletionService<Object[]>(executorService);
                    for (String object : list) {
                        executorCompletionService.submit(() -> new Object[]{object, this.this$0.session.decompile(object, Session.Variant.DEOBFUSCATED, this.this$0.engine).source()});
                    }
                    for (int i = 0; i < list.size() && !this.isCancelled(); ++i) {
                        if (this.count >= 5000) {
                            break;
                        }
                        Future future = executorCompletionService.take();
                        try {
                            Object[] objectArray = (Object[])future.get();
                            this.scanSource((String)objectArray[0], (String)objectArray[1]);
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                        ++this.done;
                        this.setProgress(Math.min(100, this.done * 100 / Math.max(1, list.size())));
                    }
                }
                finally {
                    executorService.shutdownNow();
                }
            }

            private void scanSource(String string, String string2) {
                Matcher matcher = pattern.matcher(string2);
                int n = string2.length();
                int n2 = 0;
                int n3 = 0;
                while (this.count < 5000) {
                    int n4 = string2.indexOf(10, n2);
                    if (n4 < 0) {
                        n4 = n;
                    }
                    matcher.region(n2, n4);
                    if (matcher.find()) {
                        ++this.count;
                        this.publish(new Hit(string, n3, string2.substring(n2, n4), matcher.group()));
                    }
                    if (n4 == n) break;
                    n2 = n4 + 1;
                    ++n3;
                }
            }

            private void searchStrings(String string, byte[] byArray) {
                final ArrayList arrayList2 = new ArrayList();
                try {
                    new ClassReader(byArray).accept(new ClassVisitor(this, 589824){
                        {
                            Objects.requireNonNull(var1_1);
                            super(n);
                        }

                        @Override
                        public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
                            if (object instanceof String) {
                                String string4 = (String)object;
                                arrayList2.add(string4);
                            }
                            return null;
                        }

                        @Override
                        public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
                            return new MethodVisitor(this, 589824){
                                {
                                    Objects.requireNonNull(var1_1);
                                    super(n);
                                }

                                @Override
                                public void visitLdcInsn(Object object) {
                                    if (object instanceof String) {
                                        String string = (String)object;
                                        arrayList2.add(string);
                                    }
                                }

                                @Override
                                public void visitInvokeDynamicInsn(String string, String string2, Handle handle, Object ... objectArray) {
                                    for (Object object : objectArray) {
                                        if (!(object instanceof String)) continue;
                                        String string3 = (String)object;
                                        arrayList2.add(string3.replace("\u0001", "\u2026"));
                                    }
                                }
                            };
                        }
                    }, 6);
                }
                catch (Exception exception) {
                    return;
                }
                for (String string2 : arrayList2) {
                    Matcher matcher = pattern.matcher(string2);
                    if (!matcher.find() || this.count >= 5000) continue;
                    ++this.count;
                    this.publish(new Hit(Session.topLevel(string, map), -1, "\"" + string2 + "\"", matcher.group()));
                }
            }

            private void searchNames(String string, byte[] byArray) {
                if (pattern.matcher(string.replace('/', '.')).find()) {
                    ++this.count;
                    this.publish(new Hit(Session.topLevel(string, map), -1, "class " + string.replace('/', '.'), null));
                }
                final ArrayList arrayList2 = new ArrayList();
                try {
                    new ClassReader(byArray).accept(new ClassVisitor(this, 589824){
                        {
                            Objects.requireNonNull(var1_1);
                            super(n);
                        }

                        @Override
                        public FieldVisitor visitField(int n, String string, String string2, String string3, Object object) {
                            arrayList2.add(new String[]{"field", string});
                            return null;
                        }

                        @Override
                        public MethodVisitor visitMethod(int n, String string, String string2, String string3, String[] stringArray) {
                            if (!string.startsWith("<")) {
                                arrayList2.add(new String[]{"method", string});
                            }
                            return null;
                        }
                    }, 7);
                }
                catch (Exception exception) {
                    return;
                }
                for (String[] stringArray : arrayList2) {
                    if (!pattern.matcher(stringArray[1]).find() || this.count >= 5000) continue;
                    ++this.count;
                    this.publish(new Hit(Session.topLevel(string, map), -1, stringArray[0] + " " + stringArray[1], stringArray[1]));
                }
            }

            @Override
            protected void process(List<Hit> list) {
                this.this$0.results.addAll(list);
                this.this$0.progress.setValue(this.done);
                this.this$0.status.setText(this.this$0.results.size() + " results" + (this.count >= 5000 ? " (limit reached)" : "") + " \u2014 " + this.done + " / " + arrayList.size() + " classes");
            }

            @Override
            protected void done() {
                this.this$0.progress.setVisible(false);
                this.this$0.go.setText("Search");
                String string = this.this$0.results.size() + " results" + (this.this$0.results.size() >= 5000 ? " (limit reached)" : "");
                this.this$0.status.setText(this.isCancelled() ? string + " (stopped)" : string);
                if (!this.this$0.results.isEmpty() && this.this$0.list.getSelectedIndex() < 0) {
                    this.this$0.list.setSelectedIndex(0);
                }
            }
        };
        this.worker.addPropertyChangeListener(propertyChangeEvent -> {
            if ("progress".equals(propertyChangeEvent.getPropertyName())) {
                this.progress.setValue(this.progress.getMaximum() * (Integer)propertyChangeEvent.getNewValue() / 100);
            }
        });
        this.worker.execute();
    }

    private static enum Scope {
        CODE("Decompiled code"),
        STRINGS("String constants (fast)"),
        NAMES("Class & member names (fast)");

        final String label;

        private Scope(String string2) {
            this.label = string2;
        }

        public String toString() {
            return this.label;
        }
    }

    static interface OpenHandler {
        public void open(Hit var1);
    }

    record Hit(String className, int line, String text, String match) {
    }
}

