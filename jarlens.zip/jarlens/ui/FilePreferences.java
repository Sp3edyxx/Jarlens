/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.prefs.AbstractPreferences;

final class FilePreferences
extends AbstractPreferences {
    private final Path file;
    private final Properties values = new Properties();
    private boolean dirty;

    FilePreferences(Path path) {
        super(null, "");
        this.file = path;
        try (InputStream inputStream = Files.newInputStream(path, new OpenOption[0]);){
            this.values.load(inputStream);
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    @Override
    protected void putSpi(String string, String string2) {
        if (!string2.equals(this.values.getProperty(string))) {
            this.values.setProperty(string, string2);
            this.dirty = true;
        }
    }

    @Override
    protected String getSpi(String string) {
        return this.values.getProperty(string);
    }

    @Override
    protected void removeSpi(String string) {
        if (this.values.remove(string) != null) {
            this.dirty = true;
        }
    }

    @Override
    protected void removeNodeSpi() {
        this.values.clear();
        this.dirty = true;
    }

    @Override
    protected String[] keysSpi() {
        return this.values.stringPropertyNames().toArray(new String[0]);
    }

    @Override
    protected String[] childrenNamesSpi() {
        return new String[0];
    }

    @Override
    protected AbstractPreferences childSpi(String string) {
        throw new UnsupportedOperationException("flat settings file");
    }

    @Override
    protected void syncSpi() {
    }

    @Override
    protected void flushSpi() {
        if (!this.dirty) {
            return;
        }
        try {
            Path path = this.file.resolveSibling(String.valueOf(this.file.getFileName()) + ".tmp");
            try (OutputStream outputStream = Files.newOutputStream(path, new OpenOption[0]);){
                this.values.store(outputStream, "JarLens settings");
            }
            Files.move(path, this.file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            this.dirty = false;
        }
        catch (IOException | RuntimeException exception) {
            // empty catch block
        }
    }
}

