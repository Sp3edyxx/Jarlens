/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import dev.jarlens.core.JarModel;
import dev.jarlens.ui.Icons;
import dev.jarlens.ui.ResourceView;
import dev.jarlens.ui.Session;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import org.objectweb.asm.ClassReader;

final class FileTreePanel
extends JPanel {
    private final JTree tree = new JTree(new DefaultTreeModel(new DefaultMutableTreeNode()));
    private final JTextField filter = new JTextField();
    private final Timer filterTimer;
    private Session session;
    private final Map<byte[], int[]> classMeta = new HashMap<byte[], int[]>();
    private Consumer<Item> openHandler = item -> {};
    private Consumer<Item> openOriginalHandler = item -> {};

    FileTreePanel() {
        super(new BorderLayout());
        this.filter.putClientProperty("JTextField.placeholderText", "Filter classes and files\u2026");
        this.filter.putClientProperty("JTextField.showClearButton", true);
        this.filter.putClientProperty("JTextField.leadingIcon", new ImageIcon(FileTreePanel.searchGlyph()));
        this.filter.setBorder(BorderFactory.createCompoundBorder(this.filter.getBorder(), BorderFactory.createEmptyBorder(2, 2, 2, 2)));
        this.filterTimer = new Timer(200, actionEvent -> this.rebuild());
        this.filterTimer.setRepeats(false);
        this.filter.getDocument().addDocumentListener(new DocumentListener(this){
            final /* synthetic */ FileTreePanel this$0;
            {
                FileTreePanel fileTreePanel2 = fileTreePanel;
                Objects.requireNonNull(fileTreePanel2);
                this.this$0 = fileTreePanel2;
            }

            @Override
            public void insertUpdate(DocumentEvent documentEvent) {
                this.this$0.filterTimer.restart();
            }

            @Override
            public void removeUpdate(DocumentEvent documentEvent) {
                this.this$0.filterTimer.restart();
            }

            @Override
            public void changedUpdate(DocumentEvent documentEvent) {
                this.this$0.filterTimer.restart();
            }
        });
        this.filter.registerKeyboardAction(actionEvent -> this.tree.requestFocusInWindow(), KeyStroke.getKeyStroke(40, 0), 0);
        this.tree.setRootVisible(true);
        this.tree.setShowsRootHandles(true);
        this.tree.getSelectionModel().setSelectionMode(1);
        this.tree.setCellRenderer(new Renderer());
        this.tree.setToggleClickCount(2);
        this.tree.addMouseListener(new MouseAdapter(this){
            final /* synthetic */ FileTreePanel this$0;
            {
                FileTreePanel fileTreePanel2 = fileTreePanel;
                Objects.requireNonNull(fileTreePanel2);
                this.this$0 = fileTreePanel2;
            }

            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                this.this$0.maybePopup(mouseEvent);
            }

            @Override
            public void mouseReleased(MouseEvent mouseEvent) {
                this.this$0.maybePopup(mouseEvent);
            }

            @Override
            public void mouseClicked(MouseEvent mouseEvent) {
                if (mouseEvent.getButton() != 1) {
                    return;
                }
                Item item = this.this$0.itemAt(mouseEvent.getX(), mouseEvent.getY());
                if (item == null) {
                    return;
                }
                if ((item.kind == Kind.NESTED_JAR ? mouseEvent.getClickCount() == 2 : mouseEvent.getClickCount() == 1) && item.kind != Kind.DIR && item.kind != Kind.ROOT) {
                    this.this$0.openHandler.accept(item);
                }
            }
        });
        this.tree.registerKeyboardAction(actionEvent -> {
            Item item = this.selected();
            if (item != null && item.kind != Kind.DIR && item.kind != Kind.ROOT) {
                this.openHandler.accept(item);
            }
        }, KeyStroke.getKeyStroke(10, 0), 0);
        this.add((Component)this.filter, "North");
        JScrollPane jScrollPane = new JScrollPane(this.tree);
        jScrollPane.setBorder(BorderFactory.createEmptyBorder());
        this.add((Component)jScrollPane, "Center");
    }

    private static BufferedImage searchGlyph() {
        int n = 14;
        BufferedImage bufferedImage = new BufferedImage(n, n, 2);
        Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2D.setColor(new Color(9080728));
        graphics2D.setStroke(new BasicStroke(1.6f));
        graphics2D.drawOval(1, 1, 8, 8);
        graphics2D.drawLine(8, 8, 12, 12);
        graphics2D.dispose();
        return bufferedImage;
    }

    void onOpen(Consumer<Item> consumer) {
        this.openHandler = consumer;
    }

    void onOpenOriginal(Consumer<Item> consumer) {
        this.openOriginalHandler = consumer;
    }

    void focusFilter() {
        this.filter.requestFocusInWindow();
        this.filter.selectAll();
    }

    void setSession(Session session) {
        this.session = session;
        this.classMeta.clear();
        this.rebuild();
    }

    private Item selected() {
        Item item;
        TreePath treePath = this.tree.getSelectionPath();
        if (treePath == null) {
            return null;
        }
        Object object = ((DefaultMutableTreeNode)treePath.getLastPathComponent()).getUserObject();
        return object instanceof Item ? (item = (Item)object) : null;
    }

    private Item itemAt(int n, int n2) {
        Item item;
        TreePath treePath = this.tree.getPathForLocation(n, n2);
        if (treePath == null) {
            return null;
        }
        Object object = ((DefaultMutableTreeNode)treePath.getLastPathComponent()).getUserObject();
        return object instanceof Item ? (item = (Item)object) : null;
    }

    private void maybePopup(MouseEvent mouseEvent) {
        JMenuItem jMenuItem;
        if (!mouseEvent.isPopupTrigger()) {
            return;
        }
        TreePath treePath = this.tree.getPathForLocation(mouseEvent.getX(), mouseEvent.getY());
        if (treePath == null) {
            return;
        }
        this.tree.setSelectionPath(treePath);
        Item item = this.selected();
        if (item == null) {
            return;
        }
        JPopupMenu jPopupMenu = new JPopupMenu();
        if (item.kind == Kind.CLASS || item.kind == Kind.RESOURCE || item.kind == Kind.NESTED_JAR || item.kind == Kind.BROKEN) {
            jMenuItem = new JMenuItem(item.kind == Kind.NESTED_JAR ? "Open nested jar" : "Open");
            jMenuItem.addActionListener(actionEvent -> this.openHandler.accept(item));
            jPopupMenu.add(jMenuItem);
        }
        if (item.kind == Kind.CLASS) {
            jMenuItem = new JMenuItem("Open original (not deobfuscated)");
            jMenuItem.addActionListener(actionEvent -> this.openOriginalHandler.accept(item));
            jPopupMenu.add(jMenuItem);
        }
        jMenuItem = new JMenuItem("Copy name");
        jMenuItem.addActionListener(actionEvent -> Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(item.kind == Kind.CLASS ? item.path.replace('/', '.') : item.path), null));
        jPopupMenu.add(jMenuItem);
        jPopupMenu.show(this.tree, mouseEvent.getX(), mouseEvent.getY());
    }

    void reveal(String string) {
        DefaultMutableTreeNode defaultMutableTreeNode = (DefaultMutableTreeNode)this.tree.getModel().getRoot();
        Enumeration<TreeNode> enumeration = defaultMutableTreeNode.depthFirstEnumeration();
        while (enumeration.hasMoreElements()) {
            DefaultMutableTreeNode defaultMutableTreeNode2 = (DefaultMutableTreeNode)enumeration.nextElement();
            Object object = defaultMutableTreeNode2.getUserObject();
            if (!(object instanceof Item)) continue;
            Item item = (Item)object;
            if (item.kind != Kind.CLASS || !item.path.equals(string)) continue;
            TreePath treePath = new TreePath(defaultMutableTreeNode2.getPath());
            this.tree.setSelectionPath(treePath);
            this.tree.scrollPathToVisible(treePath);
            return;
        }
    }

    void rebuild() {
        Object object;
        int n;
        Map.Entry<String, byte[]> entry22;
        if (this.session == null) {
            DefaultMutableTreeNode defaultMutableTreeNode = new DefaultMutableTreeNode(new Item(Kind.ROOT, "Drop a .jar here or use File \u2192 Open", "", 0, false));
            this.tree.setModel(new DefaultTreeModel(defaultMutableTreeNode));
            return;
        }
        String string = this.filter.getText().trim().toLowerCase(Locale.ROOT);
        JarModel jarModel = this.session.model();
        Map<String, byte[]> map = this.session.classes(Session.Variant.DEOBFUSCATED);
        Dir dir = new Dir("");
        int n2 = 0;
        Predicate<String> predicate = string.isEmpty() ? null : FileTreePanel.matcher(string);
        for (Map.Entry<String, byte[]> entry22 : map.entrySet()) {
            String object22 = entry22.getKey();
            if (!Session.topLevel(object22, map).equals(object22) || predicate != null && !predicate.test(object22.replace('/', '.'))) continue;
            n = object22.lastIndexOf(47);
            object = n < 0 ? "" : object22.substring(0, n);
            int[] nArray = this.classMeta.computeIfAbsent((byte[])entry22.getValue(), FileTreePanel::readMeta);
            int n3 = nArray[0];
            boolean bl = nArray[1] != 0;
            dir.dir((String)object).items.add(new Item(Kind.CLASS, object22.substring(n + 1), object22, n3, bl));
            ++n2;
        }
        HashSet hashSet = new HashSet();
        for (JarModel.BrokenClass brokenClass : jarModel.brokenClasses()) {
            hashSet.add(brokenClass.entryPath());
        }
        for (String string2 : jarModel.resources().keySet()) {
            if (predicate != null && !predicate.test(string2)) continue;
            n = string2.lastIndexOf(47);
            object = n < 0 ? "" : string2.substring(0, n);
            boolean bl = hashSet.contains(string2);
            Kind kind = bl ? Kind.BROKEN : (jarModel.isNestedArchive(string2) ? Kind.NESTED_JAR : Kind.RESOURCE);
            dir.dir((String)object).items.add(new Item(kind, string2.substring(n + 1), string2, 0, false));
            ++n2;
        }
        entry22 = jarModel.displayName() + (String)(string.isEmpty() ? "" : "  (" + n2 + " matches)");
        DefaultMutableTreeNode defaultMutableTreeNode = new DefaultMutableTreeNode(new Item(Kind.ROOT, (String)((Object)entry22), "", 0, false));
        dir.addChildrenTo(defaultMutableTreeNode, "");
        object = new DefaultTreeModel(defaultMutableTreeNode);
        this.tree.setModel((TreeModel)object);
        if (!string.isEmpty() && n2 <= 3000) {
            for (int i = 0; i < this.tree.getRowCount() && i < 20000; ++i) {
                this.tree.expandRow(i);
            }
        } else {
            this.tree.expandRow(0);
        }
    }

    private static Predicate<String> matcher(String string3) {
        if (string3.contains("*")) {
            String string4 = "\\Q" + string3.replace("*", "\\E.*\\Q") + "\\E";
            Pattern pattern = Pattern.compile(".*" + string4 + ".*");
            return string -> pattern.matcher(string.toLowerCase(Locale.ROOT)).matches();
        }
        return string2 -> string2.toLowerCase(Locale.ROOT).contains(string3);
    }

    private static int[] readMeta(byte[] byArray) {
        try {
            ClassReader classReader = new ClassReader(byArray);
            return new int[]{classReader.getAccess(), "java/lang/Record".equals(classReader.getSuperName()) ? 1 : 0};
        }
        catch (Exception exception) {
            return new int[]{0, 0};
        }
    }

    private static final class Renderer
    extends DefaultTreeCellRenderer {
        private final Map<String, String> tooltips = new HashMap<String, String>();

        private Renderer() {
        }

        @Override
        public Component getTreeCellRendererComponent(JTree jTree, Object object, boolean bl, boolean bl2, boolean bl3, int n, boolean bl4) {
            super.getTreeCellRendererComponent(jTree, object, bl, bl2, bl3, n, bl4);
            Object object2 = ((DefaultMutableTreeNode)object).getUserObject();
            if (object2 instanceof Item) {
                Item item = (Item)object2;
                switch (item.kind.ordinal()) {
                    case 0: {
                        this.setIcon(Icons.JAR);
                        break;
                    }
                    case 1: {
                        this.setIcon(Icons.folder(bl2));
                        break;
                    }
                    case 2: {
                        this.setIcon(Renderer.classIcon(item));
                        break;
                    }
                    case 4: {
                        this.setIcon(Icons.JAR);
                        break;
                    }
                    case 5: {
                        this.setIcon(Icons.BROKEN);
                        break;
                    }
                    case 3: {
                        this.setIcon(ResourceView.isImage(item.path) ? Icons.IMAGE : (ResourceView.isText(item.path, null) ? Icons.TEXT : Icons.BINARY));
                    }
                }
                this.setToolTipText(this.tooltips.computeIfAbsent(item.path, string -> item.kind == Kind.CLASS ? string.replace('/', '.') : string));
            }
            return this;
        }

        private static Icon classIcon(Item item) {
            int n = item.access;
            if ((n & 0x2000) != 0) {
                return Icons.ANNOTATION;
            }
            if ((n & 0x4000) != 0) {
                return Icons.ENUM;
            }
            if ((n & 0x200) != 0) {
                return Icons.INTERFACE;
            }
            if (item.record) {
                return Icons.RECORD;
            }
            if ((n & 0x400) != 0) {
                return Icons.ABSTRACT;
            }
            return Icons.CLASS;
        }
    }

    record Item(Kind kind, String label, String path, int access, boolean record) {
        @Override
        public String toString() {
            return this.label;
        }
    }

    static enum Kind {
        ROOT,
        DIR,
        CLASS,
        RESOURCE,
        NESTED_JAR,
        BROKEN;

    }

    private static final class Dir {
        private static final Comparator<Item> ITEM_ORDER = Comparator.comparingInt(item -> item.kind() == Kind.CLASS ? 0 : 1).thenComparing(item -> item.label().toLowerCase(Locale.ROOT));
        final String name;
        final Map<String, Dir> dirs = new TreeMap<String, Dir>();
        final List<Item> items = new ArrayList<Item>();

        Dir(String string) {
            this.name = string;
        }

        Dir dir(String string) {
            if (string.isEmpty()) {
                return this;
            }
            Dir dir = this;
            for (String string2 : string.split("/")) {
                dir = dir.dirs.computeIfAbsent(string2, Dir::new);
            }
            return dir;
        }

        void addChildrenTo(DefaultMutableTreeNode defaultMutableTreeNode, String string) {
            Iterator<Object> iterator = this.dirs.values().iterator();
            while (iterator.hasNext()) {
                Dir object;
                Dir dir = object = iterator.next();
                StringBuilder stringBuilder = new StringBuilder(object.name);
                String string2 = string + object.name;
                while (dir.items.isEmpty() && dir.dirs.size() == 1) {
                    dir = dir.dirs.values().iterator().next();
                    stringBuilder.append('.').append(dir.name);
                    string2 = string2 + "/" + dir.name;
                }
                DefaultMutableTreeNode defaultMutableTreeNode2 = new DefaultMutableTreeNode(new Item(Kind.DIR, stringBuilder.toString(), string2, 0, false));
                dir.addChildrenTo(defaultMutableTreeNode2, string2 + "/");
                defaultMutableTreeNode.add(defaultMutableTreeNode2);
            }
            this.items.sort(ITEM_ORDER);
            for (Item item : this.items) {
                defaultMutableTreeNode.add(new DefaultMutableTreeNode(item, false));
            }
        }
    }
}

