/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import dev.jarlens.decompile.DecompilerService;
import dev.jarlens.deob.DeobSettings;
import dev.jarlens.ui.FilePreferences;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

public final class AppSettings {
    private static final String SETTINGS_FILE = System.getProperty("jarlens.settings");
    static final boolean PORTABLE = SETTINGS_FILE != null && !SETTINGS_FILE.isBlank();
    private static final Preferences PREFS = PORTABLE ? new FilePreferences(Path.of(SETTINGS_FILE, new String[0])) : Preferences.userRoot().node("dev/jarlens");
    private static final int MAX_RECENT = 10;
    public boolean darkTheme = true;
    public int fontSize = 13;
    public DecompilerService.Engine engine = DecompilerService.Engine.AUTO;
    public DeobSettings deob = new DeobSettings();
    public final List<String> recentFiles = new ArrayList<String>();

    public static AppSettings load() {
        AppSettings appSettings = new AppSettings();
        try {
            appSettings.darkTheme = PREFS.getBoolean("ui.dark", true);
            appSettings.fontSize = Math.max(8, Math.min(40, PREFS.getInt("ui.fontSize", 13)));
            try {
                appSettings.engine = DecompilerService.Engine.valueOf(PREFS.get("decompiler.engine", "AUTO"));
            }
            catch (IllegalArgumentException illegalArgumentException) {
                appSettings.engine = DecompilerService.Engine.AUTO;
            }
            appSettings.deob = DeobSettings.load(PREFS);
            for (int i = 0; i < 10 && !PORTABLE; ++i) {
                String string = PREFS.get("recent." + i, null);
                if (string == null || string.isBlank()) continue;
                appSettings.recentFiles.add(string);
            }
        }
        catch (RuntimeException runtimeException) {
            // empty catch block
        }
        return appSettings;
    }

    public void save() {
        try {
            PREFS.putBoolean("ui.dark", this.darkTheme);
            PREFS.putInt("ui.fontSize", this.fontSize);
            PREFS.put("decompiler.engine", this.engine.name());
            this.deob.save(PREFS);
            for (int i = 0; i < 10; ++i) {
                if (i < this.recentFiles.size() && !PORTABLE) {
                    PREFS.put("recent." + i, this.recentFiles.get(i));
                    continue;
                }
                PREFS.remove("recent." + i);
            }
            PREFS.flush();
        }
        catch (RuntimeException | BackingStoreException exception) {
            // empty catch block
        }
    }

    public void addRecent(String string) {
        this.recentFiles.remove(string);
        this.recentFiles.add(0, string);
        while (this.recentFiles.size() > 10) {
            this.recentFiles.remove(this.recentFiles.size() - 1);
        }
        if (!PORTABLE) {
            this.save();
        }
    }
}

