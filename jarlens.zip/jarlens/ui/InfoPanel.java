/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import dev.jarlens.core.JarModel;
import dev.jarlens.deob.DeobReport;
import dev.jarlens.deob.Deobfuscator;
import dev.jarlens.deob.Stat;
import dev.jarlens.mapping.MappingSet;
import dev.jarlens.ui.ResourceView;
import dev.jarlens.ui.Session;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.event.HyperlinkEvent;

final class InfoPanel
extends JPanel {
    private final JEditorPane pane = new JEditorPane();
    private Consumer<String> classLinkHandler = string -> {};

    InfoPanel() {
        super(new BorderLayout());
        this.pane.setContentType("text/html");
        this.pane.setEditable(false);
        this.pane.putClientProperty("JEditorPane.honorDisplayProperties", true);
        this.pane.addHyperlinkListener(hyperlinkEvent -> {
            if (hyperlinkEvent.getEventType() == HyperlinkEvent.EventType.ACTIVATED && hyperlinkEvent.getDescription() != null && hyperlinkEvent.getDescription().startsWith("class:")) {
                this.classLinkHandler.accept(hyperlinkEvent.getDescription().substring(6));
            }
        });
        JScrollPane jScrollPane = new JScrollPane(this.pane);
        jScrollPane.setBorder(BorderFactory.createEmptyBorder());
        this.add((Component)jScrollPane, "Center");
        this.showMessage("No jar opened.");
    }

    void onClassLink(Consumer<String> consumer) {
        this.classLinkHandler = consumer;
    }

    void showMessage(String string) {
        this.pane.setText(InfoPanel.html("<p>" + ResourceView.escape(string) + "</p>"));
    }

    void showProgress(JarModel jarModel, String string) {
        this.pane.setText(InfoPanel.html(InfoPanel.header(jarModel) + "<p><i>" + ResourceView.escape(string) + "</i></p>"));
    }

    /*
     * WARNING - void declaration
     */
    void update(Session session) {
        JarModel jarModel = session.model();
        Deobfuscator.Result result = session.result();
        StringBuilder stringBuilder = new StringBuilder(InfoPanel.header(jarModel));
        if (result != null) {
            List<String> list;
            Object object2;
            Iterator<String> iterator = result.report();
            stringBuilder.append("<h3>Obfuscation found</h3>");
            List<String> object3 = ((DeobReport)((Object)iterator)).techniques();
            if (object3.isEmpty()) {
                stringBuilder.append("<p>No obfuscation detected.</p>");
            } else {
                stringBuilder.append("<ul>");
                for (Object object2 : object3) {
                    stringBuilder.append("<li>").append(ResourceView.escape((String)object2)).append("</li>");
                }
                stringBuilder.append("</ul>");
            }
            stringBuilder.append("<p><b>Strings decrypted:</b> ").append(((DeobReport)((Object)iterator)).get(Stat.STRINGS_DECRYPTED));
            if (((DeobReport)((Object)iterator)).get(Stat.STRINGS_FAILED) > 0L) {
                stringBuilder.append(" (").append(((DeobReport)((Object)iterator)).get(Stat.STRINGS_FAILED)).append(" left encrypted)");
            }
            stringBuilder.append("</p>");
            Map<Stat, Long> map = ((DeobReport)((Object)iterator)).stats();
            if (!map.isEmpty()) {
                stringBuilder.append("<h3>Deobfuscation</h3><table cellspacing=0 cellpadding=1>");
                for (Map.Entry entry : map.entrySet()) {
                    stringBuilder.append("<tr><td>").append(ResourceView.escape(((Stat)((Object)entry.getKey())).label)).append("</td><td align=right>&nbsp;").append(entry.getValue()).append("</td></tr>");
                }
                stringBuilder.append("</table>");
            }
            stringBuilder.append("<p class=dim>").append(((DeobReport)((Object)iterator)).passes()).append(" pass(es), ").append(((DeobReport)((Object)iterator)).millis()).append(" ms</p>");
            object2 = session.mapping();
            if (object2 != null) {
                stringBuilder.append("<p><b>Mapping:</b> ").append(((MappingSet)object2).format()).append(" \u2014 ").append(((MappingSet)object2).classCount()).append(" classes, ").append(((MappingSet)object2).methodCount()).append(" methods, ").append(((MappingSet)object2).fieldCount()).append(" fields</p>");
            }
            if (!(list = ((DeobReport)((Object)iterator)).logLines()).isEmpty()) {
                stringBuilder.append("<h3>Deobfuscator notes</h3><ul>");
                boolean bl = false;
                for (String string : list) {
                    void var10_15;
                    if (++var10_15 >= 50) {
                        stringBuilder.append("<li>\u2026 ").append(list.size() - 50).append(" more</li>");
                        break;
                    }
                    stringBuilder.append("<li class=dim>").append(ResourceView.escape(string)).append("</li>");
                }
                stringBuilder.append("</ul>");
            }
        }
        if (!jarModel.warnings().isEmpty() || !jarModel.brokenClasses().isEmpty()) {
            stringBuilder.append("<h3>Archive warnings</h3><ul>");
            int n = 0;
            for (JarModel.BrokenClass brokenClass : jarModel.brokenClasses()) {
                if (n++ >= 50) break;
                stringBuilder.append("<li>Unparseable class ").append(ResourceView.escape(brokenClass.entryPath())).append(": ").append(ResourceView.escape(brokenClass.error())).append("</li>");
            }
            for (String string : jarModel.warnings()) {
                if (n++ >= 80) {
                    stringBuilder.append("<li>\u2026</li>");
                    break;
                }
                stringBuilder.append("<li class=dim>").append(ResourceView.escape(string)).append("</li>");
            }
            stringBuilder.append("</ul>");
        }
        this.pane.setText(InfoPanel.html(stringBuilder.toString()));
        this.pane.setCaretPosition(0);
    }

    private static String header(JarModel jarModel) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("<h2>").append(ResourceView.escape(jarModel.displayName())).append("</h2><table cellspacing=0 cellpadding=1>");
        InfoPanel.row(stringBuilder, "Java version", InfoPanel.javaVersions(jarModel));
        String string = jarModel.mainClass();
        InfoPanel.row(stringBuilder, "Main class", (String)(string == null ? "\u2014" : "<a href=\"class:" + ResourceView.escape(string.replace('.', '/')) + "\">" + ResourceView.escape(string) + "</a>"));
        InfoPanel.row(stringBuilder, "Classes", String.valueOf(jarModel.classes().size()));
        InfoPanel.row(stringBuilder, "Resources", String.valueOf(jarModel.resources().size()));
        long l = jarModel.resources().keySet().stream().filter(jarModel::isNestedArchive).count();
        if (l > 0L) {
            InfoPanel.row(stringBuilder, "Nested jars", String.valueOf(l));
        }
        stringBuilder.append("</table>");
        return stringBuilder.toString();
    }

    private static String javaVersions(JarModel jarModel) {
        Map<Integer, Integer> map = jarModel.classVersions();
        if (map.isEmpty()) {
            return "\u2014";
        }
        StringBuilder stringBuilder = new StringBuilder();
        int n3 = map.keySet().stream().max(Integer::compare).orElse(0);
        stringBuilder.append(JarModel.javaVersionName(n3)).append(" (class file ").append(n3).append(")");
        if (map.size() > 1) {
            stringBuilder.append("<br><span class=dim>");
            map.forEach((n, n2) -> stringBuilder.append(JarModel.javaVersionName(n)).append(": ").append(n2).append("&nbsp; "));
            stringBuilder.append("</span>");
        }
        return stringBuilder.toString();
    }

    private static void row(StringBuilder stringBuilder, String string, String string2) {
        stringBuilder.append("<tr><td valign=top><b>").append(string).append("</b>&nbsp;&nbsp;</td><td>").append(string2).append("</td></tr>");
    }

    private static String html(String string) {
        Color color = UIManager.getColor("Label.foreground");
        Color color2 = UIManager.getColor("Label.disabledForeground");
        Color color3 = UIManager.getColor("Component.linkColor");
        if (color3 == null) {
            color3 = new Color(5807606);
        }
        return "<html><head><style>body{font-family:sans-serif;margin:6px;color:" + InfoPanel.hex(color) + "} h2{margin:2px 0 6px 0} h3{margin:10px 0 3px 0} ul{margin-left:16px;margin-top:2px} li{margin-bottom:2px} .dim{color:" + InfoPanel.hex(color2) + "} a{color:" + InfoPanel.hex(color3) + "}</style></head><body>" + string + "</body></html>";
    }

    private static String hex(Color color) {
        if (color == null) {
            return "#888888";
        }
        return String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue());
    }
}

