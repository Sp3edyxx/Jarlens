/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import javax.swing.BorderFactory;
import javax.swing.SwingUtilities;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.Theme;
import org.fife.ui.rtextarea.RTextScrollPane;

final class Editors {
    private static final Set<RSyntaxTextArea> ALL = Collections.newSetFromMap(new WeakHashMap());
    private static boolean dark = true;
    private static int fontSize = 13;
    private static volatile String fontFamily;
    private static volatile byte[] darkThemeXml;
    private static volatile byte[] lightThemeXml;

    private Editors() {
    }

    static void warmUp() {
        Editors.family();
        Editors.themeXml(true);
        Editors.themeXml(false);
    }

    private static byte[] themeXml(boolean bl) {
        byte[] byArray;
        byte[] byArray2 = byArray = bl ? darkThemeXml : lightThemeXml;
        if (byArray == null) {
            String string = bl ? "/org/fife/ui/rsyntaxtextarea/themes/dark.xml" : "/org/fife/ui/rsyntaxtextarea/themes/idea.xml";
            try (InputStream inputStream = RSyntaxTextArea.class.getResourceAsStream(string);){
                byArray = inputStream == null ? new byte[]{} : inputStream.readAllBytes();
            }
            catch (Exception exception) {
                byArray = new byte[]{};
            }
            if (bl) {
                darkThemeXml = byArray;
            } else {
                lightThemeXml = byArray;
            }
        }
        return byArray;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static RSyntaxTextArea create(String string) {
        Set<RSyntaxTextArea> set;
        RSyntaxTextArea rSyntaxTextArea = new RSyntaxTextArea();
        rSyntaxTextArea.setEditable(false);
        rSyntaxTextArea.setSyntaxEditingStyle(string == null ? "text/plain" : string);
        rSyntaxTextArea.setCodeFoldingEnabled(true);
        rSyntaxTextArea.setAntiAliasingEnabled(true);
        rSyntaxTextArea.setHighlightCurrentLine(true);
        rSyntaxTextArea.setMarkOccurrences(true);
        rSyntaxTextArea.setTabSize(4);
        rSyntaxTextArea.setBracketMatchingEnabled(true);
        rSyntaxTextArea.setAnimateBracketMatching(false);
        rSyntaxTextArea.setFadeCurrentLineHighlight(false);
        Editors.apply(rSyntaxTextArea);
        Set<RSyntaxTextArea> set2 = set = ALL;
        synchronized (set2) {
            ALL.add(rSyntaxTextArea);
        }
        return rSyntaxTextArea;
    }

    static RTextScrollPane scroll(RSyntaxTextArea rSyntaxTextArea) {
        RTextScrollPane rTextScrollPane = new RTextScrollPane(rSyntaxTextArea, true);
        rTextScrollPane.setFoldIndicatorEnabled(true);
        rTextScrollPane.setBorder(BorderFactory.createEmptyBorder());
        Editors.apply(rSyntaxTextArea);
        return rTextScrollPane;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    static void configure(boolean bl, int n) {
        Set<RSyntaxTextArea> set;
        dark = bl;
        fontSize = n;
        Set<RSyntaxTextArea> set2 = set = ALL;
        synchronized (set2) {
            for (RSyntaxTextArea rSyntaxTextArea : ALL) {
                Editors.apply(rSyntaxTextArea);
            }
        }
    }

    private static void apply(RSyntaxTextArea rSyntaxTextArea) {
        byte[] byArray = Editors.themeXml(dark);
        if (byArray.length > 0) {
            try {
                Theme.load(new ByteArrayInputStream(byArray)).apply(rSyntaxTextArea);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        Font font = new Font(Editors.family(), 0, fontSize);
        rSyntaxTextArea.setFont(font);
        RTextScrollPane rTextScrollPane = (RTextScrollPane)SwingUtilities.getAncestorOfClass(RTextScrollPane.class, rSyntaxTextArea);
        if (rTextScrollPane != null) {
            rTextScrollPane.getGutter().setLineNumberFont(font.deriveFont(font.getSize2D() - 1.0f));
        }
        rSyntaxTextArea.revalidate();
        rSyntaxTextArea.repaint();
    }

    private static String family() {
        Set<String> set;
        if (fontFamily != null) {
            return fontFamily;
        }
        try {
            set = Set.of(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
        }
        catch (Exception exception) {
            set = Set.of();
        }
        for (String string : new String[]{"JetBrains Mono", "Cascadia Mono", "Consolas", "SF Mono", "Menlo", "DejaVu Sans Mono", "Liberation Mono"}) {
            if (!set.contains(string)) continue;
            fontFamily = string;
            return fontFamily;
        }
        fontFamily = "Monospaced";
        return "Monospaced";
    }
}

