/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import dev.jarlens.decompile.DecompilerService;
import dev.jarlens.deob.DeobSettings;
import dev.jarlens.ui.AppSettings;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.KeyStroke;
import javax.swing.SpinnerNumberModel;

final class SettingsDialog
extends JDialog {
    SettingsDialog(JFrame jFrame, AppSettings appSettings, boolean bl, Consumer<Boolean> consumer) {
        super(jFrame, "Deobfuscation Settings", true);
        DeobSettings deobSettings = appSettings.deob.copy();
        JCheckBox jCheckBox = SettingsDialog.box("Deobfuscate automatically", deobSettings.enabled, "Run the transforms below when a jar is opened. If off, classes are decompiled as they are.");
        JCheckBox jCheckBox2 = SettingsDialog.box("Remove junk & dead code, fake exception handlers", deobSettings.junkCode, "NOPs, push/pop pairs, useless jumps, unreachable code and try/catch blocks that can never catch anything.");
        JCheckBox jCheckBox3 = SettingsDialog.box("Remove bogus debug info and metadata", deobSettings.debugInfo, "Forged local variable tables, invalid generic signatures, junk attributes, fake synthetic/bridge flags.");
        JCheckBox jCheckBox4 = SettingsDialog.box("Simplify opaque predicates & fold constants", deobSettings.constantFolding, "Branches whose condition is constant on every path are replaced by plain jumps.");
        JCheckBox jCheckBox5 = SettingsDialog.box("    Treat never-reassigned static fields as constants", deobSettings.foldStaticConstantFields, "Only fields that are written at most once, with a literal, in their own static initializer.");
        JCheckBox jCheckBox6 = SettingsDialog.box("Decrypt strings (static emulation)", deobSettings.stringDecryption, "Decryption routines are evaluated in a sandboxed bytecode emulator. Nothing from the jar is executed.");
        JCheckBox jCheckBox7 = SettingsDialog.box("Resolve invokedynamic with custom bootstrap methods", deobSettings.indyResolution, "Bootstrap methods are emulated symbolically and replaced by the direct call they resolve to.");
        JCheckBox jCheckBox8 = SettingsDialog.box("Rename illegal / confusing names", deobSettings.renaming, "Unicode, invisible, keyword, Il1I-style and Windows-reserved names become class_001, method_a3f, field_12.");
        JCheckBox jCheckBox9 = SettingsDialog.box("    Also rename short names (a, b, aa \u2026)", deobSettings.renameShortNames, "ProGuard-style names are legal Java; enable to replace them too.");
        jCheckBox5.setEnabled(jCheckBox4.isSelected());
        jCheckBox4.addActionListener(actionEvent -> jCheckBox5.setEnabled(jCheckBox4.isSelected()));
        jCheckBox9.setEnabled(jCheckBox8.isSelected());
        jCheckBox8.addActionListener(actionEvent -> jCheckBox9.setEnabled(jCheckBox8.isSelected()));
        JSpinner jSpinner = new JSpinner(new SpinnerNumberModel(deobSettings.maxPasses, 1, 50, 1));
        JSpinner jSpinner2 = new JSpinner(new SpinnerNumberModel(deobSettings.emulatorInstructionLimit, 1000, 50000000, 10000));
        JSpinner jSpinner3 = new JSpinner(new SpinnerNumberModel(deobSettings.emulatorClinitLimit, 1000, 100000000, 100000));
        JComboBox<DecompilerService.Engine> jComboBox = new JComboBox<DecompilerService.Engine>(DecompilerService.Engine.values());
        jComboBox.setSelectedItem((Object)appSettings.engine);
        JPanel jPanel = SettingsDialog.column("Transforms (repeated until nothing changes)", jCheckBox, jCheckBox2, jCheckBox3, jCheckBox4, jCheckBox5, jCheckBox6, jCheckBox7, jCheckBox8, jCheckBox9);
        JPanel jPanel2 = SettingsDialog.column("Limits", SettingsDialog.labeled("Maximum passes", jSpinner), SettingsDialog.labeled("Emulator instruction limit per call", jSpinner2), SettingsDialog.labeled("Emulator instruction limit per static initializer", jSpinner3));
        JPanel jPanel3 = SettingsDialog.column("Decompiler", SettingsDialog.labeled("Engine", jComboBox));
        JPanel jPanel4 = new JPanel();
        jPanel4.setLayout(new BoxLayout(jPanel4, 1));
        jPanel4.setBorder(BorderFactory.createEmptyBorder(10, 12, 4, 12));
        jPanel4.add(jPanel);
        jPanel4.add(Box.createVerticalStrut(8));
        jPanel4.add(jPanel2);
        jPanel4.add(Box.createVerticalStrut(8));
        jPanel4.add(jPanel3);
        Runnable runnable = () -> {
            deobSettings.enabled = jCheckBox.isSelected();
            deobSettings.junkCode = jCheckBox2.isSelected();
            deobSettings.debugInfo = jCheckBox3.isSelected();
            deobSettings.constantFolding = jCheckBox4.isSelected();
            deobSettings.foldStaticConstantFields = jCheckBox5.isSelected();
            deobSettings.stringDecryption = jCheckBox6.isSelected();
            deobSettings.indyResolution = jCheckBox7.isSelected();
            deobSettings.renaming = jCheckBox8.isSelected();
            deobSettings.renameShortNames = jCheckBox9.isSelected();
            deobSettings.maxPasses = (Integer)jSpinner.getValue();
            deobSettings.emulatorInstructionLimit = (Integer)jSpinner2.getValue();
            deobSettings.emulatorClinitLimit = (Integer)jSpinner3.getValue();
            appSettings.deob = deobSettings.copy();
            appSettings.engine = (DecompilerService.Engine)((Object)((Object)jComboBox.getSelectedItem()));
            appSettings.save();
        };
        JButton jButton = new JButton("Save & Re-run");
        jButton.setEnabled(bl);
        jButton.setToolTipText("Apply the settings and deobfuscate the opened jar again");
        jButton.addActionListener(actionEvent -> {
            runnable.run();
            this.dispose();
            consumer.accept(true);
        });
        JButton jButton2 = new JButton("Save");
        jButton2.addActionListener(actionEvent -> {
            runnable.run();
            this.dispose();
            consumer.accept(false);
        });
        JButton jButton3 = new JButton("Cancel");
        jButton3.addActionListener(actionEvent -> this.dispose());
        JPanel jPanel5 = new JPanel(new FlowLayout(2));
        jPanel5.add(jButton3);
        jPanel5.add(jButton2);
        jPanel5.add(jButton);
        this.getRootPane().setDefaultButton(bl ? jButton : jButton2);
        this.getRootPane().registerKeyboardAction(actionEvent -> this.dispose(), KeyStroke.getKeyStroke(27, 0), 2);
        this.setLayout(new BorderLayout());
        this.add((Component)jPanel4, "Center");
        this.add((Component)jPanel5, "South");
        this.pack();
        this.setResizable(false);
        this.setLocationRelativeTo(jFrame);
    }

    private static JCheckBox box(String string, boolean bl, String string2) {
        JCheckBox jCheckBox = new JCheckBox(string, bl);
        jCheckBox.setToolTipText(string2);
        jCheckBox.setAlignmentX(0.0f);
        return jCheckBox;
    }

    private static JPanel labeled(String string, JComponent jComponent) {
        JPanel jPanel = new JPanel(new BorderLayout(12, 0));
        jPanel.add((Component)new JLabel(string), "Center");
        jPanel.add((Component)jComponent, "East");
        jPanel.setAlignmentX(0.0f);
        jPanel.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
        return jPanel;
    }

    private static JPanel column(String string, JComponent ... jComponentArray) {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, 1));
        jPanel.setBorder(BorderFactory.createTitledBorder(string));
        jPanel.setAlignmentX(0.0f);
        for (JComponent jComponent : jComponentArray) {
            jPanel.add(jComponent);
        }
        return jPanel;
    }
}

