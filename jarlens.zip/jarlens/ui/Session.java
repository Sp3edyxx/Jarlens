/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.ui;

import dev.jarlens.core.JarModel;
import dev.jarlens.decompile.DecompilerService;
import dev.jarlens.deob.DeobSettings;
import dev.jarlens.deob.Deobfuscator;
import dev.jarlens.mapping.MappingSet;
import dev.jarlens.ui.NavIndex;
import java.lang.ref.SoftReference;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class Session {
    private final JarModel model;
    private final DecompilerService decompiler;
    private volatile Deobfuscator.Result result;
    private volatile MappingSet mapping;
    private final Map<String, SoftReference<DecompilerService.Result>> cache = new ConcurrentHashMap<String, SoftReference<DecompilerService.Result>>();
    private final Map<Variant, NavIndex> indexes = new ConcurrentHashMap<Variant, NavIndex>();

    public Session(JarModel jarModel, DecompilerService decompilerService) {
        this.model = jarModel;
        this.decompiler = decompilerService;
    }

    public JarModel model() {
        return this.model;
    }

    public Deobfuscator.Result result() {
        return this.result;
    }

    public MappingSet mapping() {
        return this.mapping;
    }

    public void mapping(MappingSet mappingSet) {
        this.mapping = mappingSet;
    }

    public Deobfuscator.Result deobfuscate(DeobSettings deobSettings, Deobfuscator.Progress progress) {
        Deobfuscator.Result result;
        this.result = result = new Deobfuscator(deobSettings, progress).run(this.model, this.mapping);
        this.cache.clear();
        this.indexes.clear();
        return result;
    }

    public Map<String, byte[]> classes(Variant variant) {
        Deobfuscator.Result result = this.result;
        if (variant == Variant.ORIGINAL || result == null) {
            return this.model.classes();
        }
        return result.classes();
    }

    public String nameIn(String string, Variant variant) {
        Deobfuscator.Result result = this.result;
        if (variant == Variant.ORIGINAL && result != null) {
            return result.originalName(string);
        }
        return string;
    }

    public String currentName(String string, Variant variant) {
        Deobfuscator.Result result = this.result;
        if (variant == Variant.ORIGINAL && result != null) {
            return result.currentName(string);
        }
        return string;
    }

    public static String topLevel(String string, Map<String, byte[]> map) {
        String string2;
        int n;
        String string3 = string;
        while ((n = string3.lastIndexOf(36)) > 0 && map.containsKey(string2 = string3.substring(0, n))) {
            string3 = string2;
        }
        return string3;
    }

    public DecompilerService.Result decompile(String string, Variant variant, DecompilerService.Engine engine) {
        return this.decompile(string, variant, engine, true);
    }

    public DecompilerService.Result decompile(String string, Variant variant, DecompilerService.Engine engine, boolean bl) {
        Map<String, byte[]> map = this.classes(variant);
        String string2 = Session.topLevel(string, map);
        String string3 = String.valueOf((Object)variant) + "|" + String.valueOf((Object)engine) + "|" + string2;
        SoftReference<DecompilerService.Result> softReference = this.cache.get(string3);
        DecompilerService.Result result = softReference == null ? null : softReference.get();
        DecompilerService.Result result2 = result;
        if (result != null) {
            return result;
        }
        DecompilerService.Result result3 = this.decompiler.decompile(string2, map, engine);
        if (bl) {
            this.cache.put(string3, new SoftReference<DecompilerService.Result>(result3));
        }
        return result3;
    }

    public NavIndex index(Variant variant2) {
        return this.indexes.computeIfAbsent(variant2, variant -> NavIndex.build(this.classes((Variant)((Object)variant))));
    }

    public void clearDecompiled() {
        this.cache.clear();
    }

    public static enum Variant {
        DEOBFUSCATED,
        ORIGINAL;

    }
}

