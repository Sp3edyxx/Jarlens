/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.decompile;

import java.util.Map;

interface Decompiler {
    public String name();

    public String decompile(String var1, Map<String, byte[]> var2) throws Exception;

    public int failureMarkers(String var1);
}

