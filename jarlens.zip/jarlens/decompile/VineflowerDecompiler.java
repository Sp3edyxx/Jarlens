/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.decompile;

import dev.jarlens.core.JdkClasses;
import dev.jarlens.decompile.Decompiler;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.invoke.CallSite;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Objects;
import java.util.jar.Manifest;
import org.jetbrains.java.decompiler.main.Fernflower;
import org.jetbrains.java.decompiler.main.extern.IContextSource;
import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
import org.jetbrains.java.decompiler.main.extern.IResultSaver;

final class VineflowerDecompiler
implements Decompiler {
    private static final String CLASS_SUFFIX_STR = ".class";
    private static final IResultSaver NO_SAVER = new IResultSaver(){

        @Override
        public void saveFolder(String string) {
        }

        @Override
        public void copyFile(String string, String string2, String string3) {
        }

        @Override
        public void saveClassFile(String string, String string2, String string3, String string4, int[] nArray) {
        }

        @Override
        public void createArchive(String string, String string2, Manifest manifest) {
        }

        @Override
        public void saveDirEntry(String string, String string2, String string3) {
        }

        @Override
        public void copyEntry(String string, String string2, String string3, String string4) {
        }

        @Override
        public void saveClassEntry(String string, String string2, String string3, String string4, String string5) {
        }

        @Override
        public void closeArchive(String string, String string2) {
        }
    };

    VineflowerDecompiler() {
    }

    @Override
    public String name() {
        return "Vineflower";
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public String decompile(String string, Map<String, byte[]> map) {
        Map.Entry<String, byte[]> entry2;
        Object object;
        Map<String, Object> map2;
        HashMap<String, byte[]> hashMap = new HashMap<String, byte[]>();
        String string2 = string + "$";
        if (map instanceof NavigableMap && (map2 = (NavigableMap)map).comparator() == null) {
            object = (byte[])map2.get(string);
            if (object != null) {
                hashMap.put(string, (byte[])object);
            }
            hashMap.putAll(map2.subMap((String)((Object)((CallSite)((Object)string2))), true, (String)((Object)((CallSite)((Object)(string + "%")))), false));
        } else {
            for (Map.Entry<String, byte[]> entry2 : map.entrySet()) {
                String string3 = entry2.getKey();
                if (!string3.equals(string) && !string3.startsWith(string2)) continue;
                hashMap.put(string3, entry2.getValue());
            }
        }
        if (hashMap.isEmpty()) {
            throw new IllegalArgumentException("Class not found: " + string);
        }
        map2 = new HashMap();
        ((HashMap)map2).put("decompile-generics", "1");
        ((HashMap)map2).put("remove-bridge", "1");
        ((HashMap)map2).put("remove-synthetic", "1");
        ((HashMap)map2).put("ignore-invalid-bytecode", "1");
        ((HashMap)map2).put("verify-anonymous-classes", "1");
        ((HashMap)map2).put("pattern-matching", "1");
        ((HashMap)map2).put("ternary-in-if", "1");
        ((HashMap)map2).put("decompile-switch-expressions", "1");
        ((HashMap)map2).put("override-annotation", "1");
        ((HashMap)map2).put("indent-string", "    ");
        ((HashMap)map2).put("max-time-per-method", "15");
        ((HashMap)map2).put("thread-count", "1");
        ((HashMap)map2).put("dump-exception-on-error", "0");
        ((HashMap)map2).put("validate-inner-classes-names", "1");
        ((HashMap)map2).put("include-runtime", "current");
        ((HashMap)map2).put("log-level", "ERROR");
        object = new StringBuilder();
        entry2 = new Fernflower(NO_SAVER, map2, new IFernflowerLogger(this){
            {
                Objects.requireNonNull(vineflowerDecompiler);
            }

            @Override
            public void writeMessage(String string, IFernflowerLogger.Severity severity) {
            }

            @Override
            public void writeMessage(String string, IFernflowerLogger.Severity severity, Throwable throwable) {
            }
        });
        try {
            ((Fernflower)((Object)entry2)).addSource(new MemorySource("jarlens-source", hashMap, (StringBuilder)object, string));
            ((Fernflower)((Object)entry2)).addLibrary(new LibrarySource(map, hashMap));
            ((Fernflower)((Object)entry2)).decompileContext();
        }
        finally {
            ((Fernflower)((Object)entry2)).clearContext();
        }
        if (((StringBuilder)object).length() == 0) {
            throw new IllegalStateException("Vineflower produced no output");
        }
        return ((StringBuilder)object).toString();
    }

    @Override
    public int failureMarkers(String string) {
        return VineflowerDecompiler.count(string, "Couldn't be decompiled") + VineflowerDecompiler.count(string, "$VF: Unable to") + VineflowerDecompiler.count(string, "<unrepresentable>") + VineflowerDecompiler.count(string, "$FF: Couldn't");
    }

    static int count(String string, String string2) {
        int n = 0;
        int n2 = 0;
        while ((n2 = string.indexOf(string2, n2)) >= 0) {
            ++n;
            n2 += string2.length();
        }
        return n;
    }

    private static String strip(String string) {
        return string.endsWith(CLASS_SUFFIX_STR) ? string.substring(0, string.length() - CLASS_SUFFIX_STR.length()) : string;
    }

    private static final class MemorySource
    implements IContextSource {
        private final String name;
        private final Map<String, byte[]> classes;
        private final StringBuilder out;
        private final String topLevel;

        MemorySource(String string, Map<String, byte[]> map, StringBuilder stringBuilder, String string2) {
            this.name = string;
            this.classes = map;
            this.out = stringBuilder;
            this.topLevel = string2;
        }

        @Override
        public String getName() {
            return this.name;
        }

        @Override
        public IContextSource.Entries getEntries() {
            ArrayList<IContextSource.Entry> arrayList = new ArrayList<IContextSource.Entry>();
            for (String string : this.classes.keySet()) {
                arrayList.add(IContextSource.Entry.atBase(string));
            }
            return new IContextSource.Entries(arrayList, List.of(), List.of());
        }

        @Override
        public byte[] getClassBytes(String string) {
            return this.classes.get(VineflowerDecompiler.strip(string));
        }

        @Override
        public boolean hasClass(String string) {
            return this.classes.containsKey(VineflowerDecompiler.strip(string));
        }

        @Override
        public InputStream getInputStream(String string) {
            byte[] byArray = this.classes.get(VineflowerDecompiler.strip(string));
            return byArray == null ? null : new ByteArrayInputStream(byArray);
        }

        @Override
        public IContextSource.IOutputSink createOutputSink(IResultSaver iResultSaver) {
            return new IContextSource.IOutputSink(this){
                final /* synthetic */ MemorySource this$0;
                {
                    MemorySource memorySource2 = memorySource;
                    Objects.requireNonNull(memorySource2);
                    this.this$0 = memorySource2;
                }

                @Override
                public void begin() {
                }

                @Override
                public void acceptClass(String string, String string2, String string3, int[] nArray) {
                    if (string3 == null) {
                        return;
                    }
                    if (string.equals(this.this$0.topLevel) || this.this$0.out.length() == 0) {
                        if (string.equals(this.this$0.topLevel)) {
                            this.this$0.out.setLength(0);
                        }
                        this.this$0.out.append(string3);
                    }
                }

                @Override
                public void acceptDirectory(String string) {
                }

                @Override
                public void acceptOther(String string) {
                }

                @Override
                public void close() {
                }
            };
        }
    }

    private static final class LibrarySource
    implements IContextSource {
        private final Map<String, byte[]> all;
        private final Map<String, byte[]> exclude;

        LibrarySource(Map<String, byte[]> map, Map<String, byte[]> map2) {
            this.all = map;
            this.exclude = map2;
        }

        @Override
        public String getName() {
            return "jarlens-library";
        }

        @Override
        public IContextSource.Entries getEntries() {
            return IContextSource.Entries.EMPTY;
        }

        @Override
        public boolean isLazy() {
            return true;
        }

        @Override
        public boolean hasClass(String string) {
            return this.getClassBytes(string) != null;
        }

        @Override
        public byte[] getClassBytes(String string) {
            String string2 = VineflowerDecompiler.strip(string);
            if (this.exclude.containsKey(string2)) {
                return null;
            }
            byte[] byArray = this.all.get(string2);
            return byArray != null ? byArray : JdkClasses.get(string2);
        }

        @Override
        public InputStream getInputStream(String string) {
            byte[] byArray = this.getClassBytes(string);
            return byArray == null ? null : new ByteArrayInputStream(byArray);
        }
    }
}

