/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.decompile;

import dev.jarlens.core.JdkClasses;
import dev.jarlens.decompile.Decompiler;
import dev.jarlens.decompile.VineflowerDecompiler;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.benf.cfr.reader.api.CfrDriver;
import org.benf.cfr.reader.api.ClassFileSource;
import org.benf.cfr.reader.api.OutputSinkFactory;
import org.benf.cfr.reader.api.SinkReturns;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;

final class CfrDecompiler
implements Decompiler {
    CfrDecompiler() {
    }

    @Override
    public String name() {
        return "CFR";
    }

    @Override
    public String decompile(String string, final Map<String, byte[]> map) {
        if (!map.containsKey(string)) {
            throw new IllegalArgumentException("Class not found: " + string);
        }
        final StringBuilder stringBuilder = new StringBuilder();
        final StringBuilder stringBuilder2 = new StringBuilder();
        ClassFileSource classFileSource = new ClassFileSource(){
            {
                Objects.requireNonNull(cfrDecompiler);
            }

            @Override
            public void informAnalysisRelativePathDetail(String string, String string2) {
            }

            @Override
            public Collection<String> addJar(String string) {
                return Collections.emptyList();
            }

            @Override
            public String getPossiblyRenamedPath(String string) {
                return string;
            }

            @Override
            public Pair<byte[], String> getClassFileContent(String string) throws IOException {
                String string2 = string.endsWith(".class") ? string.substring(0, string.length() - 6) : string;
                byte[] byArray = (byte[])map.get(string2);
                if (byArray == null) {
                    byArray = JdkClasses.get(string2);
                }
                if (byArray == null) {
                    throw new IOException("No class " + string2);
                }
                return Pair.make(byArray, string);
            }
        };
        OutputSinkFactory outputSinkFactory = new OutputSinkFactory(){
            {
                Objects.requireNonNull(cfrDecompiler);
            }

            @Override
            public List<OutputSinkFactory.SinkClass> getSupportedSinks(OutputSinkFactory.SinkType sinkType, Collection<OutputSinkFactory.SinkClass> collection) {
                if (sinkType == OutputSinkFactory.SinkType.JAVA && collection.contains((Object)OutputSinkFactory.SinkClass.DECOMPILED)) {
                    return List.of(OutputSinkFactory.SinkClass.DECOMPILED, OutputSinkFactory.SinkClass.STRING);
                }
                return List.of(OutputSinkFactory.SinkClass.STRING);
            }

            @Override
            public <T> OutputSinkFactory.Sink<T> getSink(OutputSinkFactory.SinkType sinkType, OutputSinkFactory.SinkClass sinkClass) {
                if (sinkType == OutputSinkFactory.SinkType.JAVA && sinkClass == OutputSinkFactory.SinkClass.DECOMPILED) {
                    return object -> stringBuilder.append(((SinkReturns.Decompiled)object).getJava());
                }
                if (sinkType == OutputSinkFactory.SinkType.JAVA) {
                    return object -> stringBuilder.append(object);
                }
                if (sinkType == OutputSinkFactory.SinkType.EXCEPTION) {
                    return object -> stringBuilder2.append(object).append('\n');
                }
                return object -> {};
            }
        };
        CfrDriver cfrDriver = new CfrDriver.Builder().withOverrideClassFileSource(classFileSource).withOutputSink(outputSinkFactory).withOptions(Map.of("showversion", "false", "silent", "true", "innerclasses", "true", "decodestringswitch", "true", "sugarenums", "true", "decodelambdas", "true", "hideutf", "false", "recover", "true")).build();
        cfrDriver.analyse(List.of(string + ".class"));
        if (stringBuilder.length() == 0) {
            throw new IllegalStateException("CFR produced no output" + (String)(stringBuilder2.length() > 0 ? ": " + String.valueOf(stringBuilder2) : ""));
        }
        return stringBuilder.toString();
    }

    @Override
    public int failureMarkers(String string) {
        return VineflowerDecompiler.count(string, "This method has failed to decompile") + VineflowerDecompiler.count(string, "Exception decompiling") + VineflowerDecompiler.count(string, "Unable to fully structure code");
    }
}

