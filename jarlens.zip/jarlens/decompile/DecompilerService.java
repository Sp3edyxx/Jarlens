/*
 * Decompiled with CFR 0.152.
 */
package dev.jarlens.decompile;

import dev.jarlens.core.JarLoader;
import dev.jarlens.decompile.CfrDecompiler;
import dev.jarlens.decompile.Decompiler;
import dev.jarlens.decompile.VineflowerDecompiler;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;

public final class DecompilerService
implements AutoCloseable {
    private static final long TIMEOUT_SECONDS = 90L;
    private final Decompiler vineflower = new VineflowerDecompiler();
    private final Decompiler cfr = new CfrDecompiler();
    private final ExecutorService pool;

    public DecompilerService(int n) {
        AtomicInteger atomicInteger = new AtomicInteger();
        ThreadFactory threadFactory = runnable -> {
            Thread thread = new Thread(null, runnable, "decompiler-" + atomicInteger.incrementAndGet(), 0x4000000L);
            thread.setDaemon(true);
            thread.setPriority(4);
            return thread;
        };
        this.pool = Executors.newFixedThreadPool(Math.max(1, n), threadFactory);
    }

    public Result decompile(String string, Map<String, byte[]> map, Engine engine) {
        if (engine == Engine.CFR) {
            return this.attempt(this.cfr, string, map).orElse(string);
        }
        Attempt attempt = this.attempt(this.vineflower, string, map);
        if (engine == Engine.VINEFLOWER) {
            return attempt.orElse(string);
        }
        if (attempt.source != null && attempt.markers == 0) {
            return attempt.result(null);
        }
        Attempt attempt2 = this.attempt(this.cfr, string, map);
        if (attempt.source == null && attempt2.source == null) {
            return new Result(DecompilerService.errorText(string, "Vineflower: " + attempt.error + "\nCFR: " + attempt2.error), "none", "Both decompilers failed");
        }
        if (attempt.source == null) {
            return attempt2.result("Vineflower failed (" + attempt.error + "), showing CFR output");
        }
        if (attempt2.source != null && attempt2.markers < attempt.markers) {
            return attempt2.result("Vineflower could not decompile parts of this class, showing CFR output");
        }
        return attempt.result(attempt.markers > 0 ? "Some methods could not be decompiled" : null);
    }

    private Attempt attempt(Decompiler decompiler, String string, Map<String, byte[]> map) {
        Attempt attempt = new Attempt(this, decompiler);
        Future<String> future = this.pool.submit(() -> decompiler.decompile(string, map));
        try {
            attempt.source = future.get(90L, TimeUnit.SECONDS);
            attempt.markers = decompiler.failureMarkers(attempt.source);
        }
        catch (TimeoutException timeoutException) {
            future.cancel(true);
            attempt.error = "timed out after 90s";
        }
        catch (ExecutionException executionException) {
            Throwable throwable = executionException.getCause();
            attempt.error = throwable instanceof StackOverflowError ? "stack overflow" : JarLoader.describe(throwable);
        }
        catch (InterruptedException interruptedException) {
            future.cancel(true);
            Thread.currentThread().interrupt();
            attempt.error = "interrupted";
        }
        catch (Throwable throwable) {
            attempt.error = JarLoader.describe(throwable);
        }
        return attempt;
    }

    public void warmUp() {
        String string = "jarlens/internal/Warmup";
        TreeMap<String, byte[]> treeMap = new TreeMap<String, byte[]>(Map.of(string, DecompilerService.warmupClass(string)));
        for (Decompiler decompiler : new Decompiler[]{this.cfr, this.vineflower}) {
            try {
                decompiler.decompile(string, treeMap);
            }
            catch (Throwable throwable) {
                // empty catch block
            }
        }
    }

    private static byte[] warmupClass(String string) {
        ClassWriter classWriter = new ClassWriter(3);
        classWriter.visit(52, 33, string, null, "java/lang/Object", null);
        classWriter.visitField(0, "s", "Ljava/lang/String;", null, null).visitEnd();
        MethodVisitor methodVisitor = classWriter.visitMethod(1, "<init>", "()V", null, null);
        methodVisitor.visitCode();
        methodVisitor.visitVarInsn(25, 0);
        methodVisitor.visitMethodInsn(183, "java/lang/Object", "<init>", "()V", false);
        methodVisitor.visitVarInsn(25, 0);
        methodVisitor.visitLdcInsn("x");
        methodVisitor.visitFieldInsn(181, string, "s", "Ljava/lang/String;");
        methodVisitor.visitInsn(177);
        methodVisitor.visitMaxs(0, 0);
        methodVisitor.visitEnd();
        methodVisitor = classWriter.visitMethod(0, "sum", "(I)I", null, null);
        methodVisitor.visitCode();
        Label label = new Label();
        Label label2 = new Label();
        methodVisitor.visitInsn(3);
        methodVisitor.visitVarInsn(54, 2);
        methodVisitor.visitInsn(3);
        methodVisitor.visitVarInsn(54, 3);
        methodVisitor.visitLabel(label);
        methodVisitor.visitVarInsn(21, 3);
        methodVisitor.visitVarInsn(21, 1);
        methodVisitor.visitJumpInsn(162, label2);
        methodVisitor.visitVarInsn(21, 2);
        methodVisitor.visitVarInsn(21, 3);
        methodVisitor.visitInsn(96);
        methodVisitor.visitVarInsn(54, 2);
        methodVisitor.visitIincInsn(3, 1);
        methodVisitor.visitJumpInsn(167, label);
        methodVisitor.visitLabel(label2);
        methodVisitor.visitVarInsn(21, 2);
        methodVisitor.visitInsn(172);
        methodVisitor.visitMaxs(0, 0);
        methodVisitor.visitEnd();
        classWriter.visitEnd();
        return classWriter.toByteArray();
    }

    private static String errorText(String string, String string2) {
        return "/*\n * JarLens could not decompile " + string.replace('/', '.') + "\n *\n * " + string2.replace("*/", "* /").replace("\n", "\n * ") + "\n */\n";
    }

    @Override
    public void close() {
        this.pool.shutdownNow();
    }

    public static enum Engine {
        AUTO("Vineflower (CFR fallback)"),
        VINEFLOWER("Vineflower"),
        CFR("CFR");

        public final String label;

        private Engine(String string2) {
            this.label = string2;
        }

        public String toString() {
            return this.label;
        }
    }

    private final class Attempt {
        final Decompiler d;
        String source;
        String error;
        int markers;

        Attempt(DecompilerService decompilerService, Decompiler decompiler) {
            Objects.requireNonNull(decompilerService);
            this.d = decompiler;
        }

        Result result(String string) {
            return new Result(this.source, this.d.name(), string);
        }

        Result orElse(String string) {
            if (this.source != null) {
                return this.result(this.markers > 0 ? "Some methods could not be decompiled" : null);
            }
            return new Result(DecompilerService.errorText(string, this.d.name() + ": " + this.error), this.d.name(), this.d.name() + " failed");
        }
    }

    public record Result(String source, String engine, String note) {
    }
}

